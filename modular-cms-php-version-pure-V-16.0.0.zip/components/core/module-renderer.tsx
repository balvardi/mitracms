import { HeroSection } from "@/components/sections/hero-section"
import { ContentSection } from "@/components/sections/content-section"

interface ModuleRendererProps {
  type: string
  props: any
}

export function ModuleRenderer({ type, props }: ModuleRendererProps) {
  switch (type) {
    case "hero":
      return <HeroSection {...props} />
    case "content":
      return <ContentSection {...props} />
    default:
      return (
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-800">Unknown module type: {type}</p>
        </div>
      )
  }
}
