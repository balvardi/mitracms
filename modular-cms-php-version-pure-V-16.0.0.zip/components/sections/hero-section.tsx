import { Button } from "@/components/ui/button"
import { ArrowRight, Download, Github } from "lucide-react"
import Link from "next/link"

interface HeroSectionProps {
  title: string
  subtitle: string
  description: string
}

export function HeroSection({ title, subtitle, description }: HeroSectionProps) {
  return (
    <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">{title}</h1>
        <p className="text-xl md:text-2xl text-gray-600 mb-4 max-w-3xl mx-auto">{subtitle}</p>
        <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">{description}</p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <Download className="w-5 h-5 mr-2" />
            دانلود رایگان
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="https://github.com/balvardi/mitracms">
              <Github className="w-5 h-5 mr-2" />
              مشاهده در GitHub
            </Link>
          </Button>
          <Button size="lg" variant="ghost" asChild>
            <Link href="https://demo.mitracms.ir">
              نسخه آزمایشی
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="font-semibold text-lg mb-2">معماری ماژولار</h3>
            <p className="text-gray-600">نصب و مدیریت آسان ماژول‌ها برای گسترش قابلیت‌ها</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="font-semibold text-lg mb-2">قالب‌های زیبا</h3>
            <p className="text-gray-600">طراحی قالب‌های خیره‌کننده با سیستم قالب انعطاف‌پذیر</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="font-semibold text-lg mb-2">بهینه‌سازی SEO</h3>
            <p className="text-gray-600">ویژگی‌های داخلی SEO برای رتبه‌بندی بهتر در موتورهای جستجو</p>
          </div>
        </div>
      </div>
    </section>
  )
}
