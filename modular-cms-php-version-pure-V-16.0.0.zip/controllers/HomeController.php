<?php
require_once __DIR__ . '/../core/Controller.php';

class HomeController extends Controller
{
    public function index(): void
    {
        $this->view('home', [
            'title' => 'Mitra Global CMS – PHP Edition',
            'subtitle' => '🚀 CMS skeleton built with plain PHP, MySQL & Bootstrap',
        ]);
    }
}
