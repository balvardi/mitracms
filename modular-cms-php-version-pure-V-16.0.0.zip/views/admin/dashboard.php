<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> - Mitra CMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', Arial, sans-serif; background: #f8f9fa; }
        .sidebar { background: #343a40; min-height: 100vh; }
        .sidebar .nav-link { color: #adb5bd; }
        .sidebar .nav-link:hover { color: white; }
        .stat-card { transition: transform 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="p-3">
                    <h5 class="text-white">Mitra CMS</h5>
                    <nav class="nav flex-column mt-4">
                        <a class="nav-link active" href="/admin">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            داشبورد
                        </a>
                        <a class="nav-link" href="/admin/pages">
                            <i class="fas fa-file-alt me-2"></i>
                            صفحات
                        </a>
                        <a class="nav-link" href="/admin/users">
                            <i class="fas fa-users me-2"></i>
                            کاربران
                        </a>
                        <a class="nav-link" href="/admin/settings">
                            <i class="fas fa-cog me-2"></i>
                            تنظیمات
                        </a>
                        <hr class="text-secondary">
                        <a class="nav-link" href="/">
                            <i class="fas fa-home me-2"></i>
                            مشاهده سایت
                        </a>
                        <a class="nav-link" href="/admin/logout">
                            <i class="fas fa-sign-out-alt me-2"></i>
                            خروج
                        </a>
                    </nav>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-10">
                <div class="p-4">
                    <h1><?= $title ?></h1>
                    <p class="text-muted">خوش آمدید به پنل مدیریت Mitra Global CMS</p>

                    <!-- Stats -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card stat-card text-center">
                                <div class="card-body">
                                    <i class="fas fa-users fa-2x text-primary mb-2"></i>
                                    <h3><?= $stats['users'] ?></h3>
                                    <p class="text-muted">کاربران</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card text-center">
                                <div class="card-body">
                                    <i class="fas fa-file-alt fa-2x text-success mb-2"></i>
                                    <h3><?= $stats['pages'] ?></h3>
                                    <p class="text-muted">صفحات</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card text-center">
                                <div class="card-body">
                                    <i class="fas fa-shopping-cart fa-2x text-warning mb-2"></i>
                                    <h3><?= $stats['products'] ?></h3>
                                    <p class="text-muted">محصولات</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card text-center">
                                <div class="card-body">
                                    <i class="fas fa-chart-line fa-2x text-info mb-2"></i>
                                    <h3>0</h3>
                                    <p class="text-muted">بازدید امروز</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">اقدامات سریع</h5>
                                </div>
                                <div class="card-body">
                                    <div class="d-grid gap-2">
                                        <button class="btn btn-primary">
                                            <i class="fas fa-plus me-2"></i>
                                            ایجاد صفحه جدید
                                        </button>
                                        <button class="btn btn-success">
                                            <i class="fas fa-user-plus me-2"></i>
                                            افزودن کاربر
                                        </button>
                                        <button class="btn btn-info">
                                            <i class="fas fa-download me-2"></i>
                                            پشتیبان‌گیری
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">اطلاعات سیستم</h5>
                                </div>
                                <div class="card-body">
                                    <ul class="list-unstyled">
                                        <li><strong>نسخه PHP:</strong> <?= PHP_VERSION ?></li>
                                        <li><strong>نسخه CMS:</strong> 1.0.0</li>
                                        <li><strong>حافظه استفاده شده:</strong> <?= round(memory_get_usage() / 1024 / 1024, 2) ?> MB</li>
                                        <li><strong>زمان سرور:</strong> <?= date('Y-m-d H:i:s') ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
