<?php

namespace Modules\Ecommerce\Services;

class ZarinpalService
{
    private $merchantId;
    private $sandbox;
    private $apiUrl;

    public function __construct(string $merchantId, bool $sandbox = false)
    {
        $this->merchantId = $merchantId;
        $this->sandbox = $sandbox;
        $this->apiUrl = $sandbox 
            ? 'https://sandbox.zarinpal.com/pg/rest/WebGate/'
            : 'https://api.zarinpal.com/pg/rest/WebGate/';
    }

    public function requestPayment(array $data): array
    {
        $this->validatePaymentData($data);

        $requestData = [
            'MerchantID' => $this->merchantId,
            'Amount' => $data['amount'],
            'Description' => $data['description'],
            'CallbackURL' => $data['callback_url'],
            'Email' => $data['email'] ?? '',
            'Mobile' => $data['mobile'] ?? ''
        ];

        $response = $this->makeRequest('PaymentRequest.json', $requestData);

        if ($response['Status'] == 100) {
            $paymentUrl = ($this->sandbox ? 'https://sandbox.zarinpal.com' : 'https://www.zarinpal.com') 
                        . '/pg/StartPay/' . $response['Authority'];
            
            return [
                'success' => true,
                'authority' => $response['Authority'],
                'payment_url' => $paymentUrl
            ];
        }

        return [
            'success' => false,
            'error' => $this->getErrorMessage($response['Status']),
            'status' => $response['Status']
        ];
    }

    public function verifyPayment(string $authority, int $amount): array
    {
        $requestData = [
            'MerchantID' => $this->merchantId,
            'Authority' => $authority,
            'Amount' => $amount
        ];

        $response = $this->makeRequest('PaymentVerification.json', $requestData);

        if ($response['Status'] == 100 || $response['Status'] == 101) {
            return [
                'success' => true,
                'ref_id' => $response['RefID'],
                'status' => $response['Status']
            ];
        }

        return [
            'success' => false,
            'error' => $this->getErrorMessage($response['Status']),
            'status' => $response['Status']
        ];
    }

    private function makeRequest(string $endpoint, array $data): array
    {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl . $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Content-Length: ' . strlen(json_encode($data))
            ],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if (curl_errno($ch)) {
            throw new \Exception('cURL Error: ' . curl_error($ch));
        }
        
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new \Exception('HTTP Error: ' . $httpCode);
        }

        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('JSON Decode Error: ' . json_last_error_msg());
        }

        return $decodedResponse;
    }

    private function validatePaymentData(array $data): void
    {
        $required = ['amount', 'description', 'callback_url'];
        
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new \InvalidArgumentException("Field {$field} is required");
            }
        }

        if (!is_numeric($data['amount']) || $data['amount'] < 1000) {
            throw new \InvalidArgumentException("Amount must be at least 1000 Rials");
        }

        if (!filter_var($data['callback_url'], FILTER_VALIDATE_URL)) {
            throw new \InvalidArgumentException("Invalid callback URL");
        }

        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException("Invalid email address");
        }

        if (!empty($data['mobile']) && !preg_match('/^09\d{9}$/', $data['mobile'])) {
            throw new \InvalidArgumentException("Invalid mobile number");
        }
    }

    private function getErrorMessage(int $status): string
    {
        $errors = [
            -1 => 'اطلاعات ارسال شده ناقص است',
            -2 => 'IP یا مرچنت کد پذیرنده صحیح نیست',
            -3 => 'با توجه به محدودیت‌های شاپرک امکان پرداخت با رقم درخواستی میسر نمی‌باشد',
            -4 => 'سطح تأیید پذیرنده پایین‌تر از سطح نقره‌ای است',
            -11 => 'درخواست مورد نظر یافت نشد',
            -12 => 'امکان ویرایش درخواست میسر نمی‌باشد',
            -21 => 'هیچ نوع عملیات مالی برای این تراکنش یافت نشد',
            -22 => 'تراکنش ناموفق است',
            -33 => 'رقم تراکنش با رقم پرداخت شده مطابقت ندارد',
            -34 => 'سقف تقسیم تراکنش از لحاظ تعداد یا رقم عبور نموده است',
            -40 => 'اجازه دسترسی به متد مربوطه وجود ندارد',
            -41 => 'اطلاعات ارسال شده مربوط به AdditionalData غیرمعتبر است',
            -42 => 'مدت زمان معتبر طول عمر شناسه پرداخت بایستی بین 30 دقیقه تا 45 روز مشخص گردد',
            -54 => 'درخواست مورد نظر آرشیو شده است',
            100 => 'عملیات با موفقیت انجام گردید',
            101 => 'عملیات پرداخت موفق بوده و قبلا PaymentVerification تراکنش انجام شده است'
        ];

        return $errors[$status] ?? 'خطای نامشخص';
    }
}
