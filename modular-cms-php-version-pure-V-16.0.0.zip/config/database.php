<?php
/**
 * Simple DB config
 * Rename this file to database.php and put your real credentials.
 */
return [
    'host'     => 'localhost',
    'port'     => 3306,
    'name'     => 'cms_db',
    'user'     => 'cms_user',
    'password' => 'secret',
    'charset'  => 'utf8mb4'
];
