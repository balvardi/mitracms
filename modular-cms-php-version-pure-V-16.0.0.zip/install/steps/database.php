<div class="card">
    <div class="card-header">
        <h4 class="mb-0">
            <i class="fas fa-database me-2"></i>
            تنظیمات پایگاه داده
        </h4>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            اطلاعات پایگاه داده MySQL خود را وارد کنید
        </p>
        
        <form id="database-form">
            <div class="row">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label for="db_host" class="form-label">آدرس سرور</label>
                        <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                        <div class="form-text">معمولاً localhost است</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="db_port" class="form-label">پورت</label>
                        <input type="number" class="form-control" id="db_port" name="db_port" value="3306" required>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="db_name" class="form-label">نام پایگاه داده</label>
                <input type="text" class="form-control" id="db_name" name="db_name" value="mitracms" required>
                <div class="form-text">پایگاه داده باید از قبل ایجاد شده باشد</div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="db_username" class="form-label">نام کاربری</label>
                        <input type="text" class="form-control" id="db_username" name="db_username" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="db_password" class="form-label">رمز عبور</label>
                        <input type="password" class="form-control" id="db_password" name="db_password">
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <button type="button" class="btn btn-outline-primary" data-action="test-database">
                    <i class="fas fa-plug me-2"></i>
                    تست اتصال
                </button>
            </div>
        </form>
    </div>
</div>

<div class="d-flex justify-content-between mt-4">
    <button type="button" class="btn btn-outline-secondary" data-action="prev-step" data-prev-step="requirements">
        <i class="fas fa-arrow-right me-2"></i>
        مرحله قبل
    </button>
    
    <button type="button" class="btn btn-primary" data-action="next-step" data-next-step="config" disabled>
        مرحله بعد
        <i class="fas fa-arrow-left ms-2"></i>
    </button>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-info-circle me-2"></i>نکات مهم</h6>
    <ul class="mb-0">
        <li>پایگاه داده باید از قبل در cPanel یا phpMyAdmin ایجاد شده باشد</li>
        <li>کاربر پایگاه داده باید دسترسی کامل به پایگاه داده داشته باشد</li>
        <li>حتماً قبل از ادامه، اتصال را تست کنید</li>
    </ul>
</div>
