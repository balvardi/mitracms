<div class="card">
    <div class="card-header">
        <h4 class="mb-0">
            <i class="fas fa-check-circle me-2"></i>
            بررسی پیش‌نیازها
        </h4>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            لطفاً صبر کنید تا پیش‌نیازهای سیستم بررسی شود...
        </p>
        
        <div id="requirements-list">
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">در حال بررسی...</span>
                </div>
                <p class="mt-3 text-muted">در حال بررسی سیستم...</p>
            </div>
        </div>
        
        <div class="mt-4">
            <button type="button" class="btn btn-outline-primary" data-action="check-requirements">
                <i class="fas fa-refresh me-2"></i>
                بررسی مجدد
            </button>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between mt-4">
    <button type="button" class="btn btn-outline-secondary" data-action="prev-step" data-prev-step="welcome">
        <i class="fas fa-arrow-right me-2"></i>
        مرحله قبل
    </button>
    
    <button type="button" class="btn btn-primary" data-action="next-step" data-next-step="database" disabled>
        مرحله بعد
        <i class="fas fa-arrow-left ms-2"></i>
    </button>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-lightbulb me-2"></i>راهنمایی</h6>
    <p class="mb-2">در صورت مواجهه با خطا:</p>
    <ul class="mb-0">
        <li><strong>نسخه PHP:</strong> از پنل کنترل هاست نسخه PHP را به 7.4+ تغییر دهید</li>
        <li><strong>افزونه‌ها:</strong> از طریق پنل کنترل یا تماس با پشتیبانی هاست فعال کنید</li>
        <li><strong>مجوزها:</strong> مجوز نوشتن پوشه‌ها را به 755 تنظیم کنید</li>
    </ul>
</div>
