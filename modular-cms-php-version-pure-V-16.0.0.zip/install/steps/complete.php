<?php
$installData = $_SESSION['install_data'] ?? [];
?>

<div class="completion-hero">
    <div class="success-icon">
        <i class="fas fa-check"></i>
    </div>
    <h1>نصب تکمیل شد!</h1>
    <p class="lead">Mitra Global CMS با موفقیت نصب شد</p>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="info-box">
            <h6><i class="fas fa-globe me-2"></i>اطلاعات سایت</h6>
            <table class="table table-borderless">
                <tr>
                    <td><strong>آدرس سایت:</strong></td>
                    <td><a href="<?= $installData['site_url'] ?? '#' ?>" target="_blank"><?= $installData['site_url'] ?? 'نامشخص' ?></a></td>
                </tr>
                <tr>
                    <td><strong>پنل مدیریت:</strong></td>
                    <td><a href="<?= ($installData['site_url'] ?? '') . '/admin' ?>" target="_blank"><?= ($installData['site_url'] ?? '') . '/admin' ?></a></td>
                </tr>
            </table>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="info-box">
            <h6><i class="fas fa-user-shield me-2"></i>اطلاعات ورود مدیر</h6>
            <table class="table table-borderless">
                <tr>
                    <td><strong>نام کاربری:</strong></td>
                    <td><code><?= $installData['admin_username'] ?? 'admin' ?></code></td>
                </tr>
                <tr>
                    <td><strong>ایمیل:</strong></td>
                    <td><code><?= $installData['admin_email'] ?? 'نامشخص' ?></code></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<div class="alert alert-success">
    <h5><i class="fas fa-check-circle me-2"></i>مراحل بعدی</h5>
    <ol class="mb-0">
        <li>به پنل مدیریت بروید و وارد شوید</li>
        <li>تنظیمات اولیه سایت را کامل کنید</li>
        <li>قالب مورد نظر خود را انتخاب کنید</li>
        <li>محتوای اولیه سایت را ایجاد کنید</li>
    </ol>
</div>

<div class="alert alert-warning">
    <h6><i class="fas fa-exclamation-triangle me-2"></i>نکات امنیتی مهم</h6>
    <ul class="mb-0">
        <li>پوشه <code>install</code> را از سرور حذف کنید</li>
        <li>رمز عبور مدیر را تغییر دهید</li>
        <li>بک‌آپ منظم از سایت تهیه کنید</li>
        <li>سیستم را به‌روزرسانی کنید</li>
    </ul>
</div>

<div class="text-center mt-4">
    <a href="<?= ($installData['site_url'] ?? '') . '/admin' ?>" class="btn btn-primary btn-lg">
        <i class="fas fa-sign-in-alt me-2"></i>
        ورود به پنل مدیریت
    </a>
    
    <a href="<?= $installData['site_url'] ?? '#' ?>" class="btn btn-outline-primary btn-lg ms-3">
        <i class="fas fa-eye me-2"></i>
        مشاهده سایت
    </a>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-heart me-2"></i>از انتخاب Mitra Global CMS متشکریم!</h6>
    <p class="mb-2">برای دریافت آخرین اخبار و به‌روزرسانی‌ها:</p>
    <ul class="mb-0">
        <li>وب‌سایت: <a href="https://mitracms.ir" target="_blank">mitracms.ir</a></li>
        <li>مستندات: <a href="https://docs.mitracms.ir" target="_blank">docs.mitracms.ir</a></li>
        <li>پشتیبانی: <a href="https://forum.mitracms.ir" target="_blank">forum.mitracms.ir</a></li>
        <li>گیت‌هاب: <a href="https://github.com/balvardi/mitracms" target="_blank">github.com/balvardi/mitracms</a></li>
    </ul>
</div>
