<?php
/**
 * Mitra Global CMS - نصاب وب چندزبانه
 * نسخه: 1.0.0
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تنظیمات اولیه
define('INSTALL_DIR', __DIR__);
define('ROOT_DIR', dirname(__DIR__));
define('CONFIG_DIR', ROOT_DIR . '/config');
define('STORAGE_DIR', ROOT_DIR . '/storage');

// بارگذاری کلاس‌های کمکی
require_once INSTALL_DIR . '/includes/functions.php';
require_once INSTALL_DIR . '/includes/Language.php';
require_once INSTALL_DIR . '/includes/Installer.php';

// تنظیم زبان
$selectedLanguage = $_GET['lang'] ?? $_SESSION['installer_language'] ?? 'fa';
$language = new Language($selectedLanguage);

// تنظیم متغیر سراسری برای توابع کمکی
$GLOBALS['language'] = $language;

$installer = new Installer();
$step = $_GET['step'] ?? 'welcome';
$action = $_POST['action'] ?? '';

// پردازش تغییر زبان
if (isset($_GET['lang']) && $_GET['lang'] !== $selectedLanguage) {
    $language->setLanguage($_GET['lang']);
    $currentUrl = $_SERVER['REQUEST_URI'];
    $currentUrl = preg_replace('/[?&]lang=[^&]*/', '', $currentUrl);
    $separator = strpos($currentUrl, '?') !== false ? '&' : '?';
    header("Location: {$currentUrl}{$separator}lang={$_GET['lang']}");
    exit;
}

// پردازش اکشن‌ها
if ($action) {
    switch ($action) {
        case 'check_requirements':
            $result = $installer->checkRequirements();
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
            
        case 'test_database':
            $result = $installer->testDatabaseConnection($_POST);
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
            
        case 'install_database':
            $result = $installer->installDatabase($_POST);
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
            
        case 'create_config':
            $result = $installer->createConfigFiles($_POST);
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
            
        case 'create_admin':
            $result = $installer->createAdminUser($_POST);
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
            
        case 'finalize':
            $result = $installer->finalizeInstallation();
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
    }
}

// تعیین مرحله فعلی
$steps = [
    'welcome' => __('steps.welcome'),
    'requirements' => __('steps.requirements'),
    'database' => __('steps.database'),
    'config' => __('steps.config'),
    'admin' => __('steps.admin'),
    'install' => __('steps.install'),
    'complete' => __('steps.complete')
];

$currentStepIndex = array_search($step, array_keys($steps));
$progress = ($currentStepIndex + 1) / count($steps) * 100;

// اطلاعات زبان فعلی
$langInfo = $language->getLanguageInfo();
$direction = $language->getTextDirection();
$htmlLang = $language->getHtmlLang();
?>
<!DOCTYPE html>
<html lang="<?= $htmlLang ?>" dir="<?= $direction ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('app.installer') ?> - <?= __('app.name') ?></title>
    
    <?php if ($direction === 'rtl'): ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <?php else: ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php endif; ?>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <?php if ($htmlLang === 'fa' || $htmlLang === 'ar'): ?>
        <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php elseif ($htmlLang === 'tr'): ?>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php else: ?>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php endif; ?>
    
    <link href="assets/style.css" rel="stylesheet">
    
    <style>
        <?php if ($htmlLang === 'fa' || $htmlLang === 'ar'): ?>
        * { font-family: "Vazirmatn", sans-serif; }
        <?php else: ?>
        * { font-family: "Inter", sans-serif; }
        <?php endif; ?>
        
        <?php if ($direction === 'rtl'): ?>
        .step-icon { margin-right: 15px; margin-left: 0; }
        .btn i { margin-right: 8px; margin-left: 0; }
        .btn i.ms-2 { margin-right: 0; margin-left: 8px; }
        <?php endif; ?>
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row min-vh-100">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <div class="p-4">
                    <!-- Language Selector -->
                    <div class="language-selector mb-4">
                        <div class="dropdown">
                            <button class="btn btn-outline-light btn-sm dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
                                <?= $langInfo['flag'] ?> <?= $langInfo['native'] ?>
                            </button>
                            <ul class="dropdown-menu w-100">
                                <?php foreach ($language->getAvailableLanguages() as $code => $info): ?>
                                    <li>
                                        <a class="dropdown-item <?= $code === $htmlLang ? 'active' : '' ?>" 
                                           href="?<?= http_build_query(array_merge($_GET, ['lang' => $code])) ?>">
                                            <?= $info['flag'] ?> <?= $info['native'] ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="text-center mb-4">
                        <div class="logo">
                            <i class="fas fa-cube"></i>
                        </div>
                        <h4 class="mt-3"><?= __('app.name') ?></h4>
                        <p class="text-muted"><?= __('app.installer') ?></p>
                    </div>
                    
                    <!-- Progress Bar -->
                    <div class="progress mb-4" style="height: 8px;">
                        <div class="progress-bar" style="width: <?= $progress ?>%"></div>
                    </div>
                    
                    <!-- Steps -->
                    <ul class="steps-list">
                        <?php foreach ($steps as $stepKey => $stepTitle): ?>
                            <li class="step-item <?= $step === $stepKey ? 'active' : '' ?> <?= array_search($stepKey, array_keys($steps)) < $currentStepIndex ? 'completed' : '' ?>">
                                <div class="step-icon">
                                    <?php if (array_search($stepKey, array_keys($steps)) < $currentStepIndex): ?>
                                        <i class="fas fa-check"></i>
                                    <?php else: ?>
                                        <span><?= array_search($stepKey, array_keys($steps)) + 1 ?></span>
                                    <?php endif; ?>
                                </div>
                                <span class="step-title"><?= $stepTitle ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 main-content">
                <div class="p-5">
                    <?php
                    $stepFile = INSTALL_DIR . "/steps/{$step}.php";
                    if (file_exists($stepFile)) {
                        include $stepFile;
                    } else {
                        include INSTALL_DIR . '/steps/welcome.php';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Loading Modal -->
    <div class="modal fade" id="loadingModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center p-4">
                    <div class="spinner-border text-primary mb-3" role="status">
                        <span class="visually-hidden"><?= __('common.loading') ?></span>
                    </div>
                    <h5 id="loadingText"><?= __('common.processing') ?></h5>
                    <p class="text-muted mb-0" id="loadingSubtext"><?= __('common.please_wait') ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="assets/script.js"></script>
    
    <script>
        // Pass language data to JavaScript
        window.installerLang = {
            direction: '<?= $direction ?>',
            code: '<?= $htmlLang ?>',
            translations: <?= json_encode([
                'loading' => __('common.loading'),
                'processing' => __('common.processing'),
                'please_wait' => __('common.please_wait'),
                'error' => __('common.error'),
                'success' => __('common.success'),
                'connection_failed' => __('errors.connection_failed'),
                'requirements_checking' => __('requirements.checking'),
                'database_testing' => __('database.test_connection'),
                'config_creating' => __('config.title'),
                'admin_creating' => __('admin.title'),
                'installation_starting' => __('install.title')
            ]) ?>
        };
    </script>
</body>
</html>
