<?php

namespace App\Controllers;

use App\Core\Controller;

class AdminController extends Controller
{
    public function dashboard(): void
    {
        // بررسی ورود کاربر (ساده)
        if (!isset($_SESSION['admin_logged_in'])) {
            $this->showLogin();
            return;
        }

        $data = [
            'title' => 'پنل مدیریت',
            'stats' => [
                'users' => 0,
                'pages' => 0,
                'products' => 0
            ]
        ];

        $this->render('admin/dashboard', $data);
    }

    private function showLogin(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            // ورود ساده (در نسخه نهایی باید از دیتابیس استفاده کرد)
            if ($username === 'admin' && $password === 'admin123') {
                $_SESSION['admin_logged_in'] = true;
                header('Location: /admin');
                exit;
            } else {
                $error = 'نام کاربری یا رمز عبور اشتباه است';
            }
        }

        $this->render('admin/login', ['error' => $error ?? null]);
    }
}
