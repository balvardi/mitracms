import { type NextRequest, NextResponse } from "next/server"

// This would connect to your actual database
// For demo purposes, we're using mock data

const mockPages = [
  {
    id: 1,
    title: "Home",
    slug: "home",
    content: "Welcome to ModularCMS",
    status: "published",
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    title: "About Us",
    slug: "about",
    content: "About our company",
    status: "published",
    created_at: new Date().toISOString(),
  },
]

export async function GET(request: NextRequest) {
  try {
    // In a real implementation, you would:
    // const pages = await db.query('SELECT * FROM pages WHERE status = ?', ['published'])

    return NextResponse.json({
      success: true,
      data: mockPages,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch pages" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.title || !body.slug) {
      return NextResponse.json({ success: false, error: "Title and slug are required" }, { status: 400 })
    }

    // In a real implementation, you would:
    // const result = await db.query(
    //   'INSERT INTO pages (title, slug, content, status) VALUES (?, ?, ?, ?)',
    //   [body.title, body.slug, body.content, body.status || 'draft']
    // )

    const newPage = {
      id: Date.now(), // Mock ID
      ...body,
      created_at: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newPage,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to create page" }, { status: 500 })
  }
}
