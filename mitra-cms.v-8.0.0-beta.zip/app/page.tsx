import type { Metadata } from "next"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { HeroSection } from "@/components/sections/hero-section"
import { ModuleRenderer } from "@/components/core/module-renderer"

export const metadata: Metadata = {
  title: "Mitra Global CMS - سیستم مدیریت محتوای جهانی میترا",
  description: "سیستم مدیریت محتوای قدرتمند، ماژولار و متن‌باز برای توسعه‌دهندگان و تولیدکنندگان محتوا",
  keywords: "CMS, مدیریت محتوا, ماژولار, متن باز, PHP, MySQL",
  openGraph: {
    title: "Mitra Global CMS",
    description: "سیستم مدیریت محتوای قدرتمند و ماژولار",
    type: "website",
  },
}

export default function HomePage() {
  // In a real implementation, this would come from your database
  const pageModules = [
    {
      type: "hero",
      props: { title: "Welcome to ModularCMS", subtitle: "Build amazing websites with our modular system" },
    },
    {
      type: "content",
      props: { title: "About Our CMS", content: "This is a demonstration of a modular CMS system..." },
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection
          title="Mitra Global CMS"
          subtitle="سیستم مدیریت محتوای جهانی میترا"
          description="سیستم مدیریت محتوای قدرتمند، ماژولار و متن‌باز که با Next.js ساخته شده و دارای معماری ماژولار، قالب‌های زیبا و بهینه‌سازی کامل SEO است."
        />

        <div className="container mx-auto px-4 py-8">
          {pageModules.map((module, index) => (
            <ModuleRenderer key={index} type={module.type} props={module.props} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
