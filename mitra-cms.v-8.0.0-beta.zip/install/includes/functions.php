<?php

/**
 * توابع کمکی نصاب
 */

function formatBytes($size, $precision = 2)
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    
    return round($size, $precision) . ' ' . $units[$i];
}

function generateRandomString($length = 32)
{
    return bin2hex(random_bytes($length / 2));
}

function sanitizeInput($input)
{
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateUrl($url)
{
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

function createDirectory($path, $permissions = 0755)
{
    if (!is_dir($path)) {
        return mkdir($path, $permissions, true);
    }
    return true;
}

function isWritable($path)
{
    if (is_dir($path)) {
        return is_writable($path);
    }
    
    $dir = dirname($path);
    return is_writable($dir);
}

function getPhpInfo()
{
    return [
        'version' => PHP_VERSION,
        'memory_limit' => ini_get('memory_limit'),
        'max_execution_time' => ini_get('max_execution_time'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size' => ini_get('post_max_size'),
        'extensions' => get_loaded_extensions()
    ];
}

function checkDatabaseConnection($host, $port, $username, $password, $database = null)
{
    try {
        $dsn = "mysql:host=$host;port=$port";
        if ($database) {
            $dsn .= ";dbname=$database";
        }
        $dsn .= ";charset=utf8mb4";
        
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        return ['success' => true, 'connection' => $pdo];
    } catch (PDOException $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function logMessage($message, $level = 'info')
{
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] [$level] $message" . PHP_EOL;
    
    $logFile = STORAGE_DIR . '/logs/install.log';
    createDirectory(dirname($logFile));
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

function getSystemInfo()
{
    return [
        'os' => PHP_OS,
        'php_version' => PHP_VERSION,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? '',
        'memory_limit' => ini_get('memory_limit'),
        'max_execution_time' => ini_get('max_execution_time'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size' => ini_get('post_max_size'),
        'timezone' => date_default_timezone_get(),
        'extensions' => get_loaded_extensions()
    ];
}

function validateRequiredExtensions()
{
    $required = [
        'pdo_mysql' => 'پایگاه داده MySQL',
        'mbstring' => 'پردازش متن چندبایتی',
        'openssl' => 'رمزگذاری و امنیت',
        'gd' => 'پردازش تصاویر',
        'curl' => 'ارتباطات HTTP',
        'zip' => 'فشرده‌سازی فایل‌ها',
        'json' => 'پردازش JSON',
        'xml' => 'پردازش XML'
    ];
    
    $results = [];
    foreach ($required as $ext => $description) {
        $results[$ext] = [
            'name' => $description,
            'loaded' => extension_loaded($ext),
            'required' => true
        ];
    }
    
    return $results;
}

function validateDirectoryPermissions()
{
    $directories = [
        CONFIG_DIR => 'فایل‌های پیکربندی',
        STORAGE_DIR => 'فایل‌های ذخیره‌سازی',
        ROOT_DIR . '/public/uploads' => 'فایل‌های آپلود شده'
    ];
    
    $results = [];
    foreach ($directories as $dir => $description) {
        createDirectory($dir);
        $results[$dir] = [
            'name' => $description,
            'writable' => is_writable($dir),
            'exists' => is_dir($dir)
        ];
    }
    
    return $results;
}
