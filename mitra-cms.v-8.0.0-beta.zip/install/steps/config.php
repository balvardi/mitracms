<div class="card">
    <div class="card-header">
        <h4 class="mb-0">
            <i class="fas fa-cog me-2"></i>
            پیکربندی سایت
        </h4>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            اطلاعات اولیه سایت خود را وارد کنید
        </p>
        
        <form id="config-form">
            <div class="mb-3">
                <label for="site_title" class="form-label">عنوان سایت</label>
                <input type="text" class="form-control" id="site_title" name="site_title" value="Mitra Global CMS" required>
                <div class="form-text">این عنوان در تب مرورگر و موتورهای جستجو نمایش داده می‌شود</div>
            </div>
            
            <div class="mb-3">
                <label for="site_description" class="form-label">توضیحات سایت</label>
                <textarea class="form-control" id="site_description" name="site_description" rows="3" required>سیستم مدیریت محتوای قدرتمند و ماژولار</textarea>
                <div class="form-text">توضیح کوتاهی از سایت شما برای موتورهای جستجو</div>
            </div>
            
            <div class="mb-3">
                <label for="site_url" class="form-label">آدرس سایت</label>
                <input type="url" class="form-control" id="site_url" name="site_url" value="<?= (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['REQUEST_URI'])) ?>" required>
                <div class="form-text">آدرس کامل سایت شما (بدون / در انتها)</div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="admin_email" class="form-label">ایمیل مدیر</label>
                        <input type="email" class="form-control" id="admin_email" name="admin_email" required>
                        <div class="form-text">ایمیل اصلی برای دریافت اطلاعیه‌ها</div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="timezone" class="form-label">منطقه زمانی</label>
                        <select class="form-control" id="timezone" name="timezone" required>
                            <option value="Asia/Tehran" selected>تهران (ایران)</option>
                            <option value="Asia/Dubai">دبی (امارات)</option>
                            <option value="Asia/Kuwait">کویت</option>
                            <option value="Asia/Riyadh">ریاض (عربستان)</option>
                            <option value="Europe/Istanbul">استانبول (ترکیه)</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="language" class="form-label">زبان پیش‌فرض</label>
                <select class="form-control" id="language" name="language" required>
                    <option value="fa" selected>فارسی</option>
                    <option value="en">انگلیسی</option>
                    <option value="ar">عربی</option>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="d-flex justify-content-between mt-4">
    <button type="button" class="btn btn-outline-secondary" data-action="prev-step" data-prev-step="database">
        <i class="fas fa-arrow-right me-2"></i>
        مرحله قبل
    </button>
    
    <button type="button" class="btn btn-primary" data-action="create-config">
        مرحله بعد
        <i class="fas fa-arrow-left ms-2"></i>
    </button>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-lightbulb me-2"></i>توصیه‌ها</h6>
    <ul class="mb-0">
        <li>عنوان سایت را کوتاه و جذاب انتخاب کنید</li>
        <li>توضیحات سایت برای SEO بسیار مهم است</li>
        <li>آدرس سایت باید دقیقاً مطابق دامنه شما باشد</li>
        <li>ایمیل مدیر برای بازیابی رمز عبور استفاده می‌شود</li>
    </ul>
</div>
