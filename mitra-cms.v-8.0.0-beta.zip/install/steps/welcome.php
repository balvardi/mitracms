<div class="welcome-hero">
    <h1><?= __('welcome.title') ?></h1>
    <p class="lead"><?= __('welcome.subtitle') ?></p>
    <p class="text-muted"><?= __('welcome.description') ?></p>
</div>

<div class="feature-grid">
    <div class="feature-card">
        <div class="feature-icon">
            <i class="fas fa-cubes"></i>
        </div>
        <h5><?= __('welcome.features.modular.title') ?></h5>
        <p class="text-muted"><?= __('welcome.features.modular.description') ?></p>
    </div>
    
    <div class="feature-card">
        <div class="feature-icon">
            <i class="fas fa-palette"></i>
        </div>
        <h5><?= __('welcome.features.themes.title') ?></h5>
        <p class="text-muted"><?= __('welcome.features.themes.description') ?></p>
    </div>
    
    <div class="feature-card">
        <div class="feature-icon">
            <i class="fas fa-search"></i>
        </div>
        <h5><?= __('welcome.features.seo.title') ?></h5>
        <p class="text-muted"><?= __('welcome.features.seo.description') ?></p>
    </div>
    
    <div class="feature-card">
        <div class="feature-icon">
            <i class="fas fa-shield-alt"></i>
        </div>
        <h5><?= __('welcome.features.security.title') ?></h5>
        <p class="text-muted"><?= __('welcome.features.security.description') ?></p>
    </div>
</div>

<div class="text-center mt-5">
    <button type="button" class="btn btn-primary btn-lg" data-action="next-step" data-next-step="requirements">
        <?php if ($language->getTextDirection() === 'rtl'): ?>
            <i class="fas fa-arrow-left me-2"></i>
        <?php else: ?>
            <i class="fas fa-arrow-right me-2"></i>
        <?php endif; ?>
        <?= __('navigation.start') ?>
    </button>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-info-circle me-2"></i><?= __('welcome.info.title') ?></h6>
    <ul class="mb-0">
        <?php foreach (__('welcome.info.items') as $item): ?>
            <li><?= $item ?></li>
        <?php endforeach; ?>
    </ul>
</div>
