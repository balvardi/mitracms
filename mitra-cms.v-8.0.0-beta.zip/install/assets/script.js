// Import Bootstrap
import bootstrap from "bootstrap"

class MitraInstaller {
  constructor() {
    this.currentStep = new URLSearchParams(window.location.search).get("step") || "welcome"
    this.loadingModal = new bootstrap.Modal(document.getElementById("loadingModal"))
    this.init()
  }

  init() {
    this.bindEvents()
    this.initCurrentStep()
  }

  bindEvents() {
    // Navigation buttons
    document.addEventListener("click", (e) => {
      if (e.target.matches('[data-action="next-step"]')) {
        this.nextStep(e.target.dataset.nextStep)
      }

      if (e.target.matches('[data-action="prev-step"]')) {
        this.prevStep(e.target.dataset.prevStep)
      }

      if (e.target.matches('[data-action="check-requirements"]')) {
        this.checkRequirements()
      }

      if (e.target.matches('[data-action="test-database"]')) {
        this.testDatabase()
      }

      if (e.target.matches('[data-action="install-database"]')) {
        this.installDatabase()
      }

      if (e.target.matches('[data-action="create-config"]')) {
        this.createConfig()
      }

      if (e.target.matches('[data-action="create-admin"]')) {
        this.createAdmin()
      }

      if (e.target.matches('[data-action="start-installation"]')) {
        this.startInstallation()
      }
    })

    // Form validation
    document.addEventListener("input", (e) => {
      if (e.target.matches("input[required], select[required]")) {
        this.validateField(e.target)
      }
    })
  }

  initCurrentStep() {
    switch (this.currentStep) {
      case "requirements":
        this.checkRequirements()
        break
      case "install":
        this.startInstallation()
        break
    }
  }

  nextStep(step) {
    if (this.validateCurrentStep()) {
      window.location.href = `?step=${step}`
    }
  }

  prevStep(step) {
    window.location.href = `?step=${step}`
  }

  validateCurrentStep() {
    const form = document.querySelector("form")
    if (!form) return true

    const requiredFields = form.querySelectorAll("[required]")
    let isValid = true

    requiredFields.forEach((field) => {
      if (!this.validateField(field)) {
        isValid = false
      }
    })

    return isValid
  }

  validateField(field) {
    const value = field.value.trim()
    const isValid = value !== ""

    field.classList.toggle("is-invalid", !isValid)
    field.classList.toggle("is-valid", isValid)

    return isValid
  }

  showLoading(title = "در حال پردازش...", subtitle = "لطفاً صبر کنید") {
    document.getElementById("loadingText").textContent = title
    document.getElementById("loadingSubtext").textContent = subtitle
    this.loadingModal.show()
  }

  hideLoading() {
    this.loadingModal.hide()
  }

  showAlert(type, message, container = ".main-content .p-5") {
    const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `

    const containerEl = document.querySelector(container)
    containerEl.insertAdjacentHTML("afterbegin", alertHtml)

    // Auto dismiss after 5 seconds
    setTimeout(() => {
      const alert = containerEl.querySelector(".alert")
      if (alert) {
        bootstrap.Alert.getOrCreateInstance(alert).close()
      }
    }, 5000)
  }

  async makeRequest(action, data = {}) {
    try {
      const formData = new FormData()
      formData.append("action", action)

      Object.keys(data).forEach((key) => {
        formData.append(key, data[key])
      })

      const response = await fetch(window.location.href, {
        method: "POST",
        body: formData,
      })

      return await response.json()
    } catch (error) {
      console.error("Request failed:", error)
      return { success: false, message: "خطا در ارتباط با سرور" }
    }
  }

  async checkRequirements() {
    this.showLoading("بررسی پیش‌نیازها...", "در حال بررسی سیستم شما")

    try {
      const result = await this.makeRequest("check_requirements")
      this.hideLoading()

      if (result.success) {
        this.updateRequirements(result.requirements)

        const allPassed = result.requirements.every((req) => req.status === "success")
        const nextBtn = document.querySelector('[data-action="next-step"]')

        if (nextBtn) {
          nextBtn.disabled = !allPassed
          nextBtn.textContent = allPassed ? "ادامه" : "رفع مشکلات مورد نیاز"
        }
      } else {
        this.showAlert("danger", result.message)
      }
    } catch (error) {
      this.hideLoading()
      this.showAlert("danger", "خطا در بررسی پیش‌نیازها")
    }
  }

  updateRequirements(requirements) {
    const container = document.getElementById("requirements-list")
    if (!container) return

    container.innerHTML = requirements
      .map(
        (req) => `
            <div class="requirement-item ${req.status}">
                <div>
                    <strong>${req.name}</strong>
                    <div class="text-muted small">${req.description}</div>
                    ${req.current ? `<div class="text-info small">فعلی: ${req.current}</div>` : ""}
                </div>
                <div class="status-icon ${req.status}">
                    ${req.status === "success" ? "✓" : req.status === "error" ? "✗" : "!"}
                </div>
            </div>
        `,
      )
      .join("")
  }

  async testDatabase() {
    const form = document.getElementById("database-form")
    const formData = new FormData(form)
    const data = Object.fromEntries(formData)

    this.showLoading("تست اتصال...", "در حال بررسی اتصال به پایگاه داده")

    try {
      const result = await this.makeRequest("test_database", data)
      this.hideLoading()

      if (result.success) {
        this.showAlert("success", "اتصال به پایگاه داده موفقیت‌آمیز بود")
        document.querySelector('[data-action="next-step"]').disabled = false
      } else {
        this.showAlert("danger", result.message)
      }
    } catch (error) {
      this.hideLoading()
      this.showAlert("danger", "خطا در تست اتصال")
    }
  }

  async createConfig() {
    const forms = document.querySelectorAll("form")
    const allData = {}

    forms.forEach((form) => {
      const formData = new FormData(form)
      Object.assign(allData, Object.fromEntries(formData))
    })

    this.showLoading("ایجاد فایل‌های پیکربندی...", "در حال تنظیم سیستم")

    try {
      const result = await this.makeRequest("create_config", allData)
      this.hideLoading()

      if (result.success) {
        this.showAlert("success", "فایل‌های پیکربندی ایجاد شدند")
        setTimeout(() => this.nextStep("admin"), 1500)
      } else {
        this.showAlert("danger", result.message)
      }
    } catch (error) {
      this.hideLoading()
      this.showAlert("danger", "خطا در ایجاد فایل‌های پیکربندی")
    }
  }

  async createAdmin() {
    const form = document.getElementById("admin-form")
    const formData = new FormData(form)
    const data = Object.fromEntries(formData)

    if (data.password !== data.password_confirm) {
      this.showAlert("danger", "رمزهای عبور مطابقت ندارند")
      return
    }

    this.showLoading("ایجاد کاربر مدیر...", "در حال تنظیم حساب کاربری")

    try {
      const result = await this.makeRequest("create_admin", data)
      this.hideLoading()

      if (result.success) {
        this.showAlert("success", "کاربر مدیر ایجاد شد")
        setTimeout(() => this.nextStep("install"), 1500)
      } else {
        this.showAlert("danger", result.message)
      }
    } catch (error) {
      this.hideLoading()
      this.showAlert("danger", "خطا در ایجاد کاربر مدیر")
    }
  }

  async startInstallation() {
    const logContainer = document.getElementById("installation-log")
    const progressBar = document.querySelector(".progress-bar")

    this.addLogEntry("شروع نصب Mitra Global CMS...", "info")

    try {
      // نصب پایگاه داده
      this.addLogEntry("نصب پایگاه داده...", "info")
      progressBar.style.width = "20%"

      const dbResult = await this.makeRequest("install_database")
      if (!dbResult.success) {
        this.addLogEntry(`خطا در نصب پایگاه داده: ${dbResult.message}`, "error")
        return
      }
      this.addLogEntry("پایگاه داده نصب شد ✓", "success")
      progressBar.style.width = "60%"

      // تنظیمات نهایی
      this.addLogEntry("تنظیمات نهایی...", "info")
      progressBar.style.width = "80%"

      const finalResult = await this.makeRequest("finalize")
      if (!finalResult.success) {
        this.addLogEntry(`خطا در تنظیمات نهایی: ${finalResult.message}`, "error")
        return
      }

      this.addLogEntry("نصب با موفقیت تکمیل شد! ✓", "success")
      progressBar.style.width = "100%"

      setTimeout(() => {
        window.location.href = "?step=complete"
      }, 2000)
    } catch (error) {
      this.addLogEntry(`خطای غیرمنتظره: ${error.message}`, "error")
    }
  }

  addLogEntry(message, type = "info") {
    const logContainer = document.getElementById("installation-log")
    if (!logContainer) return

    const timestamp = new Date().toLocaleTimeString("fa-IR")
    const entry = document.createElement("div")
    entry.className = `log-entry ${type}`
    entry.textContent = `[${timestamp}] ${message}`

    logContainer.appendChild(entry)
    logContainer.scrollTop = logContainer.scrollHeight
  }
}

// Initialize installer when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new MitraInstaller()
})
