<div class="text-center">
    <h1 class="display-5"><?= $title ?></h1>
    <p class="lead"><?= $subtitle ?></p>
    <a href="#" class="btn btn-primary btn-lg mt-3">شروع کنید</a>
</div>
