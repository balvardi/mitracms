</main>
<footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
        <small>&copy; <?= date('Y') ?> Mitra Global CMS – built with PHP, MySQL & Bootstrap.</small>
    </div>
</footer>
</body>
</html>
