<?php
/**
 * Single-entry front-controller.
 */
require_once __DIR__ . '/core/Router.php';
require_once __DIR__ . '/controllers/HomeController.php';

$router = new Router();
$router->get('/', [new HomeController(), 'index']);

/* --------- add more routes here ---------- */
/*
$router->get('/products', [new ProductController(), 'list']);
$router->post('/checkout', [new CheckoutController(), 'process']);
*/

$router->dispatch();
