<?php

namespace Modules\Ecommerce\Controllers;

use App\Core\Controller;
use App\Core\Security;
use Modules\Ecommerce\Models\Order;
use Modules\Ecommerce\Models\Product;
use Modules\Ecommerce\Services\ZarinpalService;
use Modules\UserManagement\Models\Role;

class CheckoutController extends Controller
{
    private $orderModel;
    private $productModel;
    private $zarinpalService;
    private $security;
    private $roleModel;

    public function __construct()
    {
        parent::__construct();
        $this->orderModel = new Order();
        $this->productModel = new Product();
        $this->security = Security::getInstance();
        $this->roleModel = new Role();
        
        // Initialize Zarinpal service
        $merchantId = $_ENV['ZARINPAL_MERCHANT_ID'] ?? '';
        $sandbox = $_ENV['ZARINPAL_SANDBOX'] ?? false;
        $this->zarinpalService = new ZarinpalService($merchantId, $sandbox);
    }

    public function index()
    {
        // Check user permissions
        if (!$this->checkPermission('ecommerce.view')) {
            return $this->unauthorized();
        }

        // Rate limiting
        $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        if (!$this->security->checkRateLimit("checkout_{$clientIp}", 10, 300)) {
            return $this->error('Too many requests. Please try again later.', 429);
        }

        $cartItems = $this->getCartItems();
        
        if (empty($cartItems)) {
            return $this->redirect('/cart');
        }

        $data = [
            'cart_items' => $cartItems,
            'total' => $this->calculateTotal($cartItems),
            'csrf_token' => $this->security->generateCSRFToken('checkout')
        ];

        return $this->view('ecommerce.checkout', $data);
    }

    public function process()
    {
        try {
            // Verify CSRF token
            $csrfToken = $_POST['csrf_token'] ?? '';
            if (!$this->security->verifyCSRFToken($csrfToken, 'checkout')) {
                throw new \Exception('Invalid CSRF token');
            }

            // Rate limiting
            $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            if (!$this->security->checkRateLimit("checkout_process_{$clientIp}", 5, 300)) {
                return $this->error('Too many requests. Please try again later.', 429);
            }

            // Validate and sanitize input
            $input = $this->validateCheckoutInput($_POST);
            
            // Get cart items
            $cartItems = $this->getCartItems();
            if (empty($cartItems)) {
                throw new \Exception('Cart is empty');
            }

            // Verify stock availability
            $this->verifyStockAvailability($cartItems);

            // Calculate totals
            $totals = $this->calculateTotals($cartItems, $input);

            // Create order
            $orderData = [
                'user_id' => $this->getCurrentUserId(),
                'total_amount' => $totals['total'],
                'tax_amount' => $totals['tax'],
                'shipping_amount' => $totals['shipping'],
                'discount_amount' => $totals['discount'],
                'payment_method' => 'zarinpal',
                'billing_address' => $input['billing_address'],
                'shipping_address' => $input['shipping_address'],
                'notes' => $input['notes'] ?? ''
            ];

            $orderId = $this->orderModel->create($orderData);
            $order = $this->orderModel->find($orderId);

            // Add order items
            $this->orderModel->addOrderItems($orderId, $cartItems);

            // Process payment with Zarinpal
            $paymentData = [
                'amount' => $totals['total'] * 10, // Convert to Rials
                'description' => "پرداخت سفارش شماره {$order['order_number']}",
                'callback_url' => $this->getBaseUrl() . '/checkout/callback',
                'email' => $input['billing_address']['email'] ?? '',
                'mobile' => $input['billing_address']['phone'] ?? ''
            ];

            $paymentResult = $this->zarinpalService->requestPayment($paymentData);

            if ($paymentResult['success']) {
                // Store payment info in session
                $_SESSION['payment_order_id'] = $orderId;
                $_SESSION['payment_authority'] = $paymentResult['authority'];
                $_SESSION['payment_amount'] = $totals['total'];

                // Log security event
                $this->security->logSecurityEvent('checkout_initiated', [
                    'order_id' => $orderId,
                    'amount' => $totals['total'],
                    'user_id' => $this->getCurrentUserId()
                ]);

                return $this->redirect($paymentResult['payment_url']);
            } else {
                throw new \Exception('Payment gateway error: ' . $paymentResult['error']);
            }

        } catch (\Exception $e) {
            $this->security->logSecurityEvent('checkout_error', [
                'error' => $e->getMessage(),
                'user_id' => $this->getCurrentUserId()
            ]);

            return $this->error($e->getMessage());
        }
    }

    public function callback()
    {
        try {
            $authority = $_GET['Authority'] ?? '';
            $status = $_GET['Status'] ?? '';

            if ($status !== 'OK' || empty($authority)) {
                throw new \Exception('Payment was cancelled or failed');
            }

            // Verify session data
            $orderId = $_SESSION['payment_order_id'] ?? null;
            $sessionAuthority = $_SESSION['payment_authority'] ?? '';
            $amount = $_SESSION['payment_amount'] ?? 0;

            if (!$orderId || $authority !== $sessionAuthority) {
                throw new \Exception('Invalid payment session');
            }

            // Verify payment with Zarinpal
            $verificationResult = $this->zarinpalService->verifyPayment($authority, $amount * 10);

            if ($verificationResult['success']) {
                // Update order status
                $this->orderModel->updatePaymentStatus($orderId, 'paid', $verificationResult['ref_id']);
                $this->orderModel->updateStatus($orderId, 'processing');

                // Update product stock
                $order = $this->orderModel->find($orderId);
                $orderItems = $this->orderModel->getOrderItems($orderId);
                
                foreach ($orderItems as $item) {
                    $this->productModel->updateStock($item['product_id'], $item['quantity']);
                }

                // Clear cart
                $this->clearCart();

                // Clear payment session
                unset($_SESSION['payment_order_id']);
                unset($_SESSION['payment_authority']);
                unset($_SESSION['payment_amount']);

                // Log successful payment
                $this->security->logSecurityEvent('payment_success', [
                    'order_id' => $orderId,
                    'ref_id' => $verificationResult['ref_id'],
                    'amount' => $amount,
                    'user_id' => $this->getCurrentUserId()
                ]);

                return $this->view('ecommerce.payment-success', [
                    'order' => $order,
                    'ref_id' => $verificationResult['ref_id']
                ]);

            } else {
                // Update order status to failed
                $this->orderModel->updatePaymentStatus($orderId, 'failed');

                throw new \Exception('Payment verification failed: ' . $verificationResult['error']);
            }

        } catch (\Exception $e) {
            $this->security->logSecurityEvent('payment_error', [
                'error' => $e->getMessage(),
                'authority' => $authority ?? '',
                'user_id' => $this->getCurrentUserId()
            ]);

            return $this->view('ecommerce.payment-error', [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function validateCheckoutInput(array $input): array
    {
        $rules = [
            'billing_address.first_name' => 'required|min:2|max:50',
            'billing_address.last_name' => 'required|min:2|max:50',
            'billing_address.email' => 'required|email',
            'billing_address.phone' => 'required|regex:/^09\d{9}$/',
            'billing_address.address' => 'required|min:10|max:500',
            'billing_address.city' => 'required|min:2|max:100',
            'billing_address.postal_code' => 'required|regex:/^\d{10}$/',
            'payment_method' => 'required'
        ];

        $errors = $this->security->validateInput($input, $rules);
        
        if (!empty($errors)) {
            throw new \InvalidArgumentException('Validation failed: ' . implode(', ', array_flatten($errors)));
        }

        // Sanitize input
        $sanitized = [];
        $sanitized['billing_address'] = [
            'first_name' => $this->security->sanitizeInput($input['billing_address']['first_name']),
            'last_name' => $this->security->sanitizeInput($input['billing_address']['last_name']),
            'email' => $this->security->sanitizeInput($input['billing_address']['email'], 'email'),
            'phone' => $this->security->sanitizeInput($input['billing_address']['phone']),
            'address' => $this->security->sanitizeInput($input['billing_address']['address']),
            'city' => $this->security->sanitizeInput($input['billing_address']['city']),
            'postal_code' => $this->security->sanitizeInput($input['billing_address']['postal_code'])
        ];

        // Use billing address as shipping if not provided
        $sanitized['shipping_address'] = $input['shipping_address'] ?? $sanitized['billing_address'];
        $sanitized['notes'] = $this->security->sanitizeInput($input['notes'] ?? '');

        return $sanitized;
    }

    private function verifyStockAvailability(array $cartItems): void
    {
        foreach ($cartItems as $item) {
            $product = $this->productModel->find($item['product_id']);
            
            if (!$product) {
                throw new \Exception("Product not found: {$item['product_id']}");
            }

            if ($product['manage_stock'] && $product['stock_quantity'] < $item['quantity']) {
                throw new \Exception("Insufficient stock for product: {$product['name']}");
            }
        }
    }

    private function calculateTotals(array $cartItems, array $input): array
    {
        $subtotal = 0;
        
        foreach ($cartItems as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }

        $tax = $subtotal * 0.09; // 9% tax
        $shipping = $this->calculateShipping($input['shipping_address']);
        $discount = 0; // TODO: Implement coupon system
        $total = $subtotal + $tax + $shipping - $discount;

        return [
            'subtotal' => $subtotal,
            'tax' => $tax,
            'shipping' => $shipping,
            'discount' => $discount,
            'total' => $total
        ];
    }

    private function calculateShipping(array $address): float
    {
        // Simple shipping calculation - can be enhanced
        $baseShipping = 50000; // 50,000 Rials base shipping
        
        // Free shipping for orders over 500,000 Rials
        $cartTotal = $this->calculateCartTotal();
        if ($cartTotal > 500000) {
            return 0;
        }

        return $baseShipping;
    }

    private function getCartItems(): array
    {
        $sessionId = session_id();
        $userId = $this->getCurrentUserId();

        $sql = "SELECT ci.*, p.name, p.price, p.stock_quantity, p.manage_stock 
                FROM cart_items ci 
                JOIN products p ON ci.product_id = p.id 
                WHERE ci.session_id = ? OR ci.user_id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$sessionId, $userId]);
        
        return $stmt->fetchAll();
    }

    private function calculateCartTotal(): float
    {
        $cartItems = $this->getCartItems();
        $total = 0;
        
        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        
        return $total;
    }

    private function clearCart(): void
    {
        $sessionId = session_id();
        $userId = $this->getCurrentUserId();

        $sql = "DELETE FROM cart_items WHERE session_id = ? OR user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$sessionId, $userId]);
    }

    private function checkPermission(string $permission): bool
    {
        $userId = $this->getCurrentUserId();
        if (!$userId) {
            return false;
        }

        return $this->roleModel->hasPermission($userId, $permission);
    }

    private function getCurrentUserId(): ?int
    {
        return $_SESSION['user_id'] ?? null;
    }

    private function getBaseUrl(): string
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $protocol . '://' . $host;
    }
}
