#!/usr/bin/env bash
# ------------------------------------------------------------------
#  Mitra Global CMS – unattended installer (Ubuntu / Debian)
# ------------------------------------------------------------------
set -euo pipefail

# ──────────────────────────────────────────────────────────────────
#  Config – edit to your liking
# ──────────────────────────────────────────────────────────────────
PHP_VERSION="8.1"
CMS_DIR="/var/www/mitracms"
DB_NAME="mitracms"
DB_USER="mitracms_user"
DB_PASS="$(openssl rand -hex 12)"
ADMIN_EMAIL="admin@example.com"
ADMIN_PASS="$(openssl rand -hex 12)"
DOMAIN="example.com"          # used for Apache vhost
# ------------------------------------------------------------------

color() { printf "\033[%sm%s\033[0m\n" "$1" "$2"; }
step()   { color "1;34" "▶ $*"; }
ok()     { color "1;32" "✓ $*"; }

require_root() {
  if [[ $EUID -ne 0 ]]; then
    color "1;31" "This script must be run as root."; exit 1
  fi
}

update_system() {
  step "Updating package lists…"
  apt-get update -qq
  ok "Packages updated."
}

install_prereqs() {
  step "Installing prerequisites (Apache, PHP, MySQL, Composer)…"
  # PHP PPA
  add-apt-repository ppa:ondrej/php -y >/dev/null 2>&1
  apt-get update -qq

  apt-get install -y \
    apache2 libapache2-mod-php${PHP_VERSION} \
    php${PHP_VERSION}-{cli,common,mbstring,xml,gd,zip,bcmath,curl,mysql,tokenizer,ctype,fileinfo,openssl} \
    mysql-server unzip git curl > /dev/null

  curl -sS https://getcomposer.org/installer | php -- --quiet
  mv composer.phar /usr/local/bin/composer
  chmod +x /usr/local/bin/composer
  ok "Prerequisites installed."
}

secure_mysql() {
  step "Configuring MySQL & creating database/user…"
  systemctl enable --now mysql

  mysql -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
  mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
  mysql -e "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';"
  mysql -e "FLUSH PRIVILEGES;"
  ok "Database ${DB_NAME} and user ${DB_USER} created."
}

fetch_cms() {
  step "Fetching Mitra CMS source…"
  mkdir -p "${CMS_DIR}"
  git clone --depth=1 https://github.com/balvardi/mitracms.git "${CMS_DIR}" >/dev/null 2>&1
  cd "${CMS_DIR}"
  composer install --no-dev --optimize-autoloader --quiet
  ok "CMS files installed to ${CMS_DIR}."
}

configure_cms() {
  step "Setting up CMS configuration…"
  cp config/app.example.php      config/app.php
  cp config/database.example.php config/database.php

  sed -i "s/'database' => '.*'/'database' => '${DB_NAME}'/g"     config/database.php
  sed -i "s/'username' => '.*'/'username' => '${DB_USER}'/g"     config/database.php
  sed -i "s/'password' => ''/'password' => '${DB_PASS}'/g"       config/database.php
  sed -i "s|'url' => 'http://localhost'|'url' => 'https://${DOMAIN}'|g" config/app.php
  sed -i "s/'debug' => true/'debug' => false/g"                  config/app.php
  sed -i "s/'key' => ''/'key' => '$(openssl rand -base64 32)'/g" config/app.php
  ok "Configuration files updated."
}

permissions() {
  step "Adjusting file permissions…"
  chown -R www-data:www-data "${CMS_DIR}"
  find  "${CMS_DIR}" -type f -exec chmod 644 {} \;
  find  "${CMS_DIR}" -type d -exec chmod 755 {} \;
  chmod -R 755 "${CMS_DIR}/storage" "${CMS_DIR}/public/uploads"
  ok "Permissions set."
}

apache_vhost() {
  step "Configuring Apache virtual host…"
  cat >/etc/apache2/sites-available/mitracms.conf <<EOF
<VirtualHost *:80>
  ServerName ${DOMAIN}
  DocumentRoot ${CMS_DIR}/public

  <Directory ${CMS_DIR}/public>
    AllowOverride All
    Require all granted
  </Directory>

  ErrorLog \${APACHE_LOG_DIR}/mitracms_error.log
  CustomLog \${APACHE_LOG_DIR}/mitracms_access.log combined
</VirtualHost>
EOF
  a2enmod rewrite >/dev/null
  a2ensite mitracms.conf >/dev/null
  a2dissite 000-default.conf >/dev/null
  systemctl reload apache2
  ok "Apache configured for ${DOMAIN}."
}

init_db() {
  step "Running migrations & seeding sample data…"
  cd "${CMS_DIR}"
  php artisan migrate --force
  php artisan db:seed --force
  php artisan admin:create --email="${ADMIN_EMAIL}" --password="${ADMIN_PASS}" --force
  ok "Database ready & admin user created."
}

summary() {
  echo
  color "1;32" "────────────────────────────────────────────────────────────"
  color "1;32" "  Mitra Global CMS installed successfully! 🎉"
  color "1;32" "────────────────────────────────────────────────────────────"
  echo
  echo " Site URL    : http://${DOMAIN}"
  echo " Admin Panel : http://${DOMAIN}/admin"
  echo " ── Admin login ──────────────"
  echo "   Email     : ${ADMIN_EMAIL}"
  echo "   Password  : ${ADMIN_PASS}"
  echo
  echo " Database    : ${DB_NAME}"
  echo " DB User     : ${DB_USER}"
  echo " DB Pass     : ${DB_PASS}"
  echo
  echo " Files located at: ${CMS_DIR}"
  echo " Enjoy! – Mitra CMS Team"
}

main() {
  require_root
  update_system
  install_prereqs
  secure_mysql
  fetch_cms
  configure_cms
  permissions
  apache_vhost
  init_db
  summary
}

main "$@"
