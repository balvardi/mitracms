<?php
/**
 * تنظیمات اصلی اپلیکیشن
 */

return [
    // اطلاعات اصلی سایت
    'name' => 'Mitra Global CMS',
    'description' => 'سیستم مدیریت محتوای قدرتمند و ماژولار',
    'url' => 'http://localhost',
    'version' => '1.0.0',
    
    // تنظیمات زبان و منطقه
    'locale' => 'fa',
    'timezone' => 'Asia/Tehran',
    'charset' => 'UTF-8',
    
    // تنظیمات امنیتی
    'key' => '', // کلید رمزگذاری - در نصب تولید می‌شود
    'debug' => false,
    'maintenance' => false,
    
    // تنظیمات کش
    'cache' => [
        'enabled' => true,
        'driver' => 'file',
        'ttl' => 3600
    ],
    
    // تنظیمات جلسه
    'session' => [
        'driver' => 'file',
        'lifetime' => 120,
        'cookie_name' => 'mitracms_session'
    ],
    
    // تنظیمات ایمیل
    'mail' => [
        'driver' => 'smtp',
        'host' => 'localhost',
        'port' => 587,
        'username' => '',
        'password' => '',
        'encryption' => 'tls',
        'from' => [
            'address' => 'noreply@example.com',
            'name' => 'Mitra Global CMS'
        ]
    ],
    
    // تنظیمات آپلود
    'upload' => [
        'max_size' => '10M',
        'allowed_types' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'],
        'path' => 'public/uploads'
    ],
    
    // تنظیمات SEO
    'seo' => [
        'sitemap_enabled' => true,
        'robots_enabled' => true,
        'meta_generator' => true
    ]
];
