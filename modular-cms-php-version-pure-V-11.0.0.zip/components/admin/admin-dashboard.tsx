"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { FileText, Users, Package, Palette, Plus, Edit, Trash2 } from "lucide-react"

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")

  const stats = [
    { title: "Total Pages", value: "24", icon: FileText, color: "text-blue-600" },
    { title: "Active Users", value: "156", icon: Users, color: "text-green-600" },
    { title: "Installed Modules", value: "8", icon: Package, color: "text-purple-600" },
    { title: "Templates", value: "12", icon: Palette, color: "text-orange-600" },
  ]

  const recentPages = [
    { title: "Home Page", status: "Published", lastModified: "2 hours ago" },
    { title: "About Us", status: "Draft", lastModified: "1 day ago" },
    { title: "Contact", status: "Published", lastModified: "3 days ago" },
  ]

  const installedModules = [
    { name: "Blog Module", version: "1.2.0", status: "Active" },
    { name: "Gallery Module", version: "2.1.0", status: "Active" },
    { name: "Contact Form", version: "1.0.5", status: "Inactive" },
    { name: "SEO Tools", version: "3.0.0", status: "Active" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600">Manage your ModularCMS installation</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="pages">Pages</TabsTrigger>
            <TabsTrigger value="modules">Modules</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    <stat.icon className={`h-4 w-4 ${stat.color}`} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.value}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Pages</CardTitle>
                  <CardDescription>Latest content updates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentPages.map((page, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{page.title}</p>
                          <p className="text-sm text-gray-500">{page.lastModified}</p>
                        </div>
                        <Badge variant={page.status === "Published" ? "default" : "secondary"}>{page.status}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Status</CardTitle>
                  <CardDescription>Current system information</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>CMS Version</span>
                      <Badge>v2.1.0</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Database</span>
                      <Badge variant="outline">Connected</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Cache</span>
                      <Badge variant="outline">Enabled</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>SEO</span>
                      <Badge variant="outline">Optimized</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="pages" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Content Pages</h2>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Page
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="divide-y">
                  {recentPages.map((page, index) => (
                    <div key={index} className="p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <FileText className="w-5 h-5 text-gray-400" />
                        <div>
                          <p className="font-medium">{page.title}</p>
                          <p className="text-sm text-gray-500">Modified {page.lastModified}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={page.status === "Published" ? "default" : "secondary"}>{page.status}</Badge>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="modules" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Installed Modules</h2>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Install Module
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {installedModules.map((module, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{module.name}</CardTitle>
                      <Badge variant={module.status === "Active" ? "default" : "secondary"}>{module.status}</Badge>
                    </div>
                    <CardDescription>Version {module.version}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                      <Button variant="outline" size="sm">
                        {module.status === "Active" ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Template Management</h2>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Upload Template
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Default Theme</CardTitle>
                  <CardDescription>Clean and modern design</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gray-100 rounded-lg mb-4"></div>
                  <div className="flex space-x-2">
                    <Button size="sm">Active</Button>
                    <Button variant="outline" size="sm">
                      Customize
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Business Pro</CardTitle>
                  <CardDescription>Professional business template</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gray-100 rounded-lg mb-4"></div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      Activate
                    </Button>
                    <Button variant="outline" size="sm">
                      Preview
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-xl font-semibold">System Settings</h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>General Settings</CardTitle>
                  <CardDescription>Basic site configuration</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Site Title</label>
                    <input
                      type="text"
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                      defaultValue="ModularCMS"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Site Description</label>
                    <textarea
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                      rows={3}
                      defaultValue="A modern content management system"
                    />
                  </div>
                  <Button>Save Changes</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>SEO Settings</CardTitle>
                  <CardDescription>Search engine optimization</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Meta Keywords</label>
                    <input
                      type="text"
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                      defaultValue="cms, content management, modular"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Google Analytics ID</label>
                    <input
                      type="text"
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="GA-XXXXXXXXX-X"
                    />
                  </div>
                  <Button>Update SEO</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
