<?php
session_start();

// بررسی نصب
if (!file_exists('.installed')) {
    header('Location: install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
$dbConfig = [];
if (file_exists('config/database.php')) {
    $dbConfig = require 'config/database.php';
}

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        return $pdo;
    } catch (PDOException $e) {
        die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
    }
}

$action = $_GET['action'] ?? 'login';
$message = '';
$error = '';

// پردازش فرم ورود
if ($_POST && $action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'لطفاً نام کاربری و رمز عبور را وارد کنید';
    } else {
        try {
            $pdo = getDatabase();
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && isset($user['password']) && !empty($user['password']) && password_verify($password, $user['password'])) {
                if ($user['status'] === 'active') {
                    $_SESSION['logged_in'] = true;
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['first_name'] = $user['first_name'];
                    $_SESSION['last_name'] = $user['last_name'];
                    
                    // بروزرسانی زمان آخرین ورود
                    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $stmt->execute([$user['id']]);
                    
                    // هدایت به صفحه مناسب
                    $redirect = $_GET['redirect'] ?? '';
                    if (!empty($redirect)) {
                        header('Location: ' . $redirect);
                    } elseif (in_array($user['role'], ['admin', 'editor'])) {
                        header('Location: admin/');
                    } else {
                        header('Location: dashboard.php');
                    }
                    exit;
                } else {
                    $error = 'حساب کاربری شما غیرفعال است';
                }
            } else {
                $error = 'نام کاربری یا رمز عبور اشتباه است';
            }
        } catch (PDOException $e) {
            $error = 'خطا در ورود: ' . $e->getMessage();
        }
    }
}

// پردازش فرم ثبت نام
if ($_POST && $action === 'register') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    
    if (empty($username) || empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
        $error = 'لطفاً تمام فیلدها را پر کنید';
    } elseif ($password !== $confirm_password) {
        $error = 'رمز عبور و تکرار آن یکسان نیستند';
    } elseif (strlen($password) < 6) {
        $error = 'رمز عبور باید حداقل 6 کاراکتر باشد';
    } else {
        try {
            $pdo = getDatabase();
            
            // بررسی تکراری نبودن نام کاربری و ایمیل
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetchColumn() > 0) {
                $error = 'نام کاربری یا ایمیل قبلاً استفاده شده است';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, first_name, last_name, role, status) VALUES (?, ?, ?, ?, ?, 'user', 'active')");
                
                if ($stmt->execute([$username, $email, $hashedPassword, $first_name, $last_name])) {
                    $message = 'ثبت نام با موفقیت انجام شد. اکنون می‌توانید وارد شوید.';
                    $action = 'login';
                } else {
                    $error = 'خطا در ثبت نام';
                }
            }
        } catch (PDOException $e) {
            $error = 'خطا در ثبت نام: ' . $e->getMessage();
        }
    }
}

// اگر کاربر وارد شده است، هدایت به داشبورد
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    if (in_array($_SESSION['role'], ['admin', 'editor'])) {
        header('Location: admin/');
    } else {
        header('Location: dashboard.php');
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $action === 'register' ? 'ثبت نام' : 'ورود' ?> - Mitra CMS</title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
    <style>
        * { font-family: "Vazirmatn", sans-serif; }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .auth-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .auth-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .auth-body {
            padding: 2rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px 30px;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="auth-header">
                        <h2 class="mb-0"><?php echo $action === 'register' ? 'ثبت نام' : 'ورود به سیستم' ?></h2>
                        <p class="mb-0 mt-2">Mitra CMS</p>
                    </div>
                    
                    <div class="auth-body">
                        <?php if ($message): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($message) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($action === 'login'): ?>
                            <!-- فرم ورود -->
                            <form method="post">
                                <div class="mb-3">
                                    <label class="form-label">نام کاربری یا ایمیل</label>
                                    <input type="text" class="form-control" name="username" required 
                                           value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">ورود</button>
                                </div>
                            </form>
                            
                            <hr>
                            <div class="text-center">
                                <p>حساب کاربری ندارید؟ <a href="?action=register">ثبت نام کنید</a></p>
                                <a href="index.php" class="text-muted">بازگشت به صفحه اصلی</a>
                            </div>
                            
                        <?php else: ?>
                            <!-- فرم ثبت نام -->
                            <form method="post">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">نام</label>
                                            <input type="text" class="form-control" name="first_name" required
                                                   value="<?php echo htmlspecialchars($_POST['first_name'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">نام خانوادگی</label>
                                            <input type="text" class="form-control" name="last_name" required
                                                   value="<?php echo htmlspecialchars($_POST['last_name'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" name="username" required
                                           value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" name="email" required
                                           value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">تکرار رمز عبور</label>
                                    <input type="password" class="form-control" name="confirm_password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">ثبت نام</button>
                                </div>
                            </form>
                            
                            <hr>
                            <div class="text-center">
                                <p>قبلاً ثبت نام کرده‌اید؟ <a href="?action=login">وارد شوید</a></p>
                                <a href="index.php" class="text-muted">بازگشت به صفحه اصلی</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
