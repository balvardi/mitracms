<?php

namespace Modules\FormBuilder\Models;

use App\Core\Model;
use App\Core\Database;

class Form extends Model
{
    protected $table = 'forms';
    protected $fillable = [
        'title', 'slug', 'description', 'fields', 'settings', 'status',
        'submit_button_text', 'success_message', 'email_notifications',
        'redirect_url', 'created_by'
    ];

    protected $casts = [
        'fields' => 'json',
        'settings' => 'json',
        'email_notifications' => 'json'
    ];

    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
    }

    public function create(array $data): int
    {
        $data = $this->validateFormData($data);
        
        $sql = "INSERT INTO {$this->table} (
            title, slug, description, fields, settings, status,
            submit_button_text, success_message, email_notifications,
            redirect_url, created_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $data['title'],
            $data['slug'],
            $data['description'] ?? '',
            json_encode($data['fields']),
            json_encode($data['settings'] ?? []),
            $data['status'] ?? 'active',
            $data['submit_button_text'] ?? 'ارسال',
            $data['success_message'] ?? 'فرم با موفقیت ارسال شد',
            json_encode($data['email_notifications'] ?? []),
            $data['redirect_url'] ?? null,
            $data['created_by']
        ]);

        return $this->db->lastInsertId();
    }

    public function findBySlug(string $slug): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE slug = ? AND status = 'active'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$slug]);
        
        $form = $stmt->fetch();
        if ($form) {
            $form['fields'] = json_decode($form['fields'], true);
            $form['settings'] = json_decode($form['settings'], true);
            $form['email_notifications'] = json_decode($form['email_notifications'], true);
        }
        
        return $form ?: null;
    }

    public function submitForm(int $formId, array $data, ?int $userId = null): int
    {
        // Get form configuration
        $form = $this->find($formId);
        if (!$form) {
            throw new \Exception('Form not found');
        }

        $form['fields'] = json_decode($form['fields'], true);
        
        // Validate submission data
        $validatedData = $this->validateSubmissionData($form['fields'], $data);
        
        // Store submission
        $sql = "INSERT INTO form_submissions (
            form_id, user_id, data, ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $formId,
            $userId,
            json_encode($validatedData),
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        $submissionId = $this->db->lastInsertId();

        // Send email notifications if configured
        $this->sendEmailNotifications($form, $validatedData);

        return $submissionId;
    }

    public function getSubmissions(int $formId, int $limit = 50, int $offset = 0): array
    {
        $sql = "SELECT fs.*, u.email as user_email 
                FROM form_submissions fs 
                LEFT JOIN users u ON fs.user_id = u.id 
                WHERE fs.form_id = ? 
                ORDER BY fs.created_at DESC 
                LIMIT ? OFFSET ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$formId, $limit, $offset]);
        
        $submissions = $stmt->fetchAll();
        
        foreach ($submissions as &$submission) {
            $submission['data'] = json_decode($submission['data'], true);
        }
        
        return $submissions;
    }

    private function validateFormData(array $data): array
    {
        // Required fields
        if (empty($data['title'])) {
            throw new \InvalidArgumentException('Form title is required');
        }

        if (empty($data['fields']) || !is_array($data['fields'])) {
            throw new \InvalidArgumentException('Form fields are required');
        }

        // Sanitize title
        $data['title'] = htmlspecialchars(trim($data['title']), ENT_QUOTES, 'UTF-8');
        
        // Generate slug if not provided
        if (empty($data['slug'])) {
            $data['slug'] = $this->generateSlug($data['title']);
        }

        // Validate fields
        $data['fields'] = $this->validateFields($data['fields']);

        return $data;
    }

    private function validateFields(array $fields): array
    {
        $validatedFields = [];
        $allowedTypes = [
            'text', 'email', 'tel', 'number', 'textarea', 'select', 
            'radio', 'checkbox', 'file', 'date', 'time', 'datetime'
        ];

        foreach ($fields as $field) {
            if (empty($field['type']) || !in_array($field['type'], $allowedTypes)) {
                throw new \InvalidArgumentException('Invalid field type');
            }

            if (empty($field['name']) || !preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $field['name'])) {
                throw new \InvalidArgumentException('Invalid field name');
            }

            $validatedField = [
                'type' => $field['type'],
                'name' => $field['name'],
                'label' => htmlspecialchars($field['label'] ?? '', ENT_QUOTES, 'UTF-8'),
                'placeholder' => htmlspecialchars($field['placeholder'] ?? '', ENT_QUOTES, 'UTF-8'),
                'required' => (bool)($field['required'] ?? false),
                'validation' => $field['validation'] ?? [],
                'options' => $field['options'] ?? [],
                'attributes' => $field['attributes'] ?? []
            ];

            $validatedFields[] = $validatedField;
        }

        return $validatedFields;
    }

    private function validateSubmissionData(array $fields, array $data): array
    {
        $validatedData = [];

        foreach ($fields as $field) {
            $fieldName = $field['name'];
            $value = $data[$fieldName] ?? null;

            // Check required fields
            if ($field['required'] && empty($value)) {
                throw new \InvalidArgumentException("Field {$field['label']} is required");
            }

            // Skip validation if field is empty and not required
            if (empty($value) && !$field['required']) {
                continue;
            }

            // Validate based on field type
            $validatedValue = $this->validateFieldValue($field, $value);
            $validatedData[$fieldName] = $validatedValue;
        }

        return $validatedData;
    }

    private function validateFieldValue(array $field, $value)
    {
        switch ($field['type']) {
            case 'email':
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    throw new \InvalidArgumentException("Invalid email format for {$field['label']}");
                }
                return filter_var($value, FILTER_SANITIZE_EMAIL);

            case 'tel':
                $cleaned = preg_replace('/[^0-9+\-\s]/', '', $value);
                if (strlen($cleaned) < 10) {
                    throw new \InvalidArgumentException("Invalid phone number for {$field['label']}");
                }
                return $cleaned;

            case 'number':
                if (!is_numeric($value)) {
                    throw new \InvalidArgumentException("Invalid number format for {$field['label']}");
                }
                return (float)$value;

            case 'date':
                $date = \DateTime::createFromFormat('Y-m-d', $value);
                if (!$date) {
                    throw new \InvalidArgumentException("Invalid date format for {$field['label']}");
                }
                return $value;

            case 'select':
            case 'radio':
                if (!in_array($value, array_column($field['options'], 'value'))) {
                    throw new \InvalidArgumentException("Invalid option selected for {$field['label']}");
                }
                return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');

            case 'checkbox':
                if (!is_array($value)) {
                    $value = [$value];
                }
                $validOptions = array_column($field['options'], 'value');
                foreach ($value as $v) {
                    if (!in_array($v, $validOptions)) {
                        throw new \InvalidArgumentException("Invalid checkbox option for {$field['label']}");
                    }
                }
                return array_map(function($v) {
                    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
                }, $value);

            case 'file':
                // File validation would be handled separately in file upload process
                return $value;

            default:
                // Text, textarea, etc.
                return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
    }

    private function sendEmailNotifications(array $form, array $data): void
    {
        $notifications = $form['email_notifications'] ?? [];
        
        if (empty($notifications['enabled'])) {
            return;
        }

        $recipients = $notifications['recipients'] ?? [];
        if (empty($recipients)) {
            return;
        }

        $subject = $notifications['subject'] ?? "New form submission: {$form['title']}";
        $message = $this->buildEmailMessage($form, $data);

        foreach ($recipients as $email) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // Use your email service here
                mail($email, $subject, $message, [
                    'From' => 'noreply@' . $_SERVER['HTTP_HOST'],
                    'Content-Type' => 'text/html; charset=UTF-8'
                ]);
            }
        }
    }

    private function buildEmailMessage(array $form, array $data): string
    {
        $html = "<h2>New Form Submission: {$form['title']}</h2>";
        $html .= "<table border='1' cellpadding='10' cellspacing='0'>";
        
        foreach ($data as $field => $value) {
            $html .= "<tr>";
            $html .= "<td><strong>" . htmlspecialchars($field) . "</strong></td>";
            $html .= "<td>" . (is_array($value) ? implode(', ', $value) : htmlspecialchars($value)) . "</td>";
            $html .= "</tr>";
        }
        
        $html .= "</table>";
        $html .= "<p>Submitted at: " . date('Y-m-d H:i:s') . "</p>";
        
        return $html;
    }

    private function generateSlug(string $title): string
    {
        $slug = strtolower(trim($title));
        $slug = preg_replace('/[^a-z0-9\-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');
        
        // Ensure uniqueness
        $originalSlug = $slug;
        $counter = 1;
        
        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }

    private function slugExists(string $slug): bool
    {
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE slug = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$slug]);
        
        return $stmt->fetchColumn() > 0;
    }
}
