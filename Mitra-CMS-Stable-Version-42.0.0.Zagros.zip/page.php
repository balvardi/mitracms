<?php
session_start();

// بررسی نصب
if (!file_exists('.installed')) {
    header('Location: install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
$dbConfig = [];
if (file_exists('config/database.php')) {
    $dbConfig = require 'config/database.php';
}

$appConfig = [];
if (file_exists('config/app.php')) {
    $appConfig = require 'config/app.php';
}

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        return $pdo;
    } catch (PDOException $e) {
        die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
    }
}

$slug = $_GET['slug'] ?? '';
if (empty($slug)) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = getDatabase();
    
    // دریافت تنظیمات سایت
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE group_name = 'general'");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    
    // دریافت صفحه
    $stmt = $pdo->prepare("
        SELECT p.*, u.first_name, u.last_name 
        FROM pages p 
        LEFT JOIN users u ON p.author_id = u.id 
        WHERE p.slug = ? AND p.status = 'published'
    ");
    $stmt->execute([$slug]);
    $page = $stmt->fetch();
    
    if (!$page) {
        http_response_code(404);
        die('صفحه یافت نشد');
    }
    
    $siteName = $settings['site_name'] ?? 'Mitra CMS';
    
} catch (PDOException $e) {
    die('خطا در بارگذاری صفحه: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page['meta_title'] ?: $page['title']) ?> - <?php echo htmlspecialchars($siteName) ?></title>
    <?php if ($page['meta_description']): ?>
        <meta name="description" content="<?php echo htmlspecialchars($page['meta_description']) ?>">
    <?php endif; ?>
    <?php if ($page['meta_keywords']): ?>
        <meta name="keywords" content="<?php echo htmlspecialchars($page['meta_keywords']) ?>">
    <?php endif; ?>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
    <style>
        * { font-family: "Vazirmatn", sans-serif; }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
        }
        .content-area {
            padding: 60px 0;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo htmlspecialchars($siteName) ?></a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">صفحه اصلی</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $slug === 'about' ? 'active' : '' ?>" href="page.php?slug=about">درباره ما</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $slug === 'contact' ? 'active' : '' ?>" href="page.php?slug=contact">تماس با ما</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <?php echo htmlspecialchars($_SESSION['username']) ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="dashboard.php">داشبورد</a></li>
                                <?php if (in_array($_SESSION['role'], ['admin', 'editor'])): ?>
                                    <li><a class="dropdown-item" href="admin/">پنل مدیریت</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">خروج</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="auth.php">ورود</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="auth.php?action=register">ثبت نام</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold"><?php echo htmlspecialchars($page['title']) ?></h1>
                    <?php if ($page['excerpt']): ?>
                        <p class="lead"><?php echo htmlspecialchars($page['excerpt']) ?></p>
                    <?php endif; ?>
                    <div class="d-flex align-items-center mt-3">
                        <small class="text-white-50">
                            نویسنده: <?php echo htmlspecialchars($page['first_name'] . ' ' . $page['last_name']) ?>
                        </small>
                        <span class="mx-2 text-white-50">|</span>
                        <small class="text-white-50">
                            آخرین بروزرسانی: <?php echo date('Y/m/d', strtotime($page['updated_at'])) ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Content Area -->
    <section class="content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php if ($page['featured_image']): ?>
                        <img src="<?php echo htmlspecialchars($page['featured_image']) ?>" 
                             alt="<?php echo htmlspecialchars($page['title']) ?>" 
                             class="img-fluid rounded mb-4">
                    <?php endif; ?>
                    
                    <div class="content">
                        <?php echo $page['content'] ?>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">صفحات مرتبط</h5>
                            </div>
                            <div class="card-body">
                                <?php
                                // دریافت سایر صفحات
                                $stmt = $pdo->prepare("SELECT title, slug FROM pages WHERE status = 'published' AND slug != ? ORDER BY title LIMIT 5");
                                $stmt->execute([$slug]);
                                $relatedPages = $stmt->fetchAll();
                                ?>
                                
                                <?php if ($relatedPages): ?>
                                    <ul class="list-unstyled">
                                        <?php foreach ($relatedPages as $relatedPage): ?>
                                            <li class="mb-2">
                                                <a href="page.php?slug=<?php echo htmlspecialchars($relatedPage['slug']) ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo htmlspecialchars($relatedPage['title']) ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">صفحه‌ای یافت نشد</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo htmlspecialchars($siteName) ?></h5>
                    <p><?php echo htmlspecialchars($settings['site_description'] ?? '') ?></p>
                </div>
                <div class="col-md-6">
                    <h5>لینک‌های مفید</h5>
                    <ul class="list-unstyled">
                        <li><a href="page.php?slug=about" class="text-white-50">درباره ما</a></li>
                        <li><a href="page.php?slug=contact" class="text-white-50">تماس با ما</a></li>
                        <li><a href="page.php?slug=privacy" class="text-white-50">حریم خصوصی</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?php echo date('Y') ?> <?php echo htmlspecialchars($siteName) ?>. تمامی حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
