<?php
session_start();

// بررسی ورود کاربر
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: auth.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// بررسی نصب
if (!file_exists('.installed')) {
    header('Location: install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
$dbConfig = [];
if (file_exists('config/database.php')) {
    $dbConfig = require 'config/database.php';
}

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        return $pdo;
    } catch (PDOException $e) {
        die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
    }
}

try {
    $pdo = getDatabase();
    
    // دریافت تنظیمات سایت
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE group_name = 'general'");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    
    // دریافت اطلاعات کاربر
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    // آمار کاربر (اگر نویسنده یا ادیتور باشد)
    $userStats = [];
    if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])) {
        // تعداد مطالب کاربر
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM posts WHERE author_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['posts'] = $stmt->fetchColumn();
        
        // تعداد صفحات کاربر
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM pages WHERE author_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['pages'] = $stmt->fetchColumn();
        
        // آخرین مطالب کاربر
        $stmt = $pdo->prepare("
            SELECT title, slug, status, created_at 
            FROM posts 
            WHERE author_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['recent_posts'] = $stmt->fetchAll();
    }
    
    $siteName = $settings['site_name'] ?? 'Mitra CMS';
    
} catch (PDOException $e) {
    die('خطا در بارگذاری داشبورد: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد - <?php echo htmlspecialchars($siteName) ?></title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
    <link href="styles/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { font-family: "Vazirmatn", sans-serif; }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo htmlspecialchars($siteName) ?></a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">صفحه اصلی</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">داشبورد</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <?php if (in_array($_SESSION['role'], ['admin', 'editor'])): ?>
                                <li><a class="dropdown-item" href="admin/"><i class="bi bi-gear"></i> پنل مدیریت</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> خروج</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Dashboard Header -->
    <section class="dashboard-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="display-5 fw-bold">خوش آمدید، <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h1>
                    <p class="lead">داشبورد شخصی شما در <?php echo htmlspecialchars($siteName) ?></p>
                    <div class="d-flex align-items-center mt-3">
                        <span class="badge bg-light text-dark me-2"><?php echo htmlspecialchars($user['role']) ?></span>
                        <small class="text-white-50">
                            آخرین ورود: <?php echo $user['last_login'] ? date('Y/m/d H:i', strtotime($user['last_login'])) : 'اولین ورود' ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Dashboard Content -->
    <section class="py-5">
        <div class="container">
            <!-- User Stats -->
            <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
            <div class="row mb-5">
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-file-text display-4 text-primary mb-3"></i>
                        <h3><?php echo $userStats['posts'] ?></h3>
                        <p class="text-muted">مطالب شما</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-file-earmark display-4 text-success mb-3"></i>
                        <h3><?php echo $userStats['pages'] ?></h3>
                        <p class="text-muted">صفحات شما</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-calendar-check display-4 text-info mb-3"></i>
                        <h3><?php echo date('Y/m/d') ?></h3>
                        <p class="text-muted">امروز</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <!-- Profile Info -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-person"></i> اطلاعات شخصی</h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <?php if ($user['avatar']): ?>
                                    <img src="<?php echo htmlspecialchars($user['avatar']) ?>" alt="آواتار" class="rounded-circle" width="80" height="80">
                                <?php else: ?>
                                    <i class="bi bi-person-circle display-4 text-muted"></i>
                                <?php endif; ?>
                            </div>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>نام:</strong></td>
                                    <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>نام کاربری:</strong></td>
                                    <td><?php echo htmlspecialchars($user['username']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>ایمیل:</strong></td>
                                    <td><?php echo htmlspecialchars($user['email']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>نقش:</strong></td>
                                    <td><span class="badge bg-primary"><?php echo htmlspecialchars($user['role']) ?></span></td>
                                </tr>
                                <tr>
                                    <td><strong>عضویت:</strong></td>
                                    <td><?php echo date('Y/m/d', strtotime($user['created_at'])) ?></td>
                                </tr>
                            </table>
                            <?php if ($user['bio']): ?>
                                <div class="mt-3">
                                    <strong>درباره من:</strong>
                                    <p class="text-muted mt-2"><?php echo htmlspecialchars($user['bio']) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-lightning"></i> عملیات سریع</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
                                    <a href="admin/index.php?page=posts&action=add" class="btn btn-primary">
                                        <i class="bi bi-plus-circle"></i> مطلب جدید
                                    </a>
                                    <a href="admin/index.php?page=pages&action=add" class="btn btn-outline-primary">
                                        <i class="bi bi-file-plus"></i> صفحه جدید
                                    </a>
                                <?php endif; ?>
                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                    <a href="admin/index.php?page=users" class="btn btn-outline-success">
                                        <i class="bi bi-people"></i> مدیریت کاربران
                                    </a>
                                    <a href="admin/index.php?page=settings" class="btn btn-outline-info">
                                        <i class="bi bi-gear"></i> تنظیمات
                                    </a>
                                <?php endif; ?>
                                <a href="profile.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-person-gear"></i> ویرایش پروفایل
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> فعالیت‌های اخیر</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($userStats['recent_posts'])): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($userStats['recent_posts'] as $post): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($post['title']) ?></h6>
                                                    <small class="text-muted"><?php echo date('Y/m/d', strtotime($post['created_at'])) ?></small>
                                                </div>
                                                <span class="badge bg-<?php echo $post['status'] === 'published' ? 'success' : 'warning' ?>">
                                                    <?php echo $post['status'] === 'published' ? 'منتشر شده' : 'پیش‌نویس' ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center">فعالیتی یافت نشد</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Info (Admin Only) -->
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-info-circle"></i> اطلاعات سیستم</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <strong>نسخه PHP:</strong><br>
                                    <span class="text-muted"><?php echo PHP_VERSION ?></span>
                                </div>
                                <div class="col-md-3">
                                    <strong>نسخه MySQL:</strong><br>
                                    <span class="text-muted">
                                        <?php
                                        try {
                                            $version = $pdo->query('SELECT VERSION()')->fetchColumn();
                                            echo htmlspecialchars($version);
                                        } catch (Exception $e) {
                                            echo 'نامشخص';
                                        }
                                        ?>
                                    </span>
                                </div>
                                <div class="col-md-3">
                                    <strong>حافظه استفاده شده:</strong><br>
                                    <span class="text-muted"><?php echo round(memory_get_usage() / 1024 / 1024, 2) ?> MB</span>
                                </div>
                                <div class="col-md-3">
                                    <strong>زمان اجرا:</strong><br>
                                    <span class="text-muted"><?php echo round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 3) ?> ثانیه</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="text-center">
                <p>&copy; <?php echo date('Y') ?> <?php echo htmlspecialchars($siteName) ?>. تمامی حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
