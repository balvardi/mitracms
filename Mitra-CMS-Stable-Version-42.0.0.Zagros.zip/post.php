<?php
require_once 'config/database.php';
require_once 'config/app.php';

// Get post slug from URL
$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';

if (empty($slug)) {
    header('Location: /blog.php');
    exit;
}

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get post with category and author info
    $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug, u.username as author_name 
            FROM posts p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN users u ON p.author_id = u.id 
            WHERE p.slug = ? AND p.status = 'published'";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$slug]);
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$post) {
        header('HTTP/1.0 404 Not Found');
        include '404.php';
        exit;
    }

    // Get related posts from same category
    $related_sql = "SELECT title, slug, excerpt, featured_image, created_at 
                    FROM posts 
                    WHERE category_id = ? AND id != ? AND status = 'published' 
                    ORDER BY created_at DESC 
                    LIMIT 3";
    $related_stmt = $pdo->prepare($related_sql);
    $related_stmt->execute([$post['category_id'], $post['id']]);
    $related_posts = $related_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "خطا در دریافت مطلب: " . $e->getMessage();
}

// Helper function to format date
function formatPersianDate($date) {
    $timestamp = strtotime($date);
    $persian_months = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد', 4 => 'تیر',
        5 => 'مرداد', 6 => 'شهریور', 7 => 'مهر', 8 => 'آبان',
        9 => 'آذر', 10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];
    
    $day = date('j', $timestamp);
    $month = $persian_months[date('n', $timestamp)];
    $year = date('Y', $timestamp);
    
    return "{$day} {$month} {$year}";
}

$title = isset($post) ? $post['title'] . ' - ' . SITE_NAME : 'مطلب یافت نشد';
$description = isset($post) ? ($post['meta_description'] ?: strip_tags($post['excerpt'])) : '';
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title) ?></title>
    <?php if (isset($post)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($description) ?>">
        <meta name="keywords" content="<?php echo htmlspecialchars($post['meta_keywords']) ?>">
        <meta name="author" content="<?php echo htmlspecialchars($post['author_name']) ?>">
        
        <!-- Open Graph -->
        <meta property="og:title" content="<?php echo htmlspecialchars($post['title']) ?>">
        <meta property="og:description" content="<?php echo htmlspecialchars($description) ?>">
        <meta property="og:type" content="article">
        <meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ?>">
        <?php if (!empty($post['featured_image'])): ?>
            <meta property="og:image" content="<?php echo htmlspecialchars($post['featured_image']) ?>">
        <?php endif; ?>
        
        <!-- Twitter Card -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo htmlspecialchars($post['title']) ?>">
        <meta name="twitter:description" content="<?php echo htmlspecialchars($description) ?>">
        <?php if (!empty($post['featured_image'])): ?>
            <meta name="twitter:image" content="<?php echo htmlspecialchars($post['featured_image']) ?>">
        <?php endif; ?>
    <?php endif; ?>
    
    <!-- Bootstrap RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Vazirmatn', sans-serif;
            background-color: #f8f9fa;
            line-height: 1.8;
        }
        
        .post-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            margin-bottom: 3rem;
        }
        
        .post-content {
            background: white;
            border-radius: 15px;
            padding: 3rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 3rem;
        }
        
        .post-meta {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin-bottom: 2rem;
        }
        
        .category-badge {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .category-badge:hover {
            color: white;
            opacity: 0.8;
        }
        
        .post-content img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin: 1rem 0;
        }
        
        .related-posts {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .related-post-card {
            transition: transform 0.3s ease;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .related-post-card:hover {
            transform: translateY(-3px);
        }
        
        .breadcrumb {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 2rem;
        }
        
        .share-buttons {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 2rem 0;
        }
        
        .share-btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            margin: 0.25rem;
            border-radius: 25px;
            text-decoration: none;
            color: white;
            font-size: 0.9rem;
        }
        
        .share-telegram { background: #0088cc; }
        .share-whatsapp { background: #25d366; }
        .share-twitter { background: #1da1f2; }
        .share-facebook { background: #3b5998; }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(45deg, #667eea, #764ba2);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><?php echo SITE_NAME ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">وبلاگ</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php if (isset($error)): ?>
        <div class="container mt-5">
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle"></i> <?php echo $error ?>
            </div>
        </div>
    <?php elseif (isset($post)): ?>
        <!-- Breadcrumb -->
        <div class="container mt-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">خانه</a></li>
                    <li class="breadcrumb-item"><a href="blog.php">وبلاگ</a></li>
                    <?php if (!empty($post['category_name'])): ?>
                        <li class="breadcrumb-item">
                            <a href="blog.php?category=<?php echo $post['category_id'] ?>">
                                <?php echo htmlspecialchars($post['category_name']) ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo htmlspecialchars($post['title']) ?>
                    </li>
                </ol>
            </nav>
        </div>

        <!-- Post Header -->
        <div class="post-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center">
                        <?php if (!empty($post['category_name'])): ?>
                            <a href="blog.php?category=<?php echo $post['category_id'] ?>" class="category-badge mb-3 d-inline-block">
                                <?php echo htmlspecialchars($post['category_name']) ?>
                            </a>
                        <?php endif; ?>
                        <h1 class="display-5 fw-bold mb-4"><?php echo htmlspecialchars($post['title']) ?></h1>
                        <?php if (!empty($post['excerpt'])): ?>
                            <p class="lead"><?php echo htmlspecialchars($post['excerpt']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <!-- Post Meta -->
                    <div class="post-meta">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <i class="bi bi-person-circle text-primary"></i>
                                <strong>نویسنده:</strong> <?php echo htmlspecialchars($post['author_name']) ?>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <i class="bi bi-calendar3 text-primary"></i>
                                <strong>تاریخ انتشار:</strong> <?php echo formatPersianDate($post['created_at']) ?>
                            </div>
                        </div>
                        <?php if ($post['updated_at'] != $post['created_at']): ?>
                            <div class="row mt-2">
                                <div class="col-12 text-muted">
                                    <small>
                                        <i class="bi bi-pencil-square"></i>
                                        آخرین بروزرسانی: <?php echo formatPersianDate($post['updated_at']) ?>
                                    </small>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Featured Image -->
                    <?php if (!empty($post['featured_image'])): ?>
                        <div class="text-center mb-4">
                            <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" 
                                 class="img-fluid rounded" 
                                 alt="<?php echo htmlspecialchars($post['title']) ?>"
                                 style="max-height: 400px; object-fit: cover;">
                        </div>
                    <?php endif; ?>

                    <!-- Post Content -->
                    <div class="post-content">
                        <?php echo $post['content'] ?>
                    </div>

                    <!-- Share Buttons -->
                    <div class="share-buttons text-center">
                        <h6 class="mb-3"><i class="bi bi-share"></i> اشتراک‌گذاری این مطلب</h6>
                        <?php
                        $current_url = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        $post_title = urlencode($post['title']);
                        ?>
                        <a href="https://t.me/share/url?url=<?php echo $current_url ?>&text=<?php echo $post_title ?>" 
                           class="share-btn share-telegram" target="_blank">
                            <i class="bi bi-telegram"></i> تلگرام
                        </a>
                        <a href="https://wa.me/?text=<?php echo $post_title ?>%20<?php echo $current_url ?>" 
                           class="share-btn share-whatsapp" target="_blank">
                            <i class="bi bi-whatsapp"></i> واتساپ
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo $post_title ?>&url=<?php echo $current_url ?>" 
                           class="share-btn share-twitter" target="_blank">
                            <i class="bi bi-twitter"></i> توییتر
                        </a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url ?>" 
                           class="share-btn share-facebook" target="_blank">
                            <i class="bi bi-facebook"></i> فیسبوک
                        </a>
                    </div>

                    <!-- Related Posts -->
                    <?php if (!empty($related_posts)): ?>
                        <div class="related-posts">
                            <h4 class="fw-bold mb-4">
                                <i class="bi bi-collection"></i> مطالب مرتبط
                            </h4>
                            <div class="row">
                                <?php foreach ($related_posts as $related): ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="card related-post-card h-100">
                                            <?php if (!empty($related['featured_image'])): ?>
                                                <img src="<?php echo htmlspecialchars($related['featured_image']) ?>" 
                                                     class="card-img-top" style="height: 150px; object-fit: cover;"
                                                     alt="<?php echo htmlspecialchars($related['title']) ?>">
                                            <?php endif; ?>
                                            <div class="card-body">
                                                <h6 class="card-title">
                                                    <a href="post.php?slug=<?php echo htmlspecialchars($related['slug']) ?>" 
                                                       class="text-decoration-none">
                                                        <?php echo htmlspecialchars($related['title']) ?>
                                                    </a>
                                                </h6>
                                                <?php if (!empty($related['excerpt'])): ?>
                                                    <p class="card-text small text-muted">
                                                        <?php echo htmlspecialchars(mb_substr($related['excerpt'], 0, 100)) ?>...
                                                    </p>
                                                <?php endif; ?>
                                                <small class="text-muted">
                                                    <i class="bi bi-calendar3"></i>
                                                    <?php echo formatPersianDate($related['created_at']) ?>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Navigation -->
                    <div class="d-flex justify-content-between mt-4">
                        <a href="blog.php" class="btn btn-outline-primary">
                            <i class="bi bi-arrow-right"></i> بازگشت به وبلاگ
                        </a>
                        <?php if (!empty($post['category_name'])): ?>
                            <a href="blog.php?category=<?php echo $post['category_id'] ?>" class="btn btn-outline-secondary">
                                مطالب <?php echo htmlspecialchars($post['category_name']) ?> <i class="bi bi-arrow-left"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">&copy; <?php echo date('Y') ?> <?php echo SITE_NAME ?> - تمامی حقوق محفوظ است</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
