<?php
session_start();

// بررسی دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    http_response_code(401);
    echo json_encode(['error' => 'دسترسی غیرمجاز']);
    exit;
}

// بارگذاری تنظیمات
require_once '../config/app.php';
require_once '../config/database.php';

// اتصال به پایگاه داده
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'خطا در اتصال به پایگاه داده']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['error' => 'درخواست نامعتبر']);
    exit;
}

$file = $_FILES['file'];
$uploadDir = '../uploads/' . date('Y/m') . '/';

// ایجاد پوشه در صورت عدم وجود
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// بررسی نوع فایل
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($file['type'], $allowedTypes)) {
    http_response_code(400);
    echo json_encode(['error' => 'نوع فایل مجاز نیست']);
    exit;
}

// بررسی حجم فایل (5MB)
if ($file['size'] > MAX_FILE_SIZE) {
    http_response_code(400);
    echo json_encode(['error' => 'حجم فایل بیش از حد مجاز است']);
    exit;
}

// تولید نام یکتا
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid() . '.' . $extension;
$filepath = $uploadDir . $filename;

// آپلود فایل
if (move_uploaded_file($file['tmp_name'], $filepath)) {
    // ذخیره در پایگاه داده
    try {
        $stmt = $pdo->prepare("
            INSERT INTO media (filename, original_name, file_path, file_size, mime_type, uploaded_by, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $filename,
            $file['name'],
            $filepath,
            $file['size'],
            $file['type'],
            $_SESSION['user_id']
        ]);
        
        $mediaId = $pdo->lastInsertId();
        $fileUrl = UPLOAD_URL . date('Y/m') . '/' . $filename;
        
        echo json_encode([
            'success' => true,
            'id' => $mediaId,
            'filename' => $filename,
            'url' => $fileUrl,
            'size' => $file['size']
        ]);
        
    } catch (PDOException $e) {
        // حذف فایل در صورت خطا در پایگاه داده
        unlink($filepath);
        http_response_code(500);
        echo json_encode(['error' => 'خطا در ذخیره اطلاعات فایل']);
    }
} else {
    http_response_code(500);
    echo json_encode(['error' => 'خطا در آپلود فایل']);
}
?>
