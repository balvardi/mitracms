<?php
// بررسی دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['role'] !== 'admin') {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// پردازش فرم
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $parent_id = (int)($_POST['parent_id'] ?? 0);
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    $status = $_POST['status'] ?? 'active';
    
    if (empty($slug)) {
        $slug = preg_replace('/[^a-zA-Z0-9\-_]/', '-', $name);
        $slug = strtolower(trim($slug, '-'));
    }
    
    try {
        if ($action === 'add') {
            $stmt = $pdo->prepare("
                INSERT INTO categories (name, slug, description, parent_id, sort_order, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$name, $slug, $description, $parent_id ?: null, $sort_order, $status]);
            $success = "دسته‌بندی با موفقیت اضافه شد.";
        } elseif ($action === 'edit' && $id) {
            $stmt = $pdo->prepare("
                UPDATE categories 
                SET name = ?, slug = ?, description = ?, parent_id = ?, sort_order = ?, status = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$name, $slug, $description, $parent_id ?: null, $sort_order, $status, $id]);
            $success = "دسته‌بندی با موفقیت ویرایش شد.";
        }
        
        if (isset($success)) {
            echo '<div class="alert alert-success">' . $success . '</div>';
            $action = 'list';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">خطا: ' . $e->getMessage() . '</div>';
    }
}

// حذف دسته‌بندی
if ($action === 'delete' && $id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        echo '<div class="alert alert-success">دسته‌بندی با موفقیت حذف شد.</div>';
        $action = 'list';
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">خطا در حذف: ' . $e->getMessage() . '</div>';
    }
}

if ($action === 'list'):
    // دریافت دسته‌بندی‌ها
    $stmt = $pdo->query("
        SELECT c.*, p.name as parent_name,
               (SELECT COUNT(*) FROM posts WHERE category_id = c.id) as posts_count
        FROM categories c 
        LEFT JOIN categories p ON c.parent_id = p.id 
        ORDER BY c.sort_order, c.name
    ");
    $categories = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>مدیریت دسته‌بندی‌ها</h3>
    <a href="?page=categories&action=add" class="btn btn-primary">
        <i class="bi bi-plus-circle me-2"></i>دسته‌بندی جدید
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>نامک</th>
                        <th>والد</th>
                        <th>تعداد مطالب</th>
                        <th>ترتیب</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                    <tr>
                        <td>
                            <?php echo $category['parent_id'] ? '— ' : '' ?>
                            <?php echo htmlspecialchars($category['name']) ?>
                        </td>
                        <td><code><?php echo htmlspecialchars($category['slug']) ?></code></td>
                        <td><?php echo htmlspecialchars($category['parent_name'] ?? '—') ?></td>
                        <td>
                            <span class="badge bg-info"><?php echo $category['posts_count'] ?></span>
                        </td>
                        <td><?php echo $category['sort_order'] ?></td>
                        <td>
                            <span class="badge bg-<?php echo $category['status'] === 'active' ? 'success' : 'secondary' ?>">
                                <?php echo $category['status'] === 'active' ? 'فعال' : 'غیرفعال' ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="?page=categories&action=edit&id=<?php echo $category['id'] ?>" 
                                   class="btn btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="?page=categories&action=delete&id=<?php echo $category['id'] ?>" 
                                   class="btn btn-outline-danger"
                                   onclick="return confirm('آیا مطمئن هستید؟')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($action === 'add' || $action === 'edit'):
    $category = null;
    if ($action === 'edit' && $id) {
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $category = $stmt->fetch();
        
        if (!$category) {
            echo '<div class="alert alert-danger">دسته‌بندی یافت نشد.</div>';
            return;
        }
    }
    
    // دریافت دسته‌بندی‌های والد
    $stmt = $pdo->query("SELECT id, name FROM categories WHERE parent_id IS NULL ORDER BY name");
    $parent_categories = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3><?php echo $action === 'add' ? 'افزودن' : 'ویرایش' ?> دسته‌بندی</h3>
    <a href="?page=categories" class="btn btn-secondary">
        <i class="bi bi-arrow-left me-2"></i>بازگشت
    </a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">نام دسته‌بندی *</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               value="<?php echo htmlspecialchars($category['name'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="slug" class="form-label">نامک (اختیاری)</label>
                        <input type="text" class="form-control" id="slug" name="slug" 
                               value="<?php echo htmlspecialchars($category['slug'] ?? '') ?>">
                        <div class="form-text">در صورت خالی بودن، به صورت خودکار تولید می‌شود</div>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">توضیحات</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($category['description'] ?? '') ?></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="parent_id" class="form-label">دسته‌بندی والد</label>
                        <select class="form-select" id="parent_id" name="parent_id">
                            <option value="">— بدون والد —</option>
                            <?php foreach ($parent_categories as $parent): ?>
                                <?php if ($action === 'edit' && $parent['id'] == $id) continue; ?>
                                <option value="<?php echo $parent['id'] ?>" 
                                        <?php echo ($category['parent_id'] ?? '') == $parent['id'] ? 'selected' : '' ?>>
                                    <?php echo htmlspecialchars($parent['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="sort_order" class="form-label">ترتیب نمایش</label>
                        <input type="number" class="form-control" id="sort_order" name="sort_order" 
                               value="<?php echo $category['sort_order'] ?? 0 ?>" min="0">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="status" class="form-label">وضعیت</label>
                        <select class="form-select" id="status" name="status">
                            <option value="active" <?php echo ($category['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>فعال</option>
                            <option value="inactive" <?php echo ($category['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>غیرفعال</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-circle me-2"></i>ذخیره
                </button>
                <a href="?page=categories" class="btn btn-secondary">انصراف</a>
            </div>
        </form>
    </div>
</div>

<?php endif; ?>
