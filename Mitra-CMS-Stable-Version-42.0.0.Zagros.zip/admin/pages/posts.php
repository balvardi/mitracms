<?php
// بررسی دسترسی
if (!in_array($_SESSION['role'], ['admin', 'editor', 'author'])) {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$action = $_GET['action'] ?? 'list';
$postId = $_GET['id'] ?? null;
$message = '';
$messageType = '';

// پردازش عملیات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['save_post'])) {
            $title = trim($_POST['title']);
            $slug = trim($_POST['slug']);
            $content = $_POST['content'];
            $excerpt = trim($_POST['excerpt']);
            $status = $_POST['status'];
            $categoryId = $_POST['category_id'] ?: null;
            $metaTitle = trim($_POST['meta_title']);
            $metaDescription = trim($_POST['meta_description']);
            $metaKeywords = trim($_POST['meta_keywords']);
            $featuredImage = trim($_POST['featured_image']);
            
            // اعتبارسنجی
            if (empty($title)) {
                throw new Exception('عنوان پست الزامی است');
            }
            
            // تولید slug خودکار
            if (empty($slug)) {
                $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
            }
            
            // بررسی یکتا بودن slug
            $checkSlugSql = "SELECT id FROM posts WHERE slug = ? AND id != ?";
            $stmt = $pdo->prepare($checkSlugSql);
            $stmt->execute([$slug, $postId ?: 0]);
            if ($stmt->fetch()) {
                $slug .= '-' . time();
            }
            
            if ($postId) {
                // ویرایش پست
                $sql = "UPDATE posts SET 
                        title = ?, slug = ?, content = ?, excerpt = ?, status = ?, 
                        category_id = ?, meta_title = ?, meta_description = ?, meta_keywords = ?, 
                        featured_image = ?, updated_at = NOW()";
                $params = [$title, $slug, $content, $excerpt, $status, $categoryId, 
                          $metaTitle, $metaDescription, $metaKeywords, $featuredImage];
                
                // فقط ادمین می‌تواند پست‌های دیگران را ویرایش کند
                if ($_SESSION['role'] !== 'admin') {
                    $sql .= " WHERE id = ? AND author_id = ?";
                    $params[] = $postId;
                    $params[] = $_SESSION['user_id'];
                } else {
                    $sql .= " WHERE id = ?";
                    $params[] = $postId;
                }
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                
                if ($stmt->rowCount() > 0) {
                    $message = 'پست با موفقیت به‌روزرسانی شد';
                    $messageType = 'success';
                } else {
                    throw new Exception('خطا در به‌روزرسانی پست');
                }
            } else {
                // ایجاد پست جدید
                $sql = "INSERT INTO posts (title, slug, content, excerpt, status, category_id, 
                        author_id, meta_title, meta_description, meta_keywords, featured_image, 
                        published_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $publishedAt = ($status === 'published') ? date('Y-m-d H:i:s') : null;
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$title, $slug, $content, $excerpt, $status, $categoryId, 
                               $_SESSION['user_id'], $metaTitle, $metaDescription, $metaKeywords, 
                               $featuredImage, $publishedAt]);
                
                $message = 'پست جدید با موفقیت ایجاد شد';
                $messageType = 'success';
                $action = 'list';
            }
        } elseif (isset($_POST['delete_post']) && $postId) {
            // حذف پست
            $sql = "DELETE FROM posts WHERE id = ?";
            $params = [$postId];
            
            // فقط ادمین می‌تواند پست‌های دیگران را حذف کند
            if ($_SESSION['role'] !== 'admin') {
                $sql .= " AND author_id = ?";
                $params[] = $_SESSION['user_id'];
            }
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            
            if ($stmt->rowCount() > 0) {
                $message = 'پست با موفقیت حذف شد';
                $messageType = 'success';
                $action = 'list';
            } else {
                throw new Exception('خطا در حذف پست');
            }
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}

// دریافت دسته‌بندی‌ها
$stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
$categories = $stmt->fetchAll();

if ($action === 'list') {
    // لیست پست‌ها
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    
    $search = $_GET['search'] ?? '';
    $statusFilter = $_GET['status'] ?? '';
    $categoryFilter = $_GET['category'] ?? '';
    
    // ساخت کوئری
    $whereConditions = [];
    $params = [];
    
    if ($search) {
        $whereConditions[] = "(p.title LIKE ? OR p.content LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    if ($statusFilter) {
        $whereConditions[] = "p.status = ?";
        $params[] = $statusFilter;
    }
    
    if ($categoryFilter) {
        $whereConditions[] = "p.category_id = ?";
        $params[] = $categoryFilter;
    }
    
    // محدود کردن به پست‌های خود کاربر (غیر از ادمین)
    if ($_SESSION['role'] !== 'admin') {
        $whereConditions[] = "p.author_id = ?";
        $params[] = $_SESSION['user_id'];
    }
    
    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // شمارش کل
    $countSql = "SELECT COUNT(*) FROM posts p $whereClause";
    $stmt = $pdo->prepare($countSql);
    $stmt->execute($params);
    $totalPosts = $stmt->fetchColumn();
    $totalPages = ceil($totalPosts / $perPage);
    
    // دریافت پست‌ها
    $sql = "SELECT p.*, c.name as category_name, u.username, u.first_name, u.last_name 
            FROM posts p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN users u ON p.author_id = u.id 
            $whereClause 
            ORDER BY p.created_at DESC 
            LIMIT $perPage OFFSET $offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $posts = $stmt->fetchAll();
    
    ?>
    
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="bi bi-file-text"></i> مدیریت مطالب</h4>
        <a href="?page=posts&action=new" class="btn btn-primary">
            <i class="bi bi-plus"></i> پست جدید
        </a>
    </div>
    
    <!-- فیلترها -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="posts">
                <div class="col-md-3">
                    <input type="text" class="form-control" name="search" placeholder="جستجو..." 
                           value="<?php echo htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">همه وضعیت‌ها</option>
                        <option value="published" <?php echo $statusFilter === 'published' ? 'selected' : '' ?>>منتشر شده</option>
                        <option value="draft" <?php echo $statusFilter === 'draft' ? 'selected' : '' ?>>پیش‌نویس</option>
                        <option value="private" <?php echo $statusFilter === 'private' ? 'selected' : '' ?>>خصوصی</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="category" class="form-select">
                        <option value="">همه دسته‌ها</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id'] ?>" <?php echo $categoryFilter == $cat['id'] ? 'selected' : '' ?>>
                            <?php echo htmlspecialchars($cat['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search"></i> جستجو
                    </button>
                </div>
                <div class="col-md-3">
                    <a href="?page=posts" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise"></i> پاک کردن فیلتر
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- جدول پست‌ها -->
    <div class="card">
        <div class="card-body">
            <?php if ($posts): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>عنوان</th>
                            <th>نویسنده</th>
                            <th>دسته‌بندی</th>
                            <th>وضعیت</th>
                            <th>تاریخ</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($posts as $post): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($post['title']) ?></strong>
                                <?php if ($post['excerpt']): ?>
                                <br><small class="text-muted"><?php echo htmlspecialchars(substr($post['excerpt'], 0, 100)) ?>...</small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($post['first_name'] . ' ' . $post['last_name']) ?></td>
                            <td><?php echo htmlspecialchars($post['category_name'] ?? 'بدون دسته') ?></td>
                            <td>
                                <?php
                                $statusLabels = [
                                    'published' => '<span class="badge bg-success">منتشر شده</span>',
                                    'draft' => '<span class="badge bg-warning">پیش‌نویس</span>',
                                    'private' => '<span class="badge bg-secondary">خصوصی</span>'
                                ];
                                echo $statusLabels[$post['status']] ?? $post['status'];
                                ?>
                            </td>
                            <td>
                                <small><?php echo date('Y/m/d H:i', strtotime($post['created_at'])) ?></small>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <?php if ($post['status'] === 'published'): ?>
                                    <a href="../post.php?slug=<?php echo urlencode($post['slug']) ?>" 
                                       class="btn btn-outline-info" target="_blank" title="مشاهده">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($_SESSION['role'] === 'admin' || $post['author_id'] == $_SESSION['user_id']): ?>
                                    <a href="?page=posts&action=edit&id=<?php echo $post['id'] ?>" 
                                       class="btn btn-outline-primary" title="ویرایش">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <button type="button" class="btn btn-outline-danger" 
                                            onclick="deletePost(<?php echo $post['id'] ?>, '<?php echo htmlspecialchars($post['title']) ?>')" 
                                            title="حذف">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- صفحه‌بندی -->
            <?php if ($totalPages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=posts&p=<?php echo $i ?>&search=<?php echo urlencode($search) ?>&status=<?php echo urlencode($statusFilter) ?>&category=<?php echo urlencode($categoryFilter) ?>">
                            <?php echo $i ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
            
            <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-file-text display-1 text-muted"></i>
                <h5 class="mt-3">پستی یافت نشد</h5>
                <p class="text-muted">هنوز پستی ایجاد نشده است.</p>
                <a href="?page=posts&action=new" class="btn btn-primary">
                    <i class="bi bi-plus"></i> اولین پست را بسازید
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal حذف -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأیید حذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>آیا از حذف پست "<span id="postTitle"></span>" اطمینان دارید؟</p>
                    <p class="text-danger"><small>این عمل قابل بازگشت نیست.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="delete_post" value="1">
                        <input type="hidden" id="deletePostId" name="id" value="">
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function deletePost(id, title) {
        document.getElementById('postTitle').textContent = title;
        document.getElementById('deletePostId').value = id;
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    }
    </script>
    
    <?php
} elseif ($action === 'new' || $action === 'edit') {
    // فرم ایجاد/ویرایش پست
    $post = null;
    if ($action === 'edit' && $postId) {
        $sql = "SELECT * FROM posts WHERE id = ?";
        $params = [$postId];
        
        // فقط ادمین می‌تواند پست‌های دیگران را ویرایش کند
        if ($_SESSION['role'] !== 'admin') {
            $sql .= " AND author_id = ?";
            $params[] = $_SESSION['user_id'];
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $post = $stmt->fetch();
        
        if (!$post) {
            echo '<div class="alert alert-danger">پست مورد نظر یافت نشد یا شما دسترسی لازم را ندارید.</div>';
            return;
        }
    }
    ?>
    
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="bi bi-<?php echo $action === 'new' ? 'plus' : 'pencil' ?>"></i> 
            <?php echo $action === 'new' ? 'پست جدید' : 'ویرایش پست' ?>
        </h4>
        <a href="?page=posts" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت
        </a>
    </div>
    
    <form method="POST">
        <div class="row">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">محتوای پست</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">عنوان *</label>
                            <input type="text" name="title" class="form-control" required
                                   value="<?php echo htmlspecialchars($post['title'] ?? '') ?>"
                                   onkeyup="generateSlug(this.value)">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نامک (Slug)</label>
                            <input type="text" name="slug" id="slug" class="form-control"
                                   value="<?php echo htmlspecialchars($post['slug'] ?? '') ?>">
                            <div class="form-text">آدرس URL پست. خالی بگذارید تا خودکار تولید شود.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">محتوا</label>
                            <textarea name="content" id="content" class="form-control"><?php echo htmlspecialchars($post['content'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">خلاصه</label>
                            <textarea name="excerpt" class="form-control" rows="3"><?php echo htmlspecialchars($post['excerpt'] ?? '') ?></textarea>
                            <div class="form-text">خلاصه‌ای از پست برای نمایش در لیست مطالب</div>
                        </div>
                    </div>
                </div>
                
                <!-- SEO -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">تنظیمات SEO</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">عنوان متا</label>
                            <input type="text" name="meta_title" class="form-control"
                                   value="<?php echo htmlspecialchars($post['meta_title'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">توضیحات متا</label>
                            <textarea name="meta_description" class="form-control" rows="3"><?php echo htmlspecialchars($post['meta_description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">کلمات کلیدی</label>
                            <input type="text" name="meta_keywords" class="form-control"
                                   value="<?php echo htmlspecialchars($post['meta_keywords'] ?? '') ?>">
                            <div class="form-text">کلمات را با کاما جدا کنید</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <!-- انتشار -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">انتشار</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">وضعیت</label>
                            <select name="status" class="form-select">
                                <option value="draft" <?php echo ($post['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>پیش‌نویس</option>
                                <option value="published" <?php echo ($post['status'] ?? '') === 'published' ? 'selected' : '' ?>>منتشر شده</option>
                                <option value="private" <?php echo ($post['status'] ?? '') === 'private' ? 'selected' : '' ?>>خصوصی</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">دسته‌بندی</label>
                            <select name="category_id" class="form-select">
                                <option value="">بدون دسته</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id'] ?>" 
                                        <?php echo ($post['category_id'] ?? '') == $category['id'] ? 'selected' : '' ?>>
                                    <?php echo htmlspecialchars($category['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" name="save_post" class="btn btn-primary">
                                <i class="bi bi-check"></i> ذخیره
                            </button>
                            <?php if ($action === 'edit'): ?>
                            <a href="../post.php?slug=<?php echo urlencode($post['slug']) ?>" 
                               class="btn btn-outline-info" target="_blank">
                                <i class="bi bi-eye"></i> مشاهده
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- تصاویر -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">تصاویر</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">تصویر شاخص</label>
                            <input type="text" name="featured_image" id="featured_image" class="form-control"
                                   placeholder="آدرس تصویر" value="<?php echo htmlspecialchars($post['featured_image'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">آپلود تصاویر</label>
                            <input type="file" id="imageUpload" class="form-control" multiple accept="image/*">
                            <div class="form-text">می‌توانید چندین تصویر انتخاب کنید</div>
                        </div>
                        
                        <div id="uploadProgress" class="progress mb-3" style="display: none;">
                            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                        </div>
                        
                        <div id="uploadedImages" class="row g-2">
                            <!-- تصاویر آپلود شده اینجا نمایش داده می‌شوند -->
                        </div>
                        
                        <div id="image_preview" class="text-center mt-3">
                            <?php if (!empty($post['featured_image'])): ?>
                            <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" 
                                 class="img-fluid rounded" style="max-height: 200px;">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    
    <!-- TinyMCE Editor -->

    <script>
    // Initialize TinyMCE
    tinymce.init({
        selector: '#content',
        height: 400,
        language: 'fa',
        directionality: 'rtl',
        plugins: 'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste code help wordcount',
        toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help | image media link',
        content_style: 'body { font-family: Vazirmatn, Arial, sans-serif; font-size: 14px; direction: rtl; }',
        setup: function (editor) {
            editor.on('change', function () {
                editor.save();
            });
        }
    });

    // Image upload functionality
    document.getElementById('imageUpload').addEventListener('change', function(e) {
        const files = e.target.files;
        if (files.length === 0) return;
        
        const progressBar = document.getElementById('uploadProgress');
        const progressBarInner = progressBar.querySelector('.progress-bar');
        const uploadedImagesContainer = document.getElementById('uploadedImages');
        
        progressBar.style.display = 'block';
        
        let uploadedCount = 0;
        const totalFiles = files.length;
        
        Array.from(files).forEach((file, index) => {
            const formData = new FormData();
            formData.append('file', file);
            
            fetch('upload.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                uploadedCount++;
                const progress = (uploadedCount / totalFiles) * 100;
                progressBarInner.style.width = progress + '%';
                
                if (data.success) {
                    // Add image to gallery
                    const imageDiv = document.createElement('div');
                    imageDiv.className = 'col-6 col-md-4';
                    imageDiv.innerHTML = `
                        <div class="card">
                            <img src="${data.url}" class="card-img-top" style="height: 100px; object-fit: cover;">
                            <div class="card-body p-2">
                                <button type="button" class="btn btn-sm btn-primary w-100" 
                                        onclick="insertImage('${data.url}')">
                                    درج در متن
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-secondary w-100 mt-1" 
                                        onclick="setFeaturedImage('${data.url}')">
                                    تصویر شاخص
                                </button>
                            </div>
                        </div>
                    `;
                    uploadedImagesContainer.appendChild(imageDiv);
                } else {
                    alert('خطا در آپلود: ' + data.error);
                }
                
                if (uploadedCount === totalFiles) {
                    setTimeout(() => {
                        progressBar.style.display = 'none';
                        progressBarInner.style.width = '0%';
                    }, 1000);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('خطا در آپلود فایل');
                uploadedCount++;
                
                if (uploadedCount === totalFiles) {
                    setTimeout(() => {
                        progressBar.style.display = 'none';
                        progressBarInner.style.width = '0%';
                    }, 1000);
                }
            });
        });
    });

    // Insert image into TinyMCE
    function insertImage(url) {
        tinymce.get('content').insertContent(`<img src="${url}" alt="تصویر" style="max-width: 100%; height: auto;">`);
    }

    // Set as featured image
    function setFeaturedImage(url) {
        document.getElementById('featured_image').value = url;
        document.getElementById('image_preview').innerHTML = 
            `<img src="${url}" class="img-fluid rounded" style="max-height: 200px;">`;
    }

    // Generate slug function
    function generateSlug(title) {
        const slug = title.toLowerCase()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
        document.getElementById('slug').value = slug;
    }

    // Preview featured image
    document.getElementById('featured_image').addEventListener('input', function() {
        const url = this.value;
        const preview = document.getElementById('image_preview');
        if (url) {
            preview.innerHTML = '<img src="' + url + '" class="img-fluid rounded" style="max-height: 200px;">';
        } else {
            preview.innerHTML = '';
        }
    });
    </script>
    
    <?php
}
?>
