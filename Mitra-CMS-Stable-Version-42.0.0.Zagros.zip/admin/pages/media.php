<?php
// بررسی ورود کاربر
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth.php');
    exit;
}

// تنظیمات آپلود
$upload_dir = '../../uploads/';
$allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'mp4', 'mp3'];
$max_file_size = 10 * 1024 * 1024; // 10MB

// ایجاد پوشه آپلود در صورت عدم وجود
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$message = '';
$error = '';

// پردازش آپلود فایل
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
    $uploaded_files = [];
    
    foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
            $original_name = $_FILES['files']['name'][$key];
            $file_size = $_FILES['files']['size'][$key];
            $file_type = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
            
            // بررسی نوع فایل
            if (!in_array($file_type, $allowed_types)) {
                $error .= "نوع فایل {$original_name} مجاز نیست. ";
                continue;
            }
            
            // بررسی سایز فایل
            if ($file_size > $max_file_size) {
                $error .= "سایز فایل {$original_name} بیش از حد مجاز است. ";
                continue;
            }
            
            // تولید نام یکتا
            $file_name = time() . '_' . uniqid() . '.' . $file_type;
            $file_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($tmp_name, $file_path)) {
                // ذخیره در دیتابیس
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO media (original_name, file_name, file_path, file_type, file_size, uploaded_by, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->execute([
                        $original_name,
                        $file_name,
                        $file_path,
                        $file_type,
                        $file_size,
                        $_SESSION['user_id']
                    ]);
                    $uploaded_files[] = $original_name;
                } catch (PDOException $e) {
                    $error .= "خطا در ذخیره فایل {$original_name}: " . $e->getMessage() . " ";
                }
            } else {
                $error .= "خطا در آپلود فایل {$original_name}. ";
            }
        }
    }
    
    if (!empty($uploaded_files)) {
        $message = count($uploaded_files) . " فایل با موفقیت آپلود شد: " . implode(', ', $uploaded_files);
    }
}

// پردازش حذف فایل
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $file_id = (int)$_GET['delete'];
    
    try {
        // دریافت اطلاعات فایل
        $stmt = $pdo->prepare("SELECT * FROM media WHERE id = ?");
        $stmt->execute([$file_id]);
        $file = $stmt->fetch();
        
        if ($file) {
            // حذف فایل فیزیکی
            if (file_exists($file['file_path'])) {
                unlink($file['file_path']);
            }
            
            // حذف از دیتابیس
            $stmt = $pdo->prepare("DELETE FROM media WHERE id = ?");
            $stmt->execute([$file_id]);
            
            $message = "فایل با موفقیت حذف شد.";
        }
    } catch (PDOException $e) {
        $error = "خطا در حذف فایل: " . $e->getMessage();
    }
}

// دریافت فایل‌ها با فیلتر و جستجو
$search = $_GET['search'] ?? '';
$filter_type = $_GET['filter_type'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "original_name LIKE ?";
    $params[] = "%{$search}%";
}

if ($filter_type) {
    $where_conditions[] = "file_type = ?";
    $params[] = $filter_type;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// شمارش کل فایل‌ها
$count_sql = "SELECT COUNT(*) FROM media {$where_clause}";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_files = $stmt->fetchColumn();
$total_pages = ceil($total_files / $per_page);

// دریافت فایل‌ها
$sql = "
    SELECT m.*, u.first_name, u.last_name 
    FROM media m 
    LEFT JOIN users u ON m.uploaded_by = u.id 
    {$where_clause}
    ORDER BY m.created_at DESC 
    LIMIT {$per_page} OFFSET {$offset}
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$files = $stmt->fetchAll();

// دریافت آمار
$stats_sql = "
    SELECT 
        COUNT(*) as total_files,
        COALESCE(SUM(file_size), 0) as total_size,
        COUNT(CASE WHEN file_type IN ('jpg', 'jpeg', 'png', 'gif') THEN 1 END) as images,
        COUNT(CASE WHEN file_type IN ('pdf', 'doc', 'docx') THEN 1 END) as documents,
        COUNT(CASE WHEN file_type IN ('mp4', 'avi', 'mov') THEN 1 END) as videos,
        COUNT(CASE WHEN file_type IN ('mp3', 'wav', 'ogg') THEN 1 END) as audio
    FROM media
";
$stmt = $pdo->query($stats_sql);
$stats = $stmt->fetch();

// تابع فرمت سایز فایل
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// تابع تشخیص آیکون فایل
function getFileIcon($file_type) {
    $icons = [
        'jpg' => 'bi-image',
        'jpeg' => 'bi-image',
        'png' => 'bi-image',
        'gif' => 'bi-image',
        'pdf' => 'bi-file-earmark-pdf',
        'doc' => 'bi-file-earmark-word',
        'docx' => 'bi-file-earmark-word',
        'mp4' => 'bi-camera-video',
        'avi' => 'bi-camera-video',
        'mov' => 'bi-camera-video',
        'mp3' => 'bi-music-note',
        'wav' => 'bi-music-note',
        'ogg' => 'bi-music-note'
    ];
    
    return $icons[$file_type] ?? 'bi-file-earmark';
}

// تابع بررسی تصویر
function isImage($file_type) {
    return in_array($file_type, ['jpg', 'jpeg', 'png', 'gif']);
}
?>

<!-- نمایش پیام‌ها -->
<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- آمار کلی -->
<div class="row mb-4">
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-primary"><?php echo number_format($stats['total_files']) ?></div>
            <div class="stats-label">کل فایل‌ها</div>
            <small class="text-muted"><?php echo formatFileSize($stats['total_size']) ?></small>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-success"><?php echo number_format($stats['images']) ?></div>
            <div class="stats-label">تصاویر</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-info"><?php echo number_format($stats['documents']) ?></div>
            <div class="stats-label">اسناد</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-warning"><?php echo number_format($stats['videos']) ?></div>
            <div class="stats-label">ویدیوها</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-danger"><?php echo number_format($stats['audio']) ?></div>
            <div class="stats-label">صوتی</div>
        </div>
    </div>
</div>

<!-- فرم آپلود -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-cloud-upload"></i> آپلود فایل جدید</h5>
    </div>
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data" id="uploadForm">
            <div class="mb-3">
                <label for="files" class="form-label">انتخاب فایل‌ها</label>
                <input type="file" class="form-control" id="files" name="files[]" multiple 
                       accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.mp4,.mp3">
                <div class="form-text">
                    انواع مجاز: JPG, PNG, GIF, PDF, DOC, DOCX, MP4, MP3 | حداکثر سایز: 10MB
                </div>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-upload"></i> آپلود فایل‌ها
            </button>
        </form>
    </div>
</div>

<!-- فیلتر و جستجو -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <input type="hidden" name="page" value="media">
            <div class="col-md-4">
                <label for="search" class="form-label">جستجو در نام فایل</label>
                <input type="text" class="form-control" id="search" name="search" 
                       value="<?php echo htmlspecialchars($search) ?>" placeholder="نام فایل...">
            </div>
            <div class="col-md-3">
                <label for="filter_type" class="form-label">نوع فایل</label>
                <select class="form-select" id="filter_type" name="filter_type">
                    <option value="">همه انواع</option>
                    <option value="jpg" <?php echo $filter_type === 'jpg' ? 'selected' : '' ?>>JPG</option>
                    <option value="png" <?php echo $filter_type === 'png' ? 'selected' : '' ?>>PNG</option>
                    <option value="gif" <?php echo $filter_type === 'gif' ? 'selected' : '' ?>>GIF</option>
                    <option value="pdf" <?php echo $filter_type === 'pdf' ? 'selected' : '' ?>>PDF</option>
                    <option value="doc" <?php echo $filter_type === 'doc' ? 'selected' : '' ?>>DOC</option>
                    <option value="mp4" <?php echo $filter_type === 'mp4' ? 'selected' : '' ?>>MP4</option>
                    <option value="mp3" <?php echo $filter_type === 'mp3' ? 'selected' : '' ?>>MP3</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> جستجو
                    </button>
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label>
                <div>
                    <a href="?page=media" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise"></i> پاک کردن فیلتر
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- لیست فایل‌ها -->
<div class="row">
    <?php if (empty($files)): ?>
        <div class="col-12">
            <div class="text-center py-5">
                <i class="bi bi-folder2-open display-1 text-muted"></i>
                <h4 class="mt-3">هیچ فایلی یافت نشد</h4>
                <p class="text-muted">فایل جدیدی آپلود کنید یا فیلترها را تغییر دهید.</p>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($files as $file): ?>
            <div class="col-md-3 mb-4">
                <div class="card file-card">
                    <div class="card-body text-center">
                        <?php if (isImage($file['file_type'])): ?>
                            <img src="<?php echo htmlspecialchars($file['file_path']) ?>" 
                                 class="img-fluid mb-3 file-preview" 
                                 alt="<?php echo htmlspecialchars($file['original_name']) ?>">
                        <?php else: ?>
                            <i class="<?php echo getFileIcon($file['file_type']) ?> display-1 text-muted mb-3"></i>
                        <?php endif; ?>
                        
                        <h6 class="card-title" title="<?php echo htmlspecialchars($file['original_name']) ?>">
                            <?php echo htmlspecialchars(mb_substr($file['original_name'], 0, 20)) ?>
                            <?php echo mb_strlen($file['original_name']) > 20 ? '...' : '' ?>
                        </h6>
                        
                        <div class="file-info">
                            <small class="text-muted d-block">
                                <i class="bi bi-file-earmark"></i> <?php echo strtoupper($file['file_type']) ?>
                            </small>
                            <small class="text-muted d-block">
                                <i class="bi bi-hdd"></i> <?php echo formatFileSize($file['file_size']) ?>
                            </small>
                            <small class="text-muted d-block">
                                <i class="bi bi-person"></i> <?php echo htmlspecialchars($file['first_name'] . ' ' . $file['last_name']) ?>
                            </small>
                            <small class="text-muted d-block">
                                <i class="bi bi-calendar"></i> <?php echo date('Y/m/d', strtotime($file['created_at'])) ?>
                            </small>
                        </div>
                        
                        <div class="file-actions mt-3">
                            <button class="btn btn-sm btn-outline-primary" 
                                    onclick="copyToClipboard('<?php echo htmlspecialchars($file['file_path']) ?>')">
                                <i class="bi bi-link-45deg"></i> کپی لینک
                            </button>
                            <a href="<?php echo htmlspecialchars($file['file_path']) ?>" 
                               class="btn btn-sm btn-outline-success" target="_blank">
                                <i class="bi bi-download"></i> دانلود
                            </a>
                            <a href="?page=media&delete=<?php echo $file['id'] ?>" 
                               class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('آیا از حذف این فایل اطمینان دارید؟')">
                                <i class="bi bi-trash"></i> حذف
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- صفحه‌بندی -->
<?php if ($total_pages > 1): ?>
    <nav aria-label="صفحه‌بندی فایل‌ها">
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=media&search=<?php echo urlencode($search) ?>&filter_type=<?php echo urlencode($filter_type) ?>&page=<?php echo $page - 1 ?>">قبلی</a>
                </li>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                <li class="page-item <?php echo $i === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=media&search=<?php echo urlencode($search) ?>&filter_type=<?php echo urlencode($filter_type) ?>&page=<?php echo $i ?>"><?php echo $i ?></a>
                </li>
            <?php endfor; ?>
            
            <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=media&search=<?php echo urlencode($search) ?>&filter_type=<?php echo urlencode($filter_type) ?>&page=<?php echo $page + 1 ?>">بعدی</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<style>
.file-card {
    transition: transform 0.3s;
    height: 100%;
}

.file-card:hover {
    transform: translateY(-5px);
}

.file-preview {
    max-height: 150px;
    object-fit: cover;
    border-radius: 8px;
}

.file-info {
    margin: 1rem 0;
}

.file-actions .btn {
    margin: 0 2px;
}

.stats-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: transform 0.3s;
    text-align: center;
}

.stats-card:hover {
    transform: translateY(-3px);
}

.stats-number {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
}

.stats-label {
    color: #6c757d;
    font-size: 0.9rem;
}
</style>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(window.location.origin + '/' + text).then(function() {
        alert('لینک کپی شد!');
    }, function(err) {
        console.error('خطا در کپی کردن: ', err);
    });
}

// پیش‌نمایش فایل‌های انتخاب شده
document.getElementById('files').addEventListener('change', function(e) {
    const files = e.target.files;
    let totalSize = 0;
    
    for (let file of files) {
        totalSize += file.size;
    }
    
    if (totalSize > 50 * 1024 * 1024) { // 50MB
        alert('مجموع سایز فایل‌ها نباید بیش از 50MB باشد.');
        e.target.value = '';
    }
});
</script>
