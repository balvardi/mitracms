<?php
// بررسی دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['role'] !== 'admin') {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$action = $_GET['action'] ?? 'list';
$module_name = $_GET['module'] ?? '';

// پردازش عملیات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $module = $_POST['module'] ?? '';
    $operation = $_POST['operation'] ?? '';
    
    try {
        if ($operation === 'activate') {
            $stmt = $pdo->prepare("
                INSERT INTO modules (name, status, activated_at) 
                VALUES (?, 'active', NOW()) 
                ON DUPLICATE KEY UPDATE status = 'active', activated_at = NOW()
            ");
            $stmt->execute([$module]);
            $success = "ماژول {$module} فعال شد.";
        } elseif ($operation === 'deactivate') {
            $stmt = $pdo->prepare("UPDATE modules SET status = 'inactive' WHERE name = ?");
            $stmt->execute([$module]);
            $success = "ماژول {$module} غیرفعال شد.";
        }
        
        if (isset($success)) {
            echo '<div class="alert alert-success">' . $success . '</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">خطا: ' . $e->getMessage() . '</div>';
    }
}

// دریافت ماژول‌های نصب شده
$stmt = $pdo->query("SELECT * FROM modules ORDER BY name");
$installed_modules = [];
while ($row = $stmt->fetch()) {
    $installed_modules[$row['name']] = $row;
}

// ماژول‌های موجود
$available_modules = [
    'ecommerce' => [
        'name' => 'فروشگاه الکترونیک',
        'description' => 'سیستم کامل فروشگاه آنلاین با درگاه پرداخت',
        'version' => '1.0.0',
        'author' => 'Mitra CMS',
        'path' => '../modules/Ecommerce/'
    ],
    'contact_form' => [
        'name' => 'فرم تماس',
        'description' => 'فرم تماس پیشرفته با مدیریت پیام‌ها',
        'version' => '1.0.0',
        'author' => 'Mitra CMS',
        'path' => '../modules/ContactForm/'
    ],
    'gallery' => [
        'name' => 'گالری تصاویر',
        'description' => 'نمایش گالری تصاویر با امکانات پیشرفته',
        'version' => '1.0.0',
        'author' => 'Mitra CMS',
        'path' => '../modules/Gallery/'
    ],
    'newsletter' => [
        'name' => 'خبرنامه',
        'description' => 'سیستم مدیریت خبرنامه و ایمیل مارکتینگ',
        'version' => '1.0.0',
        'author' => 'Mitra CMS',
        'path' => '../modules/Newsletter/'
    ]
];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>مدیریت ماژول‌ها</h3>
    <div>
        <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#installModal">
            <i class="bi bi-download me-2"></i>نصب ماژول جدید
        </button>
    </div>
</div>

<div class="row">
    <?php foreach ($available_modules as $key => $module): ?>
        <?php 
        $is_installed = isset($installed_modules[$key]);
        $is_active = $is_installed && $installed_modules[$key]['status'] === 'active';
        ?>
    <div class="col-lg-6 col-xl-4 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo htmlspecialchars($module['name']) ?></h5>
                <span class="badge bg-<?php echo $is_active ? 'success' : ($is_installed ? 'warning' : 'secondary') ?>">
                    <?php echo $is_active ? 'فعال' : ($is_installed ? 'نصب شده' : 'نصب نشده') ?>
                </span>
            </div>
            <div class="card-body">
                <p class="text-muted"><?php echo htmlspecialchars($module['description']) ?></p>
                <div class="mb-2">
                    <small class="text-muted">
                        <strong>نسخه:</strong> <?php echo htmlspecialchars($module['version']) ?><br>
                        <strong>سازنده:</strong> <?php echo htmlspecialchars($module['author']) ?>
                    </small>
                </div>
                
                <?php if ($is_installed): ?>
                    <small class="text-muted d-block mb-3">
                        <strong>تاریخ نصب:</strong> 
                        <?php echo date('Y/m/d H:i', strtotime($installed_modules[$key]['activated_at'])) ?>
                    </small>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <?php if ($is_installed): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="module" value="<?php echo $key ?>">
                        <?php if ($is_active): ?>
                            <button type="submit" name="operation" value="deactivate" 
                                    class="btn btn-warning btn-sm">
                                <i class="bi bi-pause-circle me-1"></i>غیرفعال کردن
                            </button>
                        <?php else: ?>
                            <button type="submit" name="operation" value="activate" 
                                    class="btn btn-success btn-sm">
                                <i class="bi bi-play-circle me-1"></i>فعال کردن
                            </button>
                        <?php endif; ?>
                    </form>
                    
                    <?php if ($is_active): ?>
                    <a href="?page=modules&action=config&module=<?php echo $key ?>" 
                       class="btn btn-outline-primary btn-sm">
                        <i class="bi bi-gear me-1"></i>تنظیمات
                    </a>
                    <?php endif; ?>
                <?php else: ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="module" value="<?php echo $key ?>">
                        <button type="submit" name="operation" value="activate" 
                                class="btn btn-primary btn-sm">
                            <i class="bi bi-download me-1"></i>نصب و فعال‌سازی
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Modal نصب ماژول -->
<div class="modal fade" id="installModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">نصب ماژول جدید</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    برای نصب ماژول جدید، فایل ZIP ماژول را در پوشه modules قرار دهید.
                </div>
                
                <div class="mb-3">
                    <label for="moduleFile" class="form-label">فایل ماژول (ZIP)</label>
                    <input type="file" class="form-control" id="moduleFile" accept=".zip">
                </div>
                
                <div class="alert alert-warning">
                    <strong>توجه:</strong> فقط ماژول‌های معتبر و امن را نصب کنید.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button type="button" class="btn btn-primary">نصب ماژول</button>
            </div>
        </div>
    </div>
</div>

<?php if ($action === 'config' && $module_name): ?>
<div class="mt-4">
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">تنظیمات ماژول <?php echo htmlspecialchars($available_modules[$module_name]['name'] ?? $module_name) ?></h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-gear me-2"></i>
                تنظیمات این ماژول در نسخه‌های آینده اضافه خواهد شد.
            </div>
            
            <form>
                <div class="mb-3">
                    <label class="form-label">وضعیت ماژول</label>
                    <select class="form-select">
                        <option>فعال</option>
                        <option>غیرفعال</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="autoUpdate">
                        <label class="form-check-label" for="autoUpdate">
                            به‌روزرسانی خودکار
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">ذخیره تنظیمات</button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
