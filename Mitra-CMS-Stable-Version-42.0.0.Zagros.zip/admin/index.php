<?php
session_start();

// بررسی ورود و دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || !in_array($_SESSION['role'], ['admin', 'editor'])) {
    header('Location: ../auth.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// بررسی نصب
if (!file_exists('../.installed')) {
    header('Location: ../install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
require_once '../config/app.php';
$dbConfig = [];
if (file_exists('../config/database.php')) {
    $dbConfig = require '../config/database.php';
}

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        return $pdo;
    } catch (PDOException $e) {
        die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
    }
}

$pdo = getDatabase();

// دریافت تنظیمات سایت
$stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE group_name = 'general'");
$stmt->execute();
$settings = [];
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$siteName = $settings['site_name'] ?? 'Mitra CMS';
$currentPage = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت - <?php echo htmlspecialchars($siteName) ?></title>
    <link href="../styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="../styles/vazirmatn.css" rel="stylesheet">
    <link href="../styles/bootstrap-icons.css" rel="stylesheet">
    <link href="../styles/style.rtl.css" rel="stylesheet">
    <script src="../scripts/tinymce.min.js" referrerpolicy="origin"></script>
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="p-3">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4>پنل مدیریت</h4>
                <button class="btn btn-link text-white d-md-none" id="closeSidebar">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="text-center mb-4">
                <i class="bi bi-person-circle display-6"></i>
                <div class="mt-2">
                    <strong><?php echo htmlspecialchars($_SESSION['username']) ?></strong>
                    <br>
                    <small class="text-white-50"><?php echo htmlspecialchars($_SESSION['role']) ?></small>
                </div>
            </div>
        </div>
        
        <nav class="nav flex-column px-3">
            <a class="nav-link <?php echo $currentPage === 'dashboard' ? 'active' : '' ?>" href="?page=dashboard">
                <i class="bi bi-speedometer2 me-2"></i> داشبورد
            </a>
            
            <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
            <a class="nav-link <?php echo $currentPage === 'posts' ? 'active' : '' ?>" href="?page=posts">
                <i class="bi bi-file-text me-2"></i> مطالب
            </a>
            <a class="nav-link <?php echo $currentPage === 'pages' ? 'active' : '' ?>" href="?page=pages">
                <i class="bi bi-file-earmark me-2"></i> صفحات
            </a>
            <a class="nav-link <?php echo $currentPage === 'comments' ? 'active' : '' ?>" href="?page=comments">
                <i class="bi bi-chat-dots me-2"></i> نظرات
            </a>
            <a class="nav-link <?php echo $currentPage === 'media' ? 'active' : '' ?>" href="?page=media">
                <i class="bi bi-images me-2"></i> رسانه
            </a>
            <?php endif; ?>
            
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a class="nav-link <?php echo $currentPage === 'users' ? 'active' : '' ?>" href="?page=users">
                <i class="bi bi-people me-2"></i> کاربران
            </a>
            <a class="nav-link <?php echo $currentPage === 'categories' ? 'active' : '' ?>" href="?page=categories">
                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
            </a>
            <a class="nav-link <?php echo $currentPage === 'modules' ? 'active' : '' ?>" href="?page=modules">
                <i class="bi bi-puzzle me-2"></i> ماژول‌ها
            </a>
            <a class="nav-link <?php echo $currentPage === 'settings' ? 'active' : '' ?>" href="?page=settings">
                <i class="bi bi-gear me-2"></i> تنظیمات
            </a>
            <?php endif; ?>
            
            <hr class="text-white-50">
            <a class="nav-link" href="../index.php" target="_blank">
                <i class="bi bi-eye me-2"></i> مشاهده سایت
            </a>
            <a class="nav-link" href="../dashboard.php">
                <i class="bi bi-person me-2"></i> داشبورد شخصی
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> خروج
            </a>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-admin px-4">
            <div class="d-flex align-items-center">
                <div class="hamburger me-3" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <h5 class="mb-0">
                    <?php
                    $pageTitle = [
                        'dashboard' => 'داشبورد',
                        'posts' => 'مدیریت مطالب',
                        'pages' => 'مدیریت صفحات',
                        'users' => 'مدیریت کاربران',
                        'categories' => 'مدیریت دسته‌بندی‌ها',
                        'modules' => 'مدیریت ماژول‌ها',
                        'comments' => 'مدیریت نظرات',
                        'media' => 'مدیریت رسانه',
                        'settings' => 'تنظیمات سیستم'
                    ];
                    echo $pageTitle[$currentPage] ?? 'پنل مدیریت';
                    ?>
                </h5>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><?php echo date('Y/m/d H:i') ?></span>
                <a href="../index.php" class="btn btn-outline-primary btn-sm" target="_blank">
                    <i class="bi bi-eye"></i> مشاهده سایت
                </a>
            </div>
        </nav>
        
        <!-- Page Content -->
        <div class="p-4">
            <?php
            // بارگذاری محتوای صفحه
            switch ($currentPage) {
                case 'dashboard':
                    include 'pages/dashboard.php';
                    break;
                case 'posts':
                    include 'pages/posts.php';
                    break;
                case 'pages':
                    include 'pages/pages.php';
                    break;
                case 'comments':
                    include 'pages/comments.php';
                    break;
                case 'media':
                    include 'pages/media.php';
                    break;
                case 'users':
                    if ($_SESSION['role'] === 'admin') {
                        include 'pages/users.php';
                    } else {
                        echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
                    }
                    break;
                case 'categories':
                    if ($_SESSION['role'] === 'admin') {
                        include 'pages/categories.php';
                    } else {
                        echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
                    }
                    break;
                case 'modules':
                    if ($_SESSION['role'] === 'admin') {
                        include 'pages/modules.php';
                    } else {
                        echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
                    }
                    break;
                case 'settings':
                    if ($_SESSION['role'] === 'admin') {
                        include 'pages/settings.php';
                    } else {
                        echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
                    }
                    break;
                default:
                    echo '<div class="alert alert-warning">صفحه مورد نظر یافت نشد.</div>';
            }
            ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Responsive Sidebar
        const hamburger = document.getElementById('hamburger');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const closeSidebar = document.getElementById('closeSidebar');
        
        function toggleSidebar() {
            sidebar.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');
        }
        
        hamburger.addEventListener('click', toggleSidebar);
        closeSidebar.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);
        
        // Close sidebar on window resize if mobile
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('show');
            }
        });
    </script>
</body>
</html>
