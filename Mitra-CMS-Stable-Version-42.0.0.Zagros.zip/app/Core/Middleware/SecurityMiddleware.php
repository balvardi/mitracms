<?php

namespace App\Core\Middleware;

use App\Core\Security;

class SecurityMiddleware
{
    private $security;

    public function __construct()
    {
        $this->security = Security::getInstance();
    }

    public function handle($request, $next)
    {
        // Security headers
        $this->setSecurityHeaders();

        // Rate limiting
        $this->checkRateLimit();

        // Input sanitization
        $this->sanitizeInput();

        // CSRF protection for POST requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->verifyCsrfToken();
        }

        return $next($request);
    }

    private function setSecurityHeaders(): void
    {
        // Prevent XSS attacks
        header('X-XSS-Protection: 1; mode=block');
        
        // Prevent MIME type sniffing
        header('X-Content-Type-Options: nosniff');
        
        // Prevent clickjacking
        header('X-Frame-Options: DENY');
        
        // HSTS (if using HTTPS)
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
        
        // Content Security Policy
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'");
        
        // Referrer Policy
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    private function checkRateLimit(): void
    {
        $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        // General rate limiting
        if (!$this->security->checkRateLimit("general_{$clientIp}", 100, 300)) {
            http_response_code(429);
            echo json_encode(['error' => 'Rate limit exceeded']);
            exit;
        }

        // Suspicious activity detection
        if ($this->detectSuspiciousActivity($clientIp, $userAgent)) {
            $this->security->logSecurityEvent('suspicious_activity', [
                'ip' => $clientIp,
                'user_agent' => $userAgent,
                'request_uri' => $_SERVER['REQUEST_URI'] ?? ''
            ]);
            
            http_response_code(403);
            echo json_encode(['error' => 'Access denied']);
            exit;
        }
    }

    private function sanitizeInput(): void
    {
        // Sanitize GET parameters
        if (!empty($_GET)) {
            $_GET = $this->sanitizeArray($_GET);
        }

        // Sanitize POST parameters
        if (!empty($_POST)) {
            $_POST = $this->sanitizeArray($_POST);
        }
    }

    private function sanitizeArray(array $data): array
    {
        $sanitized = [];
        
        foreach ($data as $key => $value) {
            $key = $this->security->sanitizeInput($key);
            
            if (is_array($value)) {
                $sanitized[$key] = $this->sanitizeArray($value);
            } else {
                $sanitized[$key] = $this->security->sanitizeInput($value);
            }
        }
        
        return $sanitized;
    }

    private function verifyCsrfToken(): void
    {
        // Skip CSRF verification for certain endpoints
        $skipCsrf = [
            '/api/webhook',
            '/payment/callback'
        ];

        $requestUri = $_SERVER['REQUEST_URI'] ?? '';
        
        foreach ($skipCsrf as $path) {
            if (strpos($requestUri, $path) !== false) {
                return;
            }
        }

        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        
        if (empty($token)) {
            http_response_code(403);
            echo json_encode(['error' => 'CSRF token missing']);
            exit;
        }

        // Extract action from request
        $action = $this->extractCsrfAction();
        
        if (!$this->security->verifyCSRFToken($token, $action)) {
            http_response_code(403);
            echo json_encode(['error' => 'Invalid CSRF token']);
            exit;
        }
    }

    private function extractCsrfAction(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($uri, PHP_URL_PATH);
        
        // Map paths to CSRF actions
        $actionMap = [
            '/checkout/process' => 'checkout',
            '/forms/' => 'form_submit',
            '/admin/forms/create' => 'form_create',
            '/admin/users/create' => 'user_create',
            '/admin/products/create' => 'product_create'
        ];

        foreach ($actionMap as $pathPattern => $action) {
            if (strpos($path, $pathPattern) !== false) {
                return $action;
            }
        }

        return 'default';
    }

    private function detectSuspiciousActivity(string $ip, string $userAgent): bool
    {
        // Check for common attack patterns
        $suspiciousPatterns = [
            'sqlmap',
            'nikto',
            'nmap',
            'masscan',
            'burp',
            'acunetix',
            'nessus',
            '<script',
            'javascript:',
            'eval(',
            'base64_decode',
            'UNION SELECT',
            'DROP TABLE',
            'INSERT INTO',
            'UPDATE SET',
            'DELETE FROM'
        ];

        $requestData = strtolower($_SERVER['REQUEST_URI'] . ' ' . $userAgent);
        
        foreach ($suspiciousPatterns as $pattern) {
            if (strpos($requestData, strtolower($pattern)) !== false) {
                return true;
            }
        }

        // Check for rapid requests from same IP
        if (!$this->security->checkRateLimit("rapid_{$ip}", 20, 60)) {
            return true;
        }

        return false;
    }
}
