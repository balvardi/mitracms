-- Seed data for E-commerce module

-- Insert default roles
INSERT INTO roles (name, slug, description, permissions, level) VALUES
('Super Admin', 'super-admin', 'Full system access', '["*"]', 10),
('Admin', 'admin', 'Administrative access', '["users.*", "content.*", "ecommerce.*", "forms.*", "system.settings"]', 8),
('Shop Manager', 'shop-manager', 'E-commerce management', '["ecommerce.*", "content.view", "forms.view"]', 6),
('Editor', 'editor', 'Content management', '["content.*", "forms.view"]', 4),
('Customer', 'customer', 'Customer access', '["ecommerce.view"]', 2);

-- Insert product categories
INSERT INTO product_categories (name, slug, description, sort_order) VALUES
('الکترونیک', 'electronics', 'محصولات الکترونیکی و دیجیتال', 1),
('پوشاک', 'clothing', 'لباس و پوشاک', 2),
('خانه و آشپزخانه', 'home-kitchen', 'لوازم خانگی و آشپزخانه', 3),
('کتاب', 'books', 'کتاب و نشریات', 4),
('ورزش', 'sports', 'لوازم ورزشی', 5);

-- Insert product brands
INSERT INTO product_brands (name, slug, description) VALUES
('سامسونگ', 'samsung', 'برند کره‌ای الکترونیک'),
('اپل', 'apple', 'برند آمریکایی فناوری'),
('ایران خودرو', 'iran-khodro', 'خودروساز ایرانی'),
('پارس خزر', 'pars-khazar', 'برند ایرانی لوازم خانگی');

-- Insert sample products
INSERT INTO products (name, slug, description, short_description, price, sku, stock_quantity, category_id, brand_id, status, featured, created_by) VALUES
('گوشی هوشمند Galaxy S23', 'galaxy-s23', 'گوشی هوشمند پیشرفته سامسونگ با قابلیت‌های فوق‌العاده', 'گوشی هوشمند سامسونگ', 25000000.00, 'GALAXY-S23-001', 50, 1, 1, 'published', 1, 1),
('لپ‌تاپ MacBook Pro', 'macbook-pro', 'لپ‌تاپ حرفه‌ای اپل برای کارهای سنگین', 'لپ‌تاپ اپل', 45000000.00, 'MBP-001', 20, 1, 2, 'published', 1, 1),
('تی‌شرت مردانه', 'mens-tshirt', 'تی‌شرت راحت و با کیفیت', 'تی‌شرت مردانه', 150000.00, 'TSHIRT-M-001', 100, 2, NULL, 'published', 0, 1),
('کتاب برنامه‌نویسی PHP', 'php-programming-book', 'آموزش کامل برنامه‌نویسی PHP', 'کتاب آموزش PHP', 250000.00, 'BOOK-PHP-001', 30, 4, NULL, 'published', 1, 1);

-- Insert sample forms
INSERT INTO forms (title, slug, description, fields, settings, status, created_by) VALUES
('فرم تماس با ما', 'contact-us', 'فرم تماس عمومی سایت', 
'[
  {"type": "text", "name": "name", "label": "نام و نام خانوادگی", "required": true},
  {"type": "email", "name": "email", "label": "ایمیل", "required": true},
  {"type": "tel", "name": "phone", "label": "شماره تلفن", "required": false},
  {"type": "select", "name": "subject", "label": "موضوع", "required": true, "options": [
    {"value": "support", "label": "پشتیبانی"},
    {"value": "sales", "label": "فروش"},
    {"value": "general", "label": "عمومی"}
  ]},
  {"type": "textarea", "name": "message", "label": "پیام", "required": true}
]',
'{"email_notifications": {"enabled": true, "recipients": ["admin@example.com"]}}',
'active', 1),

('فرم ثبت‌نام خبرنامه', 'newsletter-signup', 'ثبت‌نام در خبرنامه سایت',
'[
  {"type": "text", "name": "name", "label": "نام", "required": true},
  {"type": "email", "name": "email", "label": "ایمیل", "required": true},
  {"type": "checkbox", "name": "interests", "label": "علایق", "required": false, "options": [
    {"value": "tech", "label": "فناوری"},
    {"value": "fashion", "label": "مد و پوشاک"},
    {"value": "sports", "label": "ورزش"}
  ]}
]',
'{"email_notifications": {"enabled": true, "recipients": ["marketing@example.com"]}}',
'active', 1);

-- Insert sample coupons
INSERT INTO coupons (code, type, value, minimum_amount, usage_limit, expires_at, created_by) VALUES
('WELCOME10', 'percentage', 10.00, 100000.00, 100, DATE_ADD(NOW(), INTERVAL 30 DAY), 1),
('SAVE50K', 'fixed', 50000.00, 500000.00, 50, DATE_ADD(NOW(), INTERVAL 60 DAY), 1),
('NEWUSER', 'percentage', 15.00, 200000.00, 200, DATE_ADD(NOW(), INTERVAL 90 DAY), 1);
