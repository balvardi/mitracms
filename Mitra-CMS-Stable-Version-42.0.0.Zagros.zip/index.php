<?php
session_start();

// بررسی نصب
if (!file_exists('.installed')) {
    header('Location: install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
$dbConfig = [];
if (file_exists('config/database.php')) {
    $dbConfig = require 'config/database.php';
}

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        return $pdo;
    } catch (PDOException $e) {
        die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
    }
}

try {
    $pdo = getDatabase();
    
    // دریافت تنظیمات سایت
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE group_name = 'general'");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    
    // دریافت صفحه اصلی
    $stmt = $pdo->prepare("SELECT * FROM pages WHERE slug = 'home' AND status = 'published'");
    $stmt->execute();
    $homePage = $stmt->fetch();
    
    // دریافت آخرین مطالب
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name, u.first_name, u.last_name 
        FROM posts p 
        LEFT JOIN categories c ON p.category_id = c.id 
        LEFT JOIN users u ON p.author_id = u.id 
        WHERE p.status = 'published' 
        ORDER BY p.published_at DESC 
        LIMIT 6
    ");
    $stmt->execute();
    $latestPosts = $stmt->fetchAll();
    
    $siteName = $settings['site_name'] ?? 'Mitra CMS';
    $siteDescription = $settings['site_description'] ?? 'سیستم مدیریت محتوای میترا';
    
} catch (PDOException $e) {
    die('خطا در بارگذاری صفحه: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteName) ?> - <?php echo htmlspecialchars($siteDescription) ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($siteDescription) ?>">
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
    <link href="styles/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { font-family: "Vazirmatn", sans-serif; }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .card {
            transition: transform 0.3s;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .section-title {
            position: relative;
            margin-bottom: 3rem;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo htmlspecialchars($siteName) ?></a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">صفحه اصلی</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?slug=about">درباره ما</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">وبلاگ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?slug=contact">تماس با ما</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['username']) ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2"></i> داشبورد</a></li>
                                <?php if (in_array($_SESSION['role'], ['admin', 'editor'])): ?>
                                    <li><a class="dropdown-item" href="admin/"><i class="bi bi-gear"></i> پنل مدیریت</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> خروج</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="auth.php">ورود</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="auth.php?action=register">ثبت نام</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">
                        <?php echo $homePage ? htmlspecialchars($homePage['title']) : 'به میترا CMS خوش آمدید' ?>
                    </h1>
                    <p class="lead mb-4">
                        <?php echo $homePage && $homePage['excerpt'] ? htmlspecialchars($homePage['excerpt']) : htmlspecialchars($siteDescription) ?>
                    </p>
                    <div class="d-flex gap-3">
                        <a href="page.php?slug=about" class="btn btn-primary btn-lg">درباره ما</a>
                        <a href="page.php?slug=contact" class="btn btn-outline-light btn-lg">تماس با ما</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="text-center">
                        <i class="bi bi-laptop display-1 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="section-title">ویژگی‌های کلیدی</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <i class="bi bi-speedometer2 display-4 text-primary mb-3"></i>
                            <h5 class="card-title">سرعت بالا</h5>
                            <p class="card-text">سیستم بهینه‌سازی شده برای سرعت و عملکرد بالا</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <i class="bi bi-shield-check display-4 text-success mb-3"></i>
                            <h5 class="card-title">امنیت بالا</h5>
                            <p class="card-text">امنیت پیشرفته و محافظت در برابر تهدیدات</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <i class="bi bi-phone display-4 text-info mb-3"></i>
                            <h5 class="card-title">ریسپانسیو</h5>
                            <p class="card-text">سازگار با تمام دستگاه‌ها و اندازه‌های صفحه</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Latest Posts Section -->
    <?php if (!empty($latestPosts)): ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="section-title">آخرین مطالب</h2>
                </div>
            </div>
            <div class="row">
                <?php foreach (array_slice($latestPosts, 0, 3) as $post): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?php if ($post['featured_image']): ?>
                            <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" class="card-img-top" alt="<?php echo htmlspecialchars($post['title']) ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($post['title']) ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($post['excerpt']) ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($post['first_name'] . ' ' . $post['last_name']) ?>
                                </small>
                                <small class="text-muted">
                                    <?php echo date('Y/m/d', strtotime($post['published_at'])) ?>
                                </small>
                            </div>
                        </div>
                        <div class="card-footer">
                            <a href="post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" class="btn btn-primary btn-sm">ادامه مطلب</a>
                            <?php if ($post['category_name']): ?>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($post['category_name']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center">
                <a href="blog.php" class="btn btn-outline-primary">مشاهده همه مطالب</a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- CTA Section -->
    <section class="py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center text-white">
                    <h2 class="mb-4">آماده شروع هستید؟</h2>
                    <p class="lead mb-4">همین حالا با ما در ارتباط باشید</p>
                    <a href="page.php?slug=contact" class="btn btn-light btn-lg">تماس با ما</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo htmlspecialchars($siteName) ?></h5>
                    <p><?php echo htmlspecialchars($siteDescription) ?></p>
                </div>
                <div class="col-md-3">
                    <h5>لینک‌های مفید</h5>
                    <ul class="list-unstyled">
                        <li><a href="page.php?slug=about" class="text-white-50">درباره ما</a></li>
                        <li><a href="blog.php" class="text-white-50">وبلاگ</a></li>
                        <li><a href="page.php?slug=contact" class="text-white-50">تماس با ما</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>حساب کاربری</h5>
                    <ul class="list-unstyled">
                        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                            <li><a href="dashboard.php" class="text-white-50">داشبورد</a></li>
                            <li><a href="logout.php" class="text-white-50">خروج</a></li>
                        <?php else: ?>
                            <li><a href="auth.php" class="text-white-50">ورود</a></li>
                            <li><a href="auth.php?action=register" class="text-white-50">ثبت نام</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?php echo date('Y') ?> <?php echo htmlspecialchars($siteName) ?>. تمامی حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
