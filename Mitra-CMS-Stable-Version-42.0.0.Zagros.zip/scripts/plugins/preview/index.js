// Exports the "preview" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/preview')
//   ES2015:
//     import 'tinymce/plugins/preview'
require('./plugin.js');