<?php
require_once 'config/database.php';
require_once 'config/app.php';

// Get current page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// تضمین عددی بودن
$per_page = intval($per_page);
$offset = intval($offset);

// Get search and category filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;

// Build WHERE clause
$where_conditions = ["p.status = 'published'"]; // ✅ مشخص کردیم: p.status
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(p.title LIKE ? OR p.content LIKE ? OR p.excerpt LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if ($category_id > 0) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $category_id;
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get total posts count
    $count_sql = "SELECT COUNT(*) FROM posts p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  LEFT JOIN users u ON p.author_id = u.id 
                  WHERE {$where_clause}";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_posts = $count_stmt->fetchColumn();
    $total_pages = ceil($total_posts / $per_page);

    // Get posts - LIMIT و OFFSET مستقیماً (چون عدد هستند و ایمن)
    $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug, u.username as author_name 
            FROM posts p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN users u ON p.author_id = u.id 
            WHERE {$where_clause} 
            ORDER BY p.created_at DESC 
            LIMIT {$per_page} OFFSET {$offset}";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get categories for filter
    $cat_sql = "SELECT * FROM categories WHERE status = 'active' ORDER BY name";
    $cat_stmt = $pdo->query($cat_sql);
    $categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "خطا در دریافت مطالب: " . $e->getMessage();
    $posts = [];
    $categories = [];
    $total_pages = 0;
}

// Helper function to generate excerpt
function generateExcerpt($content, $length = 200) {
    $content = strip_tags($content);
    if (mb_strlen($content) <= $length) {
        return $content;
    }
    return mb_substr($content, 0, $length) . '...';
}

// Helper function to format date
function formatPersianDate($date) {
    $timestamp = strtotime($date);
    $persian_months = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد', 4 => 'تیر',
        5 => 'مرداد', 6 => 'شهریور', 7 => 'مهر', 8 => 'آبان',
        9 => 'آذر', 10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];
    $day = date('j', $timestamp);
    $month = $persian_months[date('n', $timestamp)];
    $year = date('Y', $timestamp);
    return "{$day} {$month} {$year}";
}

$title = 'وبلاگ - ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title) ?></title>
    <meta name="description" content="مطالب و مقالات وبلاگ <?php echo SITE_NAME ?>">
    <!-- Bootstrap RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Vazirmatn', sans-serif;
            background-color: #f8f9fa;
        }
        .blog-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            margin-bottom: 3rem;
        }
        .post-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        .post-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .post-image {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        .post-meta {
            font-size: 0.9rem;
            color: #6c757d;
        }
        .post-title {
            color: #2c3e50;
            text-decoration: none;
            font-weight: bold;
        }
        .post-title:hover {
            color: #667eea;
        }
        .category-badge {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            text-decoration: none;
        }
        .category-badge:hover {
            color: white;
            opacity: 0.8;
        }
        .search-form {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 3rem;
        }
        .pagination .page-link {
            border-radius: 10px;
            margin: 0 2px;
            border: none;
            color: #667eea;
        }
        .pagination .page-item.active .page-link {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
        }
        .no-posts {
            text-align: center;
            padding: 4rem 0;
            color: #6c757d;
        }
        .sidebar {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(45deg, #667eea, #764ba2);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><?php echo SITE_NAME ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="blog.php">وبلاگ</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-person-circle"></i> ورود
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Blog Header -->
    <div class="blog-header">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">وبلاگ</h1>
            <p class="lead">آخرین مطالب و مقالات</p>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Search and Filter Form -->
                <div class="search-form">
                    <form method="GET" class="row g-3">
                        <div class="col-md-6">
                            <label for="search" class="form-label">جستجو در مطالب</label>
                            <input type="text" class="form-control" id="search" name="search" 
                                   value="<?php echo htmlspecialchars($search) ?>" placeholder="عنوان، محتوا یا خلاصه...">
                        </div>
                        <div class="col-md-4">
                            <label for="category" class="form-label">دسته‌بندی</label>
                            <select class="form-select" id="category" name="category">
                                <option value="0">همه دسته‌ها</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id'] ?>" <?php echo $category_id == $cat['id'] ? 'selected' : '' ?>>
                                        <?php echo htmlspecialchars($cat['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> جستجو
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Posts List -->
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> <?php echo $error ?>
                    </div>
                <?php elseif (empty($posts)): ?>
                    <div class="no-posts">
                        <i class="bi bi-journal-x" style="font-size: 4rem; color: #dee2e6;"></i>
                        <h3 class="mt-3">مطلبی یافت نشد</h3>
                        <p>متأسفانه مطلبی با این معیارها پیدا نشد.</p>
                        <?php if (!empty($search) || $category_id > 0): ?>
                            <a href="blog.php" class="btn btn-outline-primary">نمایش همه مطالب</a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                        <article class="card post-card">
                            <div class="row g-0">
                                <?php if (!empty($post['featured_image'])): ?>
                                    <div class="col-md-4">
                                        <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" 
                                             class="post-image" alt="<?php echo htmlspecialchars($post['title']) ?>">
                                    </div>
                                    <div class="col-md-8">
                                <?php else: ?>
                                    <div class="col-12">
                                <?php endif; ?>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <?php if (!empty($post['category_name'])): ?>
                                                <a href="blog.php?category=<?php echo $post['category_id'] ?>" 
                                                   class="category-badge">
                                                    <?php echo htmlspecialchars($post['category_name']) ?>
                                                </a>
                                            <?php endif; ?>
                                            <small class="post-meta">
                                                <i class="bi bi-calendar3"></i>
                                                <?php echo formatPersianDate($post['created_at']) ?>
                                            </small>
                                        </div>
                                        <h5 class="card-title">
                                            <a href="post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" 
                                               class="post-title">
                                                <?php echo htmlspecialchars($post['title']) ?>
                                            </a>
                                        </h5>
                                        <p class="card-text text-muted">
                                            <?php echo htmlspecialchars(generateExcerpt($post['excerpt'] ?: $post['content'])) ?>
                                        </p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="post-meta">
                                                <i class="bi bi-person"></i>
                                                نویسنده: <?php echo htmlspecialchars($post['author_name']) ?>
                                            </small>
                                            <a href="post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" 
                                               class="btn btn-outline-primary btn-sm">
                                                ادامه مطلب <i class="bi bi-arrow-left"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="صفحه‌بندی مطالب" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1 ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <i class="bi bi-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                $start = max(1, $page - 2);
                                $end = min($total_pages, $page + 2);
                                for ($i = $start; $i <= $end; $i++):
                                ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?php echo $i ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <?php echo $i ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1 ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <i class="bi bi-chevron-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <div class="text-center text-muted mt-3">
                            صفحه <?php echo $page ?> از <?php echo $total_pages ?> 
                            (<?php echo $total_posts ?> مطلب)
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Categories Widget -->
                <?php if (!empty($categories)): ?>
                    <div class="sidebar">
                        <h5 class="fw-bold mb-3">
                            <i class="bi bi-folder"></i> دسته‌بندی‌ها
                        </h5>
                        <div class="list-group list-group-flush">
                            <a href="blog.php" class="list-group-item list-group-item-action border-0 <?php echo $category_id == 0 ? 'active' : '' ?>">
                                همه مطالب
                                <span class="badge bg-secondary rounded-pill"><?php echo $total_posts ?></span>
                            </a>
                            <?php foreach ($categories as $cat): ?>
                                <?php
                                // Get post count for this category
                                $cat_count_sql = "SELECT COUNT(*) FROM posts WHERE category_id = ? AND status = 'published'";
                                $cat_count_stmt = $pdo->prepare($cat_count_sql);
                                $cat_count_stmt->execute([$cat['id']]);
                                $cat_count = $cat_count_stmt->fetchColumn();
                                ?>
                                <a href="blog.php?category=<?php echo $cat['id'] ?>" 
                                   class="list-group-item list-group-item-action border-0 <?php echo $category_id == $cat['id'] ? 'active' : '' ?>">
                                    <?php echo htmlspecialchars($cat['name']) ?>
                                    <span class="badge bg-secondary rounded-pill"><?php echo $cat_count ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Recent Posts Widget -->
                <?php
                try {
                    $recent_sql = "SELECT title, slug, created_at FROM posts WHERE status = 'published' ORDER BY created_at DESC LIMIT 5";
                    $recent_stmt = $pdo->query($recent_sql);
                    $recent_posts = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    $recent_posts = [];
                }
                ?>
                <?php if (!empty($recent_posts)): ?>
                    <div class="sidebar">
                        <h5 class="fw-bold mb-3">
                            <i class="bi bi-clock-history"></i> آخرین مطالب
                        </h5>
                        <div class="list-group list-group-flush">
                            <?php foreach ($recent_posts as $recent): ?>
                                <a href="post.php?slug=<?php echo htmlspecialchars($recent['slug']) ?>" 
                                   class="list-group-item list-group-item-action border-0">
                                    <div class="fw-bold"><?php echo htmlspecialchars($recent['title']) ?></div>
                                    <small class="text-muted">
                                        <i class="bi bi-calendar3"></i>
                                        <?php echo formatPersianDate($recent['created_at']) ?>
                                    </small>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">&copy; <?php echo date('Y') ?> <?php echo SITE_NAME ?> - تمامی حقوق محفوظ است</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>