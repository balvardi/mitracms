<?php
/**
 * نصاب دیباگ - برای تست و رفع مشکل
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>اطلاعات دیباگ</h2>";

echo "<h3>اطلاعات PHP:</h3>";
echo "نسخه PHP: " . PHP_VERSION . "<br>";
echo "افزونه PDO MySQL: " . (extension_loaded('pdo_mysql') ? 'نصب شده' : 'نصب نشده') . "<br>";

echo "<h3>اطلاعات Session:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h3>اطلاعات POST:</h3>";
echo "<pre>";
print_r($_POST);
echo "</pre>";

echo "<h3>اطلاعات GET:</h3>";
echo "<pre>";
print_r($_GET);
echo "</pre>";

echo "<h3>تست اتصال پایگاه داده:</h3>";
if (isset($_POST['test_connection'])) {
    try {
        $host = $_POST['db_host'] ?? 'localhost';
        $port = $_POST['db_port'] ?? '3306';
        $database = $_POST['db_name'] ?? 'test';
        $username = $_POST['db_username'] ?? '';
        $password = $_POST['db_password'] ?? '';
        
        $dsn = "mysql:host={$host};port={$port};charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo "<div style='color: green;'>✓ اتصال موفقیت‌آمیز</div>";
        
        // تست ایجاد پایگاه داده
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "<div style='color: green;'>✓ پایگاه داده ایجاد شد</div>";
        
    } catch (PDOException $e) {
        echo "<div style='color: red;'>✗ خطا: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>دیباگ نصاب</title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>تست اتصال پایگاه داده</h2>
        <form method="post">
            <div class="mb-3">
                <label class="form-label">آدرس سرور</label>
                <input type="text" class="form-control" name="db_host" value="localhost">
            </div>
            <div class="mb-3">
                <label class="form-label">پورت</label>
                <input type="text" class="form-control" name="db_port" value="3306">
            </div>
            <div class="mb-3">
                <label class="form-label">نام پایگاه داده</label>
                <input type="text" class="form-control" name="db_name" value="mitracms">
            </div>
            <div class="mb-3">
                <label class="form-label">نام کاربری</label>
                <input type="text" class="form-control" name="db_username" value="">
            </div>
            <div class="mb-3">
                <label class="form-label">رمز عبور</label>
                <input type="password" class="form-control" name="db_password" value="">
            </div>
            <button type="submit" name="test_connection" class="btn btn-primary">تست اتصال</button>
        </form>
        
        <hr>
        <a href="simple-installer.php" class="btn btn-success">استفاده از نصاب ساده</a>
    </div>
</body>
</html>
