<?php
// تنظیمات کلی برنامه
define('DB_HOST', 'localhost');
define('DB_NAME', 'mitra_cms');
define('DB_USER', 'admin');
define('DB_PASS', 'admin');
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'Mitra CMS');
define('SITE_URL', 'http://localhost/mitra-cms');
define('ADMIN_URL', SITE_URL . '/admin');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// تنظیمات امنیتی
define('SESSION_LIFETIME', 3600); // 1 ساعت
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 دقیقه

// تنظیمات آپلود
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_FILE_TYPES', ['pdf', 'doc', 'docx', 'txt', 'zip']);

return [
    'site_name' => 'Mitra CMS',
    'site_description' => 'سیستم مدیریت محتوای میترا',
    'admin_email' => 'admin@example.com',
    'timezone' => 'Asia/Tehran',
    'language' => 'fa',
    'theme' => 'default'
];
?>
