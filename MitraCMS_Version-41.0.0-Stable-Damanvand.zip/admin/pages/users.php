<?php
// مدیریت کاربران (فقط برای ادمین)
if ($_SESSION['role'] !== 'admin') {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

// پردازش فرم‌ها
if ($_POST) {
    if ($action === 'add' || $action === 'edit') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $first_name = trim($_POST['first_name'] ?? '');
        $last_name = trim($_POST['last_name'] ?? '');
        $role = $_POST['role'] ?? 'user';
        $status = $_POST['status'] ?? 'active';
        $bio = trim($_POST['bio'] ?? '');
        
        if (empty($username) || empty($email) || empty($first_name) || empty($last_name)) {
            $error = 'تمام فیلدهای الزامی را پر کنید';
        } else {
            try {
                if ($action === 'add') {
                    $password = $_POST['password'] ?? '';
                    if (empty($password)) {
                        $error = 'رمز عبور الزامی است';
                    } elseif (strlen($password) < 6) {
                        $error = 'رمز عبور باید حداقل 6 کاراکتر باشد';
                    } else {
                        // بررسی تکراری نبودن
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                        $stmt->execute([$username, $email]);
                        
                        if ($stmt->fetchColumn() > 0) {
                            $error = 'نام کاربری یا ایمیل قبلاً استفاده شده است';
                        } else {
                            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("
                                INSERT INTO users (username, email, password, first_name, last_name, role, status, bio) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            ");
                            if ($stmt->execute([$username, $email, $hashedPassword, $first_name, $last_name, $role, $status, $bio])) {
                                $message = 'کاربر با موفقیت ایجاد شد';
                                $action = 'list';
                            } else {
                                $error = 'خطا در ایجاد کاربر';
                            }
                        }
                    }
                } elseif ($action === 'edit') {
                    $id = $_POST['id'] ?? 0;
                    $password = $_POST['password'] ?? '';
                    
                    if (!empty($password) && strlen($password) < 6) {
                        $error = 'رمز عبور باید حداقل 6 کاراکتر باشد';
                    } else {
                        if (!empty($password)) {
                            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("
                                UPDATE users 
                                SET username = ?, email = ?, password = ?, first_name = ?, last_name = ?, role = ?, status = ?, bio = ? 
                                WHERE id = ?
                            ");
                            $params = [$username, $email, $hashedPassword, $first_name, $last_name, $role, $status, $bio, $id];
                        } else {
                            $stmt = $pdo->prepare("
                                UPDATE users 
                                SET username = ?, email = ?, first_name = ?, last_name = ?, role = ?, status = ?, bio = ? 
                                WHERE id = ?
                            ");
                            $params = [$username, $email, $first_name, $last_name, $role, $status, $bio, $id];
                        }
                        
                        if ($stmt->execute($params)) {
                            $message = 'کاربر با موفقیت به‌روزرسانی شد';
                            $action = 'list';
                        } else {
                            $error = 'خطا در به‌روزرسانی کاربر';
                        }
                    }
                }
            } catch (PDOException $e) {
                $error = 'خطا: ' . $e->getMessage();
            }
        }
    }
}

// حذف کاربر
if ($action === 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    if ($id == $_SESSION['user_id']) {
        $error = 'نمی‌توانید خودتان را حذف کنید';
    } else {
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            if ($stmt->execute([$id])) {
                $message = 'کاربر با موفقیت حذف شد';
            } else {
                $error = 'خطا در حذف کاربر';
            }
            $action = 'list';
        } catch (PDOException $e) {
            $error = 'خطا: ' . $e->getMessage();
        }
    }
}

// دریافت کاربران
$users = [];
if ($action === 'list') {
    try {
        $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
        $users = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = 'خطا در دریافت کاربران: ' . $e->getMessage();
    }
}

// دریافت کاربر برای ویرایش
$editUser = null;
if ($action === 'edit' && isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $editUser = $stmt->fetch();
        
        if (!$editUser) {
            $error = 'کاربر یافت نشد';
            $action = 'list';
        }
    } catch (PDOException $e) {
        $error = 'خطا: ' . $e->getMessage();
        $action = 'list';
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>مدیریت کاربران</h2>
    <?php if ($action === 'list'): ?>
        <a href="?page=users&action=add" class="btn btn-primary">
            <i class="bi bi-person-plus"></i> افزودن کاربر جدید
        </a>
    <?php else: ?>
        <a href="?page=users" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت به لیست
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'list'): ?>
    <!-- لیست کاربران -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($users)): ?>
                <div class="alert alert-info text-center">
                    <i class="bi bi-people display-6 d-block mb-3"></i>
                    <h5>کاربری یافت نشد</h5>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>نام کاربری</th>
                                <th>نام و نام خانوادگی</th>
                                <th>ایمیل</th>
                                <th>نقش</th>
                                <th>وضعیت</th>
                                <th>تاریخ عضویت</th>
                                <th>آخرین ورود</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['username']) ?></strong>
                                        <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                            <span class="badge bg-info">شما</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></td>
                                    <td><?php echo htmlspecialchars($user['email']) ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'editor' ? 'warning' : 'primary') ?>">
                                            <?php echo htmlspecialchars($user['role']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'secondary' ?>">
                                            <?php echo $user['status'] === 'active' ? 'فعال' : 'غیرفعال' ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y/m/d', strtotime($user['created_at'])) ?></td>
                                    <td>
                                        <?php echo $user['last_login'] ? date('Y/m/d H:i', strtotime($user['last_login'])) : 'هرگز' ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="?page=users&action=edit&id=<?php echo $user['id'] ?>" class="btn btn-outline-primary" title="ویرایش">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                <a href="?page=users&action=delete&id=<?php echo $user['id'] ?>" class="btn btn-outline-danger" title="حذف"
                                                   onclick="return confirm('آیا از حذف این کاربر مطمئن هستید؟')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php elseif ($action === 'add' || $action === 'edit'): ?>
    <!-- فرم افزودن/ویرایش کاربر -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-<?php echo $action === 'add' ? 'person-plus' : 'pencil' ?>"></i>
                <?php echo $action === 'add' ? 'افزودن کاربر جدید' : 'ویرایش کاربر' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="post">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?php echo $editUser['id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">نام <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="first_name" 
                                   value="<?php echo htmlspecialchars($editUser['first_name'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">نام خانوادگی <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="last_name" 
                                   value="<?php echo htmlspecialchars($editUser['last_name'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">نام کاربری <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="username" 
                                   value="<?php echo htmlspecialchars($editUser['username'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">ایمیل <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?php echo htmlspecialchars($editUser['email'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">رمز عبور <?php echo $action === 'add' ? '<span class="text-danger">*</span>' : '' ?></label>
                            <input type="password" class="form-control" name="password" 
                                   <?php echo $action === 'add' ? 'required' : '' ?>>
                            <?php if ($action === 'edit'): ?>
                                <div class="form-text">برای تغییر رمز عبور، رمز جدید را وارد کنید. در غیر این صورت خالی بگذارید.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">نقش</label>
                            <select class="form-select" name="role">
                                <option value="user" <?php echo ($editUser['role'] ?? '') === 'user' ? 'selected' : '' ?>>
                                    کاربر عادی
                                </option>
                                <option value="author" <?php echo ($editUser['role'] ?? '') === 'author' ? 'selected' : '' ?>>
                                    نویسنده
                                </option>
                                <option value="editor" <?php echo ($editUser['role'] ?? '') === 'editor' ? 'selected' : '' ?>>
                                    ویرایشگر
                                </option>
                                <option value="admin" <?php echo ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>
                                    مدیر
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">وضعیت</label>
                            <select class="form-select" name="status">
                                <option value="active" <?php echo ($editUser['status'] ?? '') === 'active' ? 'selected' : '' ?>>
                                    فعال
                                </option>
                                <option value="inactive" <?php echo ($editUser['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                                    غیرفعال
                                </option>
                                <option value="banned" <?php echo ($editUser['status'] ?? '') === 'banned' ? 'selected' : '' ?>>
                                    مسدود
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">درباره کاربر</label>
                    <textarea class="form-control" name="bio" rows="4"><?php echo htmlspecialchars($editUser['bio'] ?? '') ?></textarea>
                </div>
                
                <hr>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i>
                        <?php echo $action === 'add' ? 'ایجاد کاربر' : 'به‌روزرسانی کاربر' ?>
                    </button>
                    <a href="?page=users" class="btn btn-secondary">
                        <i class="bi bi-x-circle"></i> انصراف
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
