<?php
// تنظیمات سیستم (فقط برای ادمین)
if ($_SESSION['role'] !== 'admin') {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$message = '';
$error = '';

// پردازش فرم تنظیمات
if ($_POST) {
    try {
        foreach ($_POST as $key => $value) {
            if ($key !== 'submit') {
                $stmt = $pdo->prepare("
                    UPDATE settings 
                    SET setting_value = ? 
                    WHERE setting_key = ?
                ");
                $stmt->execute([$value, $key]);
            }
        }
        $message = 'تنظیمات با موفقیت ذخیره شد';
    } catch (PDOException $e) {
        $error = 'خطا در ذخیره تنظیمات: ' . $e->getMessage();
    }
}

// دریافت تنظیمات
$allSettings = [];
try {
    $stmt = $pdo->query("SELECT * FROM settings ORDER BY group_name, setting_key");
    while ($row = $stmt->fetch()) {
        $allSettings[$row['group_name']][] = $row;
    }
} catch (PDOException $e) {
    $error = 'خطا در دریافت تنظیمات: ' . $e->getMessage();
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>تنظیمات سیستم</h2>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<form method="post">
    <?php foreach ($allSettings as $groupName => $groupSettings): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="bi bi-gear"></i>
                    <?php
                    $groupTitles = [
                        'general' => 'تنظیمات عمومی',
                        'reading' => 'تنظیمات خواندن',
                        'discussion' => 'تنظیمات بحث و گفتگو',
                        'appearance' => 'تنظیمات ظاهری'
                    ];
                    echo $groupTitles[$groupName] ?? ucfirst($groupName);
                    ?>
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php foreach ($groupSettings as $setting): ?>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <?php echo htmlspecialchars($setting['description'] ?: $setting['setting_key']) ?>
                            </label>
                            
                            <?php if ($setting['setting_type'] === 'textarea'): ?>
                                <textarea class="form-control" name="<?php echo htmlspecialchars($setting['setting_key']) ?>" rows="4"><?php echo htmlspecialchars($setting['setting_value']) ?></textarea>
                            <?php elseif ($setting['setting_type'] === 'boolean'): ?>
                                <select class="form-select" name="<?php echo htmlspecialchars($setting['setting_key']) ?>">
                                    <option value="1" <?php echo $setting['setting_value'] == '1' ? 'selected' : '' ?>>فعال</option>
                                    <option value="0" <?php echo $setting['setting_value'] == '0' ? 'selected' : '' ?>>غیرفعال</option>
                                </select>
                            <?php elseif ($setting['setting_type'] === 'number'): ?>
                                <input type="number" class="form-control" name="<?php echo htmlspecialchars($setting['setting_key']) ?>" 
                                       value="<?php echo htmlspecialchars($setting['setting_value']) ?>">
                            <?php else: ?>
                                <input type="text" class="form-control" name="<?php echo htmlspecialchars($setting['setting_key']) ?>" 
                                       value="<?php echo htmlspecialchars($setting['setting_value']) ?>">
                            <?php endif; ?>
                            
                            <?php if ($setting['setting_key'] === 'site_url'): ?>
                                <div class="form-text">آدرس کامل سایت شما (بدون / در انتها)</div>
                            <?php elseif ($setting['setting_key'] === 'posts_per_page'): ?>
                                <div class="form-text">تعداد مطالب نمایش داده شده در هر صفحه</div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    
    <div class="d-flex gap-2">
        <button type="submit" name="submit" class="btn btn-primary">
            <i class="bi bi-check-circle"></i> ذخیره تنظیمات
        </button>
        <button type="reset" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-clockwise"></i> بازنشانی
        </button>
    </div>
</form>

<!-- اطلاعات سیستم -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-info-circle"></i> اطلاعات سیستم</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <strong>نسخه PHP:</strong><br>
                <span class="text-muted"><?php echo PHP_VERSION ?></span>
            </div>
            <div class="col-md-3">
                <strong>نسخه MySQL:</strong><br>
                <span class="text-muted">
                    <?php
                    try {
                        $version = $pdo->query('SELECT VERSION()')->fetchColumn();
                        echo htmlspecialchars($version);
                    } catch (Exception $e) {
                        echo 'نامشخص';
                    }
                    ?>
                </span>
            </div>
            <div class="col-md-3">
                <strong>حافظه استفاده شده:</strong><br>
                <span class="text-muted"><?php echo round(memory_get_usage() / 1024 / 1024, 2) ?> MB</span>
            </div>
            <div class="col-md-3">
                <strong>فضای دیسک:</strong><br>
                <span class="text-muted"><?php echo round(disk_free_space('.') / 1024 / 1024 / 1024, 2) ?> GB آزاد</span>
            </div>
        </div>
    </div>
</div>
