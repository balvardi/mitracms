<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <title><?php echo $title ?? 'Mitra CMS' ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap RTL via CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="public/assets/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">Mitra CMS</a>
    </div>
</nav>
<main class="container py-5">
