<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Mitra Global CMS' ?></title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', Arial, sans-serif; }
        .hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 100px 0; }
        .feature-card { transition: transform 0.3s; }
        .feature-card:hover { transform: translateY(-5px); }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <strong>Mitra Global CMS</strong>
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="admin">پنل مدیریت</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero text-center">
        <div class="container">
            <h1 class="display-4 fw-bold"><?php echo $title ?></h1>
            <p class="lead"><?php echo $description ?></p>
            <a href="admin" class="btn btn-light btn-lg mt-3">
                ورود به پنل مدیریت
            </a>
        </div>
    </section>

    <!-- Features -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center p-4">
                        <div class="card-body">
                            <h5 class="card-title">معماری ماژولار</h5>
                            <p class="card-text">سیستم ماژولار انعطاف‌پذیر برای گسترش قابلیت‌ها</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center p-4">
                        <div class="card-body">
                            <h5 class="card-title">قالب‌های زیبا</h5>
                            <p class="card-text">قالب‌های آماده و قابلیت طراحی سفارشی</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100 text-center p-4">
                        <div class="card-body">
                            <h5 class="card-title">بهینه‌سازی SEO</h5>
                            <p class="card-text">ابزارهای کامل SEO برای رتبه‌بندی بهتر</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y') ?> Mitra Global CMS. تمام حقوق محفوظ است.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
