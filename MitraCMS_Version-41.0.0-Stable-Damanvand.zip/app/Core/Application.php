<?php

namespace App\Core;

class Application
{
    private $config;
    private $router;

    public function __construct(array $config = [])
    {
        $this->config = $config;
        $this->router = new Router();
        $this->setupRoutes();
    }

    public function run(): void
    {
        $this->router->dispatch();
    }

    private function setupRoutes(): void
    {
        // صفحه اصلی
        $this->router->get('/', function() {
            $controller = new \App\Controllers\HomeController();
            return $controller->index();
        });

        // پنل مدیریت
        $this->router->get('/admin', function() {
            $controller = new \App\Controllers\AdminController();
            return $controller->dashboard();
        });

        // API
        $this->router->get('/api/test', function() {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'success', 'message' => 'API is working']);
        });
    }
}
