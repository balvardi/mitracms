<?php

namespace Modules\Ecommerce\Models;

use App\Core\Model;
use App\Core\Database;

class Product extends Model
{
    protected $table = 'products';
    protected $fillable = [
        'name', 'slug', 'description', 'short_description', 'price', 'sale_price',
        'sku', 'stock_quantity', 'manage_stock', 'stock_status', 'weight',
        'dimensions', 'category_id', 'brand_id', 'featured_image', 'gallery',
        'status', 'featured', 'meta_title', 'meta_description', 'created_by'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'sale_price' => 'decimal:2',
        'weight' => 'decimal:2',
        'gallery' => 'json',
        'dimensions' => 'json',
        'featured' => 'boolean',
        'manage_stock' => 'boolean'
    ];

    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
    }

    public function create(array $data): int
    {
        // Input validation and sanitization
        $data = $this->validateAndSanitize($data);
        
        $sql = "INSERT INTO {$this->table} (
            name, slug, description, short_description, price, sale_price,
            sku, stock_quantity, manage_stock, stock_status, weight,
            dimensions, category_id, brand_id, featured_image, gallery,
            status, featured, meta_title, meta_description, created_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $data['name'],
            $data['slug'],
            $data['description'],
            $data['short_description'],
            $data['price'],
            $data['sale_price'] ?? null,
            $data['sku'],
            $data['stock_quantity'] ?? 0,
            $data['manage_stock'] ?? false,
            $data['stock_status'] ?? 'in_stock',
            $data['weight'] ?? null,
            json_encode($data['dimensions'] ?? []),
            $data['category_id'] ?? null,
            $data['brand_id'] ?? null,
            $data['featured_image'] ?? null,
            json_encode($data['gallery'] ?? []),
            $data['status'] ?? 'draft',
            $data['featured'] ?? false,
            $data['meta_title'] ?? null,
            $data['meta_description'] ?? null,
            $data['created_by']
        ]);

        return $this->db->lastInsertId();
    }

    public function findBySlug(string $slug): ?array
    {
        $sql = "SELECT p.*, c.name as category_name, b.name as brand_name 
                FROM {$this->table} p 
                LEFT JOIN product_categories c ON p.category_id = c.id 
                LEFT JOIN product_brands b ON p.brand_id = b.id 
                WHERE p.slug = ? AND p.status = 'published'";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$slug]);
        
        $product = $stmt->fetch();
        if ($product) {
            $product['gallery'] = json_decode($product['gallery'], true);
            $product['dimensions'] = json_decode($product['dimensions'], true);
        }
        
        return $product ?: null;
    }

    public function getPublished(int $limit = 20, int $offset = 0): array
    {
        $sql = "SELECT p.*, c.name as category_name 
                FROM {$this->table} p 
                LEFT JOIN product_categories c ON p.category_id = c.id 
                WHERE p.status = 'published' 
                ORDER BY p.created_at DESC 
                LIMIT ? OFFSET ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$limit, $offset]);
        
        return $stmt->fetchAll();
    }

    public function getFeatured(int $limit = 8): array
    {
        $sql = "SELECT p.*, c.name as category_name 
                FROM {$this->table} p 
                LEFT JOIN product_categories c ON p.category_id = c.id 
                WHERE p.status = 'published' AND p.featured = 1 
                ORDER BY p.created_at DESC 
                LIMIT ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$limit]);
        
        return $stmt->fetchAll();
    }

    public function updateStock(int $productId, int $quantity): bool
    {
        $sql = "UPDATE {$this->table} 
                SET stock_quantity = stock_quantity - ?, 
                    stock_status = CASE 
                        WHEN (stock_quantity - ?) <= 0 THEN 'out_of_stock' 
                        ELSE 'in_stock' 
                    END 
                WHERE id = ? AND manage_stock = 1";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$quantity, $quantity, $productId]);
    }

    private function validateAndSanitize(array $data): array
    {
        // Required fields validation
        $required = ['name', 'price', 'sku'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new \InvalidArgumentException("Field {$field} is required");
            }
        }

        // Sanitize inputs
        $data['name'] = htmlspecialchars(trim($data['name']), ENT_QUOTES, 'UTF-8');
        $data['description'] = $this->sanitizeHtml($data['description'] ?? '');
        $data['short_description'] = htmlspecialchars(trim($data['short_description'] ?? ''), ENT_QUOTES, 'UTF-8');
        $data['sku'] = preg_replace('/[^a-zA-Z0-9\-_]/', '', $data['sku']);
        
        // Generate slug if not provided
        if (empty($data['slug'])) {
            $data['slug'] = $this->generateSlug($data['name']);
        }

        // Validate price
        if (!is_numeric($data['price']) || $data['price'] < 0) {
            throw new \InvalidArgumentException("Invalid price");
        }

        // Validate sale price
        if (!empty($data['sale_price'])) {
            if (!is_numeric($data['sale_price']) || $data['sale_price'] < 0) {
                throw new \InvalidArgumentException("Invalid sale price");
            }
        }

        return $data;
    }

    private function sanitizeHtml(string $html): string
    {
        // Allow only safe HTML tags
        $allowedTags = '<p><br><strong><em><ul><ol><li><h1><h2><h3><h4><h5><h6><a><img>';
        return strip_tags($html, $allowedTags);
    }

    private function generateSlug(string $text): string
    {
        // Convert to lowercase and replace spaces with hyphens
        $slug = strtolower(trim($text));
        $slug = preg_replace('/[^a-z0-9\-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');
        
        // Ensure uniqueness
        $originalSlug = $slug;
        $counter = 1;
        
        while ($this->slugExists($slug)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }

    private function slugExists(string $slug): bool
    {
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE slug = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$slug]);
        
        return $stmt->fetchColumn() > 0;
    }
}
