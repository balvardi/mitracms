<?php
// فایل اطلاعات PHP
phpinfo();
?> 