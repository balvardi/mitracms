# Dima CMS - سیستم مدیریت محتوای فارسی

![Dima CMS](https://img.shields.io/badge/Dima-CMS-blue)
![PHP](https://img.shields.io/badge/PHP-8.0+-green)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-orange)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 📋 معرفی

Dima CMS یک سیستم مدیریت محتوای مدرن و امن است که به زبان فارسی طراحی شده است. این سیستم با استفاده از PHP و MySQL ساخته شده و قابلیت‌های پیشرفته‌ای برای مدیریت محتوا، کاربران و ماژول‌ها ارائه می‌دهد.

## ✨ ویژگی‌ها

### 🎯 ویژگی‌های اصلی
- **رابط کاربری فارسی و RTL**: طراحی شده برای کاربران فارسی‌زبان
- **سیستم مدیریت محتوا**: مدیریت مطالب، صفحات و دسته‌بندی‌ها
- **مدیریت کاربران**: سیستم نقش‌ها و دسترسی‌ها
- **سیستم ماژول‌ها**: قابلیت نصب و مدیریت ماژول‌های مختلف
- **امنیت بالا**: محافظت در برابر حملات رایج
- **پنل مدیریت مدرن**: رابط کاربری زیبا و کاربرپسند

### 🔧 ویژگی‌های فنی
- **PHP 8.0+**: استفاده از آخرین نسخه PHP
- **MySQL 5.7+**: پایگاه داده قدرتمند
- **Bootstrap 5**: طراحی ریسپانسیو
- **TinyMCE**: ویرایشگر متن پیشرفته
- **سیستم آپلود امن**: آپلود فایل با بررسی امنیتی

### 🛡️ ویژگی‌های امنیتی
- **CSRF Protection**: محافظت در برابر حملات CSRF
- **XSS Protection**: محافظت در برابر حملات XSS
- **SQL Injection Protection**: استفاده از Prepared Statements
- **File Upload Security**: بررسی امن فایل‌های آپلود شده
- **Session Security**: مدیریت امن جلسات
- **Rate Limiting**: محدودیت تلاش ورود

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها
- PHP 8.0 یا بالاتر
- MySQL 5.7 یا بالاتر
- Apache/Nginx
- Composer (اختیاری)

### مراحل نصب

1. **دانلود پروژه**
```bash
git clone https://github.com/your-username/dima-cms.git
cd dima-cms
```

2. **تنظیم مجوزهای فایل**
```bash
chmod 755 uploads/
chmod 644 config/database.php
chmod 644 .env
```

3. **تنظیم فایل .env**
```bash
cp env.example .env
# ویرایش فایل .env با اطلاعات پایگاه داده
```

4. **ایجاد پایگاه داده**
```sql
CREATE DATABASE dima_cms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'dima_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON dima_cms.* TO 'dima_user'@'localhost';
FLUSH PRIVILEGES;
```

5. **اجرای اسکریپت‌های نصب**
```bash
# اجرای جداول اصلی
mysql -u root -p dima_cms < database/schema.sql

# اجرای جداول ماژول‌ها
mysql -u root -p dima_cms < database/modules.sql

# اجرای جداول امنیتی
mysql -u root -p dima_cms < database/login_attempts.sql
```

6. **دسترسی به نصب‌کننده**
```
http://your-domain.com/install/
```

## 📦 ماژول‌ها

### ماژول فروشگاه (Ecommerce)
- مدیریت محصولات و دسته‌بندی‌ها
- سیستم سبد خرید
- درگاه پرداخت امن
- مدیریت سفارشات
- گزارش‌گیری فروش

### ماژول فرم‌ساز (FormBuilder)
- ایجاد فرم‌های سفارشی
- انواع فیلدهای مختلف
- اعتبارسنجی پیشرفته
- ارسال ایمیل خودکار
- ذخیره پاسخ‌ها

### ماژول مدیریت کاربران (UserManagement)
- مدیریت نقش‌ها و دسترسی‌ها
- احراز هویت دو مرحله‌ای
- تایید ایمیل و شماره تلفن
- مدیریت پروفایل کاربران
- گزارش فعالیت‌ها

## 🔧 تنظیمات

### تنظیمات پایگاه داده
فایل `config/database.php` را ویرایش کنید:
```php
return [
    'host' => $_ENV['DB_HOST'] ?? 'localhost',
    'port' => $_ENV['DB_PORT'] ?? '3306',
    'database' => $_ENV['DB_NAME'] ?? 'dima_cms',
    'username' => $_ENV['DB_USER'] ?? 'dima_user',
    'password' => $_ENV['DB_PASS'] ?? '',
    'charset' => 'utf8mb4'
];
```

### تنظیمات امنیتی
فایل `.env` را ویرایش کنید:
```env
# تنظیمات پایگاه داده
DB_HOST=localhost
DB_PORT=3306
DB_NAME=dima_cms
DB_USER=dima_user
DB_PASS=your_secure_password

# تنظیمات امنیتی
APP_SECRET=your_random_secret_key
SESSION_SECRET=your_session_secret

# تنظیمات آپلود
MAX_FILE_SIZE=5242880
UPLOAD_PATH=uploads
```

## 🛡️ امنیت

### اقدامات امنیتی پیاده‌سازی شده
- **محافظت از اطلاعات حساس**: استفاده از متغیرهای محیطی
- **امنیت جلسه**: تنظیمات امن کوکی‌ها
- **محافظت از حملات**: CSRF, XSS, SQL Injection
- **محدودیت تلاش ورود**: قفل کردن حساب پس از تلاش‌های مکرر
- **امنیت آپلود فایل**: بررسی نوع و محتوای فایل‌ها

### بررسی‌های امنیتی منظم
```bash
# بررسی لاگ‌های خطا
tail -f /var/log/apache2/error.log

# بررسی فایل‌های مشکوک
find uploads/ -name "*.php" -o -name "*.exe"

# به‌روزرسانی منظم
composer update
```

## 📚 مستندات

### API Documentation
- [راهنمای API](docs/api.md)
- [راهنمای ماژول‌ها](docs/modules.md)
- [راهنمای امنیت](docs/security.md)

### توسعه‌دهندگان
- [راهنمای توسعه](docs/development.md)
- [استانداردهای کدنویسی](docs/coding-standards.md)
- [راهنمای تست](docs/testing.md)

## 🤝 مشارکت

ما از مشارکت شما استقبال می‌کنیم! لطفاً قبل از ارسال Pull Request:

1. Fork کنید
2. یک شاخه جدید ایجاد کنید (`git checkout -b feature/amazing-feature`)
3. تغییرات خود را commit کنید (`git commit -m 'Add amazing feature'`)
4. به شاخه اصلی push کنید (`git push origin feature/amazing-feature`)
5. Pull Request ایجاد کنید

### استانداردهای مشارکت
- از PSR-12 برای کدنویسی استفاده کنید
- تست‌های مناسب اضافه کنید
- مستندات را به‌روزرسانی کنید
- تغییرات امنیتی را بررسی کنید

## 📄 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است. برای اطلاعات بیشتر فایل [LICENSE](LICENSE) را مطالعه کنید.

## 🆘 پشتیبانی

### گزارش مشکلات
اگر مشکلی پیدا کردید، لطفاً یک Issue ایجاد کنید:
- [گزارش باگ](https://github.com/your-username/dima-cms/issues/new?template=bug_report.md)
- [درخواست ویژگی](https://github.com/your-username/dima-cms/issues/new?template=feature_request.md)

### مشکلات امنیتی
اگر مشکل امنیتی پیدا کردید، لطفاً مستقیماً به ایمیل زیر گزارش دهید:
security@dimacms.com

### انجمن
- [Discord](https://discord.gg/dimacms)
- [Telegram](https://t.me/dimacms)
- [Website](https://dimacms.com)

## 🙏 تشکر

از تمام کسانی که در توسعه این پروژه مشارکت کرده‌اند تشکر می‌کنیم:

- [Bootstrap](https://getbootstrap.com/) - فریم‌ورک CSS
- [TinyMCE](https://www.tiny.cloud/) - ویرایشگر متن
- [Bootstrap Icons](https://icons.getbootstrap.com/) - آیکون‌ها

## 📊 آمار پروژه

![GitHub stars](https://img.shields.io/github/stars/your-username/dima-cms)
![GitHub forks](https://img.shields.io/github/forks/your-username/dima-cms)
![GitHub issues](https://img.shields.io/github/issues/your-username/dima-cms)
![GitHub pull requests](https://img.shields.io/github/issues-pr/your-username/dima-cms)

---

**Dima CMS** - سیستم مدیریت محتوای مدرن و امن برای فارسی‌زبانان 🌟
