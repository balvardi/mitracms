<?php
require_once 'config/connection.php';
//require_once 'templates/'.$settings['theme'].'/header.php';

// بررسی Rate Limiting
checkRateLimit('auth', 5, 300); // 5 تلاش در 5 دقیقه

$action = $_GET['action'] ?? 'login';
$message = '';
$error = '';
$success = '';

// توابع امنیتی در config/connection.php تعریف شده‌اند

// پردازش فرم ورود
if ($_POST && $action === 'login') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        logSecurityEvent('csrf_token_invalid', ['ip' => $_SERVER['REMOTE_ADDR']]);
        $error = 'توکن امنیتی نامعتبر است';
    } else {
        $username = sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'لطفاً نام کاربری و رمز عبور را وارد کنید';
        } elseif (!checkLoginAttempts($username)) {
            logSecurityEvent('account_locked', ['username' => $username]);
            $error = 'حساب کاربری شما به دلیل تلاش‌های مکرر قفل شده است. لطفاً 15 دقیقه صبر کنید.';
        } else {
            try {
                cleanupOldAttempts();
                
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $username]);
                $user = $stmt->fetch();
                
                if ($user && isset($user['password']) && !empty($user['password']) && password_verify($password, $user['password'])) {
                    if ($user['status'] === 'active') {
                        // بررسی IP (اختیاری)
                        if (isset($_ENV['RESTRICT_LOGIN_IPS']) && $_ENV['RESTRICT_LOGIN_IPS'] === 'true') {
                            checkIP();
                        }
                        
                        logLoginAttempt($username, true);
                        logSecurityEvent('login_successful', ['username' => $username, 'role' => $user['role']]);
                        
                        // بازسازی ID جلسه برای جلوگیری از Session Fixation
                        session_regenerate_id(true);
                        
                        $_SESSION['logged_in'] = true;
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['first_name'] = $user['first_name'];
                        $_SESSION['last_name'] = $user['last_name'];
                        $_SESSION['login_time'] = time();
                        $_SESSION['login_ip'] = $_SERVER['REMOTE_ADDR'];
                        
                        // بروزرسانی اطلاعات ورود
                        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW(), login_ip = ? WHERE id = ?");
                        $stmt->execute([$_SERVER['REMOTE_ADDR'], $user['id']]);
                        
                        // بررسی redirect امن
                        $redirect = $_GET['redirect'] ?? '';
                        if (!empty($redirect)) {
                            // بررسی URL برای جلوگیری از Open Redirect
                            $parsedUrl = parse_url($redirect);
                            if ($parsedUrl && isset($parsedUrl['host'])) {
                                // فقط اجازه redirect به دامنه خود
                                if ($parsedUrl['host'] !== $_SERVER['HTTP_HOST']) {
                                    $redirect = '';
                                }
                            } else {
                                // اگر URL نسبی است، بررسی کنید که با / شروع نشود
                                if (strpos($redirect, '/') === 0) {
                                    $redirect = '';
                                }
                            }
                        }
                        
                        if (!empty($redirect)) {
                            header('Location: ' . $redirect);
                        } elseif (in_array($user['role'], ['admin', 'editor'])) {
                            header('Location: admin/');
                        } else {
                            header('Location: dashboard.php');
                        }
                        exit;
                    } else {
                        logLoginAttempt($username, false);
                        logSecurityEvent('login_failed_inactive_account', ['username' => $username]);
                        $error = 'حساب کاربری شما غیرفعال است';
                    }
                } else {
                    logLoginAttempt($username, false);
                    logSecurityEvent('login_failed_invalid_credentials', ['username' => $username]);
                    $error = 'نام کاربری یا رمز عبور اشتباه است';
                }
            } catch (PDOException $e) {
                logSecurityEvent('login_database_error', ['error' => $e->getMessage()]);
                error_log('Login error: ' . $e->getMessage());
                $error = 'خطا در ورود به سیستم';
                header('Location: index.php');
            }
        }
    }
}

// پردازش فرم ثبت‌نام
if ($_POST && $action === 'register') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        logSecurityEvent('csrf_token_invalid_register', ['ip' => $_SERVER['REMOTE_ADDR']]);
        $error = 'توکن امنیتی نامعتبر است';
    } else {
        $username = sanitizeInput($_POST['username'] ?? '');
        $email = sanitizeInput($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $firstName = sanitizeInput($_POST['first_name'] ?? '');
        $lastName = sanitizeInput($_POST['last_name'] ?? '');
        
        // اعتبارسنجی ورودی‌ها
        if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
            $error = 'تمام فیلدها الزامی هستند';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'ایمیل نامعتبر است';
        } elseif (strlen($username) < 3 || strlen($username) > 20) {
            $error = 'نام کاربری باید بین 3 تا 20 کاراکتر باشد';
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $error = 'نام کاربری فقط می‌تواند شامل حروف، اعداد و _ باشد';
        } elseif (strlen($password) < 8) {
            $error = 'رمز عبور باید حداقل 8 کاراکتر باشد';
        } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/', $password)) {
            $error = 'رمز عبور باید شامل حروف بزرگ، کوچک و اعداد باشد';
        } elseif ($password !== $confirmPassword) {
            $error = 'رمز عبور و تکرار آن مطابقت ندارند';
        } else {
            try {
                // بررسی تکراری نبودن نام کاربری و ایمیل
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
                $stmt->execute([$username, $email]);
                $exists = $stmt->fetchColumn();
                
                if ($exists) {
                    $error = 'نام کاربری یا ایمیل قبلاً استفاده شده است';
                } else {
                    // ایجاد کاربر جدید
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        INSERT INTO users (username, email, password, first_name, last_name, role, status, created_at) 
                        VALUES (?, ?, ?, ?, ?, 'user', 'active', NOW())
                    ");
                    $stmt->execute([$username, $email, $hashedPassword, $firstName, $lastName]);
                    
                    logSecurityEvent('user_registered', ['username' => $username, 'email' => $email]);
                    $success = 'حساب کاربری با موفقیت ایجاد شد. حالا می‌توانید وارد شوید.';
                }
            } catch (PDOException $e) {
                logSecurityEvent('registration_error', ['error' => $e->getMessage()]);
                error_log('Registration error: ' . $e->getMessage());
                $error = 'خطا در ثبت‌نام';
            }
        }
    }
}

// تولید توکن CSRF
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود / ثبت‌نام - Dima CMS</title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/bootstrap-icons.css" rel="stylesheet">
    <link href="styles/login.rtl.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5 mb-5">
        <div class="auth-container">
            <div class="card">
                <div class="card-header text-center py-4">
                    <h3 class="mb-0">
                        <i class="bi bi-shield-lock"></i> <?php echo $settings['site_name']; ?>
                    </h3>
                    <p class="mb-0"><?php echo $settings['site_description']; ?></p>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        </div>
                    <?php endif; ?>

                    <ul class="nav nav-tabs mb-4" id="authTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button" role="tab">
                                <i class="bi bi-box-arrow-in-right"></i> ورود
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="register-tab" data-bs-toggle="tab" data-bs-target="#register" type="button" role="tab">
                                <i class="bi bi-person-plus"></i> ثبت‌نام
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content" id="authTabsContent">
                        <!-- فرم ورود -->
                        <div class="tab-pane fade show active" id="login" role="tabpanel">
                            <form method="post">
                                <input type="hidden" name="action" value="login">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                
                                <div class="mb-3">
                                    <label for="login_username" class="form-label">نام کاربری یا ایمیل</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                                        <input type="text" class="form-control" id="login_username" name="username" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="login_password" class="form-label">رمز عبور</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                        <input type="password" class="form-control" id="login_password" name="password" required>
                                    </div>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-box-arrow-in-right"></i> ورود
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- فرم ثبت‌نام -->
                        <div class="tab-pane fade" id="register" role="tabpanel">
                            <form method="post">
                                <input type="hidden" name="action" value="register">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="register_first_name" class="form-label">نام</label>
                                            <input type="text" class="form-control" id="register_first_name" name="first_name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="register_last_name" class="form-label">نام خانوادگی</label>
                                            <input type="text" class="form-control" id="register_last_name" name="last_name" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="register_username" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="register_username" name="username" required>
                                    <div class="form-text">3 تا 20 کاراکتر، فقط حروف، اعداد و _</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="register_email" class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" id="register_email" name="email" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="register_password" class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" id="register_password" name="password" required>
                                    <div class="form-text">حداقل 8 کاراکتر شامل حروف بزرگ، کوچک و اعداد</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="register_confirm_password" class="form-label">تکرار رمز عبور</label>
                                    <input type="password" class="form-control" id="register_confirm_password" name="confirm_password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-person-plus"></i> ثبت‌نام
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-3">
                <a href="index.php" class="text-white text-decoration-none">
                    <i class="bi bi-arrow-left"></i> بازگشت به صفحه اصلی
                </a>
                <br/>
                <a href="https://www.mitracms.ir" class="text-white text-decoration-none small">
                    <i class="bi bi-globe"></i>
                    <span>سیستم مدیریت محتوای فارسی میترا</span>
                </a>
            </div>
        </div>
    </div>

    <script src="scripts/bootstrap.bundle.min.js"></script>
    <script>
        // اعتبارسنجی رمز عبور
        document.getElementById('register_password').addEventListener('input', function() {
            const password = this.value;
            const hasLower = /[a-z]/.test(password);
            const hasUpper = /[A-Z]/.test(password);
            const hasNumber = /\d/.test(password);
            const isLongEnough = password.length >= 8;
            
            let message = '';
            if (!isLongEnough) message += 'حداقل 8 کاراکتر، ';
            if (!hasLower) message += 'حروف کوچک، ';
            if (!hasUpper) message += 'حروف بزرگ، ';
            if (!hasNumber) message += 'اعداد، ';
            
            if (message) {
                this.setCustomValidity(message.slice(0, -2));
            } else {
                this.setCustomValidity('');
            }
        });
        
        // بررسی تطابق رمز عبور
        document.getElementById('register_confirm_password').addEventListener('input', function() {
            const password = document.getElementById('register_password').value;
            const confirmPassword = this.value;
            
            if (password !== confirmPassword) {
                this.setCustomValidity('رمز عبور و تکرار آن مطابقت ندارند');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>