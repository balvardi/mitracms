<?php
require_once 'config/connection.php';
require_once 'templates/'.$settings['theme'].'/header.php';

// Get post slug from URL
$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';

if (empty($slug)) {
    header('Location: /blog.php');
    exit;
}

try {
    $pdo = new PDO("mysql:host=" . $dbConfig['host'] . ";dbname=" . $dbConfig['database'] . ";charset=utf8mb4", $dbConfig['username'], $dbConfig['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get post with category and author info
    $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug, u.username as author_name 
            FROM posts p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN users u ON p.author_id = u.id 
            WHERE p.slug = ? AND p.status = 'published'";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$slug]);
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$post) {
        header('HTTP/1.0 404 Not Found');
        include '404.php';
        exit;
    }

    // Get related posts from same category
    $related_sql = "SELECT title, slug, excerpt, featured_image, created_at 
                    FROM posts 
                    WHERE category_id = ? AND id != ? AND status = 'published' 
                    ORDER BY created_at DESC 
                    LIMIT 3";
    $related_stmt = $pdo->prepare($related_sql);
    $related_stmt->execute([$post['category_id'], $post['id']]);
    $related_posts = $related_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "خطا در دریافت مطلب: " . $e->getMessage();
}

// Helper function to format date

$title = isset($post) ? $post['title'] . ' - ' . $settings['site_name'] : 'مطلب یافت نشد';
$description = isset($post) ? ($post['meta_description'] ?: strip_tags($post['excerpt'])) : '';
require_once 'templates/'.$settings['theme'].'/single.php';
require_once 'templates/'.$settings['theme'].'/footer.php';
?>

