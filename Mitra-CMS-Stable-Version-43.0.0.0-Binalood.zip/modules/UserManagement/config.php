<?php
return [
    'name' => 'ماژول مدیریت کاربران',
    'description' => 'سیستم پیشرفته مدیریت کاربران با نقش‌های مختلف، احراز هویت دو مرحله‌ای و گزارش‌گیری',
    'version' => '1.0.0',
    'author' => 'Dima CMS',
    'category' => 'users',
    'features' => [
        'مدیریت نقش‌ها و دسترسی‌ها',
        'احراز هویت دو مرحله‌ای',
        'تایید ایمیل و شماره تلفن',
        'مدیریت پروفایل کاربران',
        'گزارش فعالیت‌های کاربران',
        'سیستم اعلان‌ها',
        'مدیریت گروه‌های کاربری',
        'لاگ ورود و خروج'
    ],
    'dependencies' => [],
    'permissions' => [
        'manage_users' => 'مدیریت کاربران',
        'manage_roles' => 'مدیریت نقش‌ها',
        'view_logs' => 'مشاهده لاگ‌ها',
        'export_users' => 'خروجی کاربران'
    ],
    'routes' => [
        'users' => 'modules/UserManagement/Controllers/UserController.php',
        'roles' => 'modules/UserManagement/Controllers/RoleController.php',
        'profile' => 'modules/UserManagement/Controllers/ProfileController.php'
    ],
    'settings' => [
        'allow_registration' => '1',
        'email_verification' => '1',
        'max_users' => '1000',
        'session_timeout' => '3600',
        'password_min_length' => '8',
        'enable_2fa' => '0'
    ]
]; 