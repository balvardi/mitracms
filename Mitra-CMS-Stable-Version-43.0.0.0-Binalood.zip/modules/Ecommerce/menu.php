<?php
return [
    'admin_menu' => [
        [
            'title' => 'فروشگاه',
            'icon' => 'bi bi-cart',
            'permission' => 'manage_products',
            'submenu' => [
                [
                    'title' => 'محصولات',
                    'url' => 'ecommerce/products',
                    'icon' => 'bi bi-box'
                ],
                [
                    'title' => 'دسته‌بندی‌ها',
                    'url' => 'ecommerce/categories',
                    'icon' => 'bi bi-tags'
                ],
                [
                    'title' => 'سفارشات',
                    'url' => 'ecommerce/orders',
                    'icon' => 'bi bi-receipt'
                ],
                [
                    'title' => 'گزارش‌ها',
                    'url' => 'ecommerce/reports',
                    'icon' => 'bi bi-graph-up'
                ]
            ]
        ]
    ],
    'frontend_menu' => [
        [
            'title' => 'فروشگاه',
            'url' => 'shop',
            'icon' => 'bi bi-cart'
        ]
    ]
]; 