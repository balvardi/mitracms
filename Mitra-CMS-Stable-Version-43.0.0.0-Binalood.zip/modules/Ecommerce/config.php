<?php
return [
    'name' => 'ماژول فروشگاه',
    'description' => 'سیستم کامل فروشگاه آنلاین با درگاه پرداخت، مدیریت محصولات، سفارشات و گزارش‌گیری',
    'version' => '1.0.0',
    'author' => 'Dima CMS',
    'category' => 'ecommerce',
    'features' => [
        'مدیریت محصولات و دسته‌بندی‌ها',
        'سیستم سبد خرید',
        'درگاه پرداخت امن',
        'مدیریت سفارشات',
        'گزارش‌گیری فروش',
        'سیستم تخفیف و کوپن',
        'مدیریت موجودی',
        'سیستم نظرات و امتیازدهی'
    ],
    'dependencies' => [],
    'permissions' => [
        'manage_products' => 'مدیریت محصولات',
        'manage_orders' => 'مدیریت سفارشات',
        'view_reports' => 'مشاهده گزارش‌ها',
        'manage_settings' => 'تنظیمات فروشگاه'
    ],
    'routes' => [
        'shop' => 'modules/Ecommerce/Controllers/ShopController.php',
        'cart' => 'modules/Ecommerce/Controllers/CartController.php',
        'checkout' => 'modules/Ecommerce/Controllers/CheckoutController.php',
        'orders' => 'modules/Ecommerce/Controllers/OrderController.php'
    ],
    'settings' => [
        'currency' => 'تومان',
        'tax_rate' => '9',
        'shipping_cost' => '50000',
        'enable_reviews' => '1',
        'enable_coupons' => '1',
        'min_order_amount' => '100000'
    ]
]; 