<?php
return [
    'name' => 'ماژول فرم‌ساز',
    'description' => 'ایجاد و مدیریت فرم‌های سفارشی با قابلیت‌های پیشرفته و ارسال ایمیل',
    'version' => '1.0.0',
    'author' => 'Dima CMS',
    'category' => 'forms',
    'features' => [
        'ایجاد فرم‌های سفارشی',
        'انواع فیلدهای مختلف',
        'اعتبارسنجی پیشرفته',
        'ارسال ایمیل خودکار',
        'ذخیره پاسخ‌ها در پایگاه داده',
        'کپچا برای امنیت',
        'قالب‌های آماده',
        'گزارش‌گیری از فرم‌ها'
    ],
    'dependencies' => [],
    'permissions' => [
        'create_forms' => 'ایجاد فرم',
        'manage_forms' => 'مدیریت فرم‌ها',
        'view_submissions' => 'مشاهده پاسخ‌ها',
        'export_data' => 'خروجی داده‌ها'
    ],
    'routes' => [
        'forms' => 'modules/FormBuilder/Controllers/FormController.php',
        'submissions' => 'modules/FormBuilder/Controllers/SubmissionController.php'
    ],
    'settings' => [
        'max_forms' => '10',
        'enable_captcha' => '1',
        'email_notifications' => '1',
        'auto_save' => '1',
        'max_file_size' => '5242880'
    ]
]; 