<?php
return [
    'admin_menu' => [
        [
            'title' => 'فرم‌ها',
            'icon' => 'bi bi-file-earmark-text',
            'permission' => 'manage_forms',
            'submenu' => [
                [
                    'title' => 'مدیریت فرم‌ها',
                    'url' => 'admin/forms',
                    'icon' => 'bi bi-list'
                ],
                [
                    'title' => 'ایجاد فرم جدید',
                    'url' => 'admin/forms/create',
                    'icon' => 'bi bi-plus'
                ],
                [
                    'title' => 'پاسخ‌ها',
                    'url' => 'admin/forms/submissions',
                    'icon' => 'bi bi-inbox'
                ]
            ]
        ]
    ],
    'frontend_menu' => [
        [
            'title' => 'فرم‌ها',
            'url' => 'forms',
            'icon' => 'bi bi-file-earmark-text'
        ]
    ]
]; 