<?php
require_once 'config/connection.php';
require_once 'templates/'.$settings['theme'].'/header.php';

// Get current page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// تضمین عددی بودن
$per_page = intval($per_page);
$offset = intval($offset);

// Get search and category filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;

// Build WHERE clause
$where_conditions = ["p.status = 'published'"]; // ✅ مشخص کردیم: p.status
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(p.title LIKE ? OR p.content LIKE ? OR p.excerpt LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if ($category_id > 0) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $category_id;
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $pdo = new PDO("mysql:host=" . $dbConfig['host'] . ";dbname=" . $dbConfig['database'] . ";charset=utf8mb4", $dbConfig['username'], $dbConfig['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get total posts count
    $count_sql = "SELECT COUNT(*) FROM posts p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  LEFT JOIN users u ON p.author_id = u.id 
                  WHERE {$where_clause}";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_posts = $count_stmt->fetchColumn();
    $total_pages = ceil($total_posts / $per_page);

    // Get posts - LIMIT و OFFSET مستقیماً (چون عدد هستند و ایمن)
    $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug, u.username as author_name 
            FROM posts p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN users u ON p.author_id = u.id 
            WHERE {$where_clause} 
            ORDER BY p.created_at DESC 
            LIMIT {$per_page} OFFSET {$offset}";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get categories for filter
    $cat_sql = "SELECT * FROM categories WHERE status = 'active' ORDER BY name";
    $cat_stmt = $pdo->query($cat_sql);
    $categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "خطا در دریافت مطالب: " . $e->getMessage();
    $posts = [];
    $categories = [];
    $total_pages = 0;
}

// Helper function to generate excerpt
function generateExcerpt($content, $length = 200) {
    $content = strip_tags($content);
    if (mb_strlen($content) <= $length) {
        return $content;
    }
    return mb_substr($content, 0, $length) . '...';
}


$title = 'وبلاگ - ' . $settings['site_name'];
require_once 'templates/'.$settings['theme'].'/blog.php';
require_once 'templates/'.$settings['theme'].'/footer.php';
?>
