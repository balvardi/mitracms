<?php
// فایل تست برای بررسی اتصال
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>تست اتصال Dima CMS</h1>";

try {
    // تست بارگذاری فایل connection.php
    require_once 'config/connection.php';
    echo "<p style='color: green;'>✅ فایل connection.php با موفقیت بارگذاری شد</p>";
    
    // تست اتصال به پایگاه داده
    $pdo = getDatabase();
    echo "<p style='color: green;'>✅ اتصال به پایگاه داده موفق بود</p>";
    
    // تست دریافت تنظیمات
    $stmt = $pdo->prepare("SELECT * FROM settings");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    echo "<p style='color: green;'>✅ دریافت تنظیمات موفق بود</p>";
    
    echo "<h2>تنظیمات سایت:</h2>";
    echo "<ul>";
    foreach ($settings as $key => $value) {
        echo "<li><strong>$key:</strong> $value</li>";
    }
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ خطا: " . $e->getMessage() . "</p>";
    echo "<p><strong>جزئیات خطا:</strong></p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h2>اطلاعات سرور:</h2>";
echo "<ul>";
echo "<li><strong>PHP Version:</strong> " . phpversion() . "</li>";
echo "<li><strong>Server:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</li>";
echo "<li><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</li>";
echo "<li><strong>Current Path:</strong> " . __DIR__ . "</li>";
echo "</ul>";
?> 