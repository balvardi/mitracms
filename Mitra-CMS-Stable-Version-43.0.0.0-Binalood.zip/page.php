<?php
require_once 'config/connection.php';
require_once 'templates/'.$settings['theme'].'/header.php';

$slug = $_GET['slug'] ?? '';
if (empty($slug)) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = getDatabase();
    // دریافت صفحه
    $stmt = $pdo->prepare("
        SELECT p.*, u.first_name, u.last_name 
        FROM pages p 
        LEFT JOIN users u ON p.author_id = u.id 
        WHERE p.slug = ? AND p.status = 'published'
    ");
    $stmt->execute([$slug]);
    $page = $stmt->fetch();
    
    if (!$page) {
        http_response_code(404);
        die('صفحه یافت نشد');
    }
    
    $siteName = $settings['site_name'] ?? 'Mitra CMS';
    
} catch (PDOException $e) {
    die('خطا در بارگذاری صفحه: ' . $e->getMessage());
}
require_once 'templates/'.$settings['theme'].'/page.php';
require_once 'templates/'.$settings['theme'].'/footer.php';
?>
