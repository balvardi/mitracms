<?php
/*
 * jdf.php (Jalali Date Functions for PHP)
 * https://github.com/sallar/jDate
 * نسخه کوتاه‌شده برای استفاده در پروژه
 */
if (!function_exists('jdate')) {
    function jdate($format, $timestamp = '', $none = '', $time_zone = 'Asia/Tehran', $tr_num = 'fa') {
        $T_sec = 0;
        if ($time_zone != 'local') {
            date_default_timezone_set(($time_zone == '') ? 'Asia/Tehran' : $time_zone);
        }
        $ts = ($timestamp == '') ? time() + $T_sec : $timestamp;
        $date = explode('_', date('Y_n_j_H_i_s_w', $ts));
        list($gy, $gm, $gd, $h, $i, $s, $w) = $date;
        $j = gregorian_to_jalali($gy, $gm, $gd);
        $out = $format;
        $out = str_replace('Y', $j[0], $out);
        $out = str_replace('m', str_pad($j[1], 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('d', str_pad($j[2], 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('H', $h, $out);
        $out = str_replace('i', $i, $out);
        $out = str_replace('s', $s, $out);
        return ($tr_num == 'fa') ? tr_num($out, 'fa', '.') : $out;
    }
    function gregorian_to_jalali($gy, $gm, $gd) {
        $g_d_m = array(0,31,59,90,120,151,181,212,243,273,304,334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + (int)(($gy2 + 3) / 4) - (int)(($gy2 + 99) / 100) + (int)(($gy2 + 399) / 400) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * (int)($days / 12053));
        $days %= 12053;
        $jy += 4 * (int)($days / 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        $jm = ($days < 186) ? 1 + (int)($days / 31) : 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days < 186) ? ($days % 31) : (($days - 186) % 30));
        return array($jy, $jm, $jd);
    }
    function tr_num($str, $mod = 'fa', $separator = ',') {
        $num_a = array('0','1','2','3','4','5','6','7','8','9');
        $key_a = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
        return ($mod == 'fa') ? str_replace($num_a, $key_a, $str) : str_replace($key_a, $num_a, $str);
    }
} 