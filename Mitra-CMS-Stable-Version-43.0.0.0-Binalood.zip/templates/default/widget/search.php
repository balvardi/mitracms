<div class="search">
    <form method="GET" class="row m-auto">
        <div class="col-md-10 p-1">
            <input type="text" class="form-control p-2 m-0" id="search" name="search" value="" placeholder="عنوان، محتوا یا خلاصه...">
        </div>
        <div class="col-md-2 p-1">
            <button type="submit" class="btn btn-primary w-100 p-2 m-0">
                <i class="bi bi-search"></i>
            </button>
        </div>
    </form>
</div>
