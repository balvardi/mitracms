<ul class="navbar-nav">
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['username']) ?>
            </a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2"></i> داشبورد</a></li>
                <?php if (in_array($_SESSION['role'], ['admin', 'editor'])): ?>
                    <li><a class="dropdown-item" href="admin/"><i class="bi bi-gear"></i> پنل مدیریت</a></li>
                <?php endif; ?>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> خروج</a></li>
            </ul>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a class="nav-link" href="auth.php">ورود</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="auth.php?action=register">ثبت نام</a>
        </li>
    <?php endif; ?>
</ul>
