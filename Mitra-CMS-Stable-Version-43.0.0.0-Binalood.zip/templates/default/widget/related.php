<div class="card">
    <div class="card-header">
        <h5 class="mb-0">صفحات مرتبط</h5>
    </div>
    <div class="card-body">
        <?php
        // دریافت سایر صفحات
        $stmt = $pdo->prepare("SELECT title, slug FROM pages WHERE status = 'published' AND slug != ? ORDER BY title LIMIT 5");
        $stmt->execute([$slug]);
        $relatedPages = $stmt->fetchAll();
        ?>
                                
        <?php if ($relatedPages): ?>
            <ul class="list-unstyled">
                <?php foreach ($relatedPages as $relatedPage): ?>
                    <li class="mb-2">
                        <a href="page.php?slug=<?php echo htmlspecialchars($relatedPage['slug']) ?>" 
                           class="text-decoration-none">
                            <?php echo htmlspecialchars($relatedPage['title']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-muted">صفحه‌ای یافت نشد</p>
        <?php endif; ?>
    </div>
</div>
