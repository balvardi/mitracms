<?php
// بررسی تنظیمات ویجت Featured
$featuredSettings = $settings['featured_widget'] ?? [];
$featuredEnabled = $featuredSettings['enabled'] ?? true;
$featuredTitle = $featuredSettings['title'] ?? 'ویژگی‌های کلیدی';
$featuredSubtitle = $featuredSettings['subtitle'] ?? 'چرا Dima CMS را انتخاب کنید؟';
$featuredItems = $featuredSettings['items'] ?? [
    [
        'icon' => 'speedometer2',
        'title' => 'سرعت بالا',
        'description' => 'سیستم بهینه‌سازی شده برای سرعت و عملکرد بالا',
        'color' => 'primary',
        'animation' => 'fade-up'
    ],
    [
        'icon' => 'shield-check',
        'title' => 'امنیت بالا',
        'description' => 'امنیت پیشرفته و محافظت در برابر تهدیدات',
        'color' => 'success',
        'animation' => 'fade-up'
    ],
    [
        'icon' => 'phone',
        'title' => 'ریسپانسیو',
        'description' => 'سازگار با تمام دستگاه‌ها و اندازه‌های صفحه',
        'color' => 'info',
        'animation' => 'fade-up'
    ],
    [
        'icon' => 'gear',
        'title' => 'قابلیت تنظیم',
        'description' => 'امکان شخصی‌سازی و تنظیم آسان',
        'color' => 'warning',
        'animation' => 'fade-up'
    ],
    [
        'icon' => 'cloud',
        'title' => 'پشتیبانی ابری',
        'description' => 'پشتیبانی کامل از خدمات ابری',
        'color' => 'secondary',
        'animation' => 'fade-up'
    ],
    [
        'icon' => 'people',
        'title' => 'مدیریت کاربران',
        'description' => 'سیستم مدیریت کاربران پیشرفته',
        'color' => 'danger',
        'animation' => 'fade-up'
    ]
];
$featuredLayout = $featuredSettings['layout'] ?? 'grid';
$featuredAnimation = $featuredSettings['animation'] ?? 'fade-in';
$featuredShowStats = $featuredSettings['show_stats'] ?? false;
$featuredStats = $featuredSettings['stats'] ?? [];

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// پاکسازی ورودی‌ها
$featuredTitle = htmlspecialchars($featuredTitle, ENT_QUOTES, 'UTF-8');
$featuredSubtitle = htmlspecialchars($featuredSubtitle, ENT_QUOTES, 'UTF-8');

// اگر ویجت غیرفعال است، نمایش نده
if (!$featuredEnabled) {
    return;
}
?>

<!-- Features Section -->
<section class="features-section py-5" 
         data-animation="<?php echo $featuredAnimation; ?>"
         data-layout="<?php echo $featuredLayout; ?>">
    
    <div class="container">
        <!-- Section Header -->
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 col-xl-6 text-center">
                <div class="section-header" data-aos="fade-up">
                    <h2 class="section-title fw-bold mb-3">
                        <?php echo $featuredTitle; ?>
                    </h2>
                    <?php if ($featuredSubtitle): ?>
                        <p class="section-subtitle lead text-muted">
                            <?php echo $featuredSubtitle; ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Features Grid -->
        <div class="row g-4">
            <?php foreach ($featuredItems as $index => $item): ?>
                <?php
                $itemIcon = htmlspecialchars($item['icon'] ?? 'star', ENT_QUOTES, 'UTF-8');
                $itemTitle = htmlspecialchars($item['title'] ?? '', ENT_QUOTES, 'UTF-8');
                $itemDescription = htmlspecialchars($item['description'] ?? '', ENT_QUOTES, 'UTF-8');
                $itemColor = htmlspecialchars($item['color'] ?? 'primary', ENT_QUOTES, 'UTF-8');
                $itemAnimation = htmlspecialchars($item['animation'] ?? 'fade-up', ENT_QUOTES, 'UTF-8');
                $itemDelay = ($index * 100) + 100;
                ?>
                
                <div class="col-md-6 col-lg-4" 
                     data-aos="<?php echo $itemAnimation; ?>" 
                     data-aos-delay="<?php echo $itemDelay; ?>">
                    <div class="feature-card h-100">
                        <div class="feature-icon">
                            <div class="icon-wrapper bg-<?php echo $itemColor; ?>">
                                <i class="bi bi-<?php echo $itemIcon; ?>"></i>
                            </div>
                        </div>
                        
                        <div class="feature-content">
                            <h5 class="feature-title"><?php echo $itemTitle; ?></h5>
                            <p class="feature-description"><?php echo $itemDescription; ?></p>
                        </div>
                        
                        <div class="feature-hover">
                            <div class="hover-content">
                                <i class="bi bi-arrow-right"></i>
                                <span>بیشتر</span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Stats Section -->
        <?php if ($featuredShowStats && !empty($featuredStats)): ?>
            <div class="row mt-5 pt-5 border-top">
                <div class="col-12">
                    <div class="stats-section" data-aos="fade-up" data-aos-delay="300">
                        <div class="row text-center">
                            <?php foreach ($featuredStats as $stat): ?>
                                <div class="col-md-3 col-6 mb-4">
                                    <div class="stat-card">
                                        <div class="stat-icon">
                                            <i class="bi bi-<?php echo htmlspecialchars($stat['icon'] ?? 'star', ENT_QUOTES, 'UTF-8'); ?>"></i>
                                        </div>
                                        <div class="stat-number">
                                            <?php echo htmlspecialchars($stat['value'] ?? '0', ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                        <div class="stat-label">
                                            <?php echo htmlspecialchars($stat['label'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
