<div class="search-form">
    <form method="GET" class="row g-3">
        <div class="col-md-6">
            <label for="search" class="form-label">جستجو در مطالب</label>
            <input type="text" class="form-control p-2 m-0" id="search" name="search" 
                   value="<?php echo htmlspecialchars($search) ?>" placeholder="عنوان، محتوا یا خلاصه...">
        </div>
        <div class="col-md-4">
            <label for="category" class="form-label">دسته‌بندی</label>
            <select class="form-select p-2 m-0" id="category" name="category">
                <option value="0">همه دسته‌ها</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id'] ?>" <?php echo $category_id == $cat['id'] ? 'selected' : '' ?>>
                        <?php echo htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label">&nbsp;</label>
            <button type="submit" class="btn btn-primary w-100 p-2 m-0">
                <i class="bi bi-search"></i> 
            </button>
        </div>
    </form>
</div>
