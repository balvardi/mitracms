<!-- Recent Posts Widget -->
<?php
try {
    $recent_sql = "SELECT title, slug, created_at FROM posts WHERE status = 'published' ORDER BY created_at DESC LIMIT 5";
    $recent_stmt = $pdo->query($recent_sql);
    $recent_posts = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $recent_posts = [];
}
?>
<?php if (!empty($recent_posts)): ?>
    <div class="sidebar">
        <h5 class="fw-bold mb-3">
            <i class="bi bi-clock-history"></i> آخرین مطالب
        </h5>
        <div class="list-group list-group-flush">
            <?php foreach ($recent_posts as $recent): ?>
                <a href="post.php?slug=<?php echo htmlspecialchars($recent['slug']) ?>" 
                   class="list-group-item list-group-item-action border-0">
                    <div class="fw-bold"><?php echo htmlspecialchars($recent['title']) ?></div>
                    <small class="text-muted">
                        <i class="bi bi-calendar3"></i>
                        <?php echo formatPersianDate($recent['created_at']) ?>
                    </small>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
