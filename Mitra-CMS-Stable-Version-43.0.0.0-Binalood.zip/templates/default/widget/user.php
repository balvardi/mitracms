<h5>حساب کاربری</h5>
<ul class="list-unstyled">
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
        <li><a href="dashboard.php" class="text-white-50">داشبورد</a></li>
        <li><a href="logout.php" class="text-white-50">خروج</a></li>
    <?php else: ?>
        <li><a href="auth.php" class="text-white-50">ورود</a></li>
        <li><a href="auth.php?action=register" class="text-white-50">ثبت نام</a></li>
    <?php endif; ?>
</ul>
