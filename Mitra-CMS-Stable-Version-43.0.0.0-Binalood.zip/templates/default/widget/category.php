<!-- Categories Widget -->
<?php if (!empty($categories)): ?>
    <div class="sidebar">
        <h5 class="fw-bold mb-3">
            <i class="bi bi-folder"></i> دسته‌بندی‌ها
        </h5>
        <div class="list-group list-group-flush">
            <a href="blog.php" class="list-group-item list-group-item-action border-0 <?php echo $category_id == 0 ? 'active' : '' ?>">
                همه مطالب
                <span class="badge bg-secondary rounded-pill"><?php echo $total_posts ?></span>
            </a>
            <?php foreach ($categories as $cat): ?>
                <?php
                // Get post count for this category
                $cat_count_sql = "SELECT COUNT(*) FROM posts WHERE category_id = ? AND status = 'published'";
                $cat_count_stmt = $pdo->prepare($cat_count_sql);
                $cat_count_stmt->execute([$cat['id']]);
                $cat_count = $cat_count_stmt->fetchColumn();
                ?>
                <a href="blog.php?category=<?php echo $cat['id'] ?>" 
                   class="list-group-item list-group-item-action border-0 <?php echo $category_id == $cat['id'] ? 'active' : '' ?>">
                    <?php echo htmlspecialchars($cat['name']) ?>
                    <span class="badge bg-secondary rounded-pill"><?php echo $cat_count ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
