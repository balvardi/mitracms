<div class="text-center">
   <p>&copy; <?php echo date('Y') ?> <?php echo $settings['site_name']; ?>. تمامی حقوق محفوظ است.</p>
</div>
