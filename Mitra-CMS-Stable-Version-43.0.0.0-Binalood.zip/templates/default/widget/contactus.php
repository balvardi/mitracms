<div class="sidebar">
   <h5 class="fw-bold mb-3">
      <i class="bi bi-phone"></i> تماس با ما
   </h5>
   <form>
     <div class="mb-3">
       <input type="text" class="form-control" id="nameInput" placeholder="نام شما">
     </div>
     <div class="mb-3">
       <input type="email" class="form-control" id="emailInput" placeholder="name@example.com">
     </div>
     <div class="mb-3">
       <input type="text" class="form-control" id="subjectInput" placeholder="موضوع پیام">
     </div>
     <div class="mb-3">
       <textarea class="form-control" id="messageTextarea" rows="5" placeholder="متن پیام"></textarea>
     </div>
     <button type="submit" class="btn btn-primary">ارسال پیام</button>
   </form>
</div>