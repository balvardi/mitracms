<?php
// بررسی تنظیمات ویجت Latest
$latestSettings = $settings['menu'] ?? [];
$latestEnabled = $latestSettings['enabled'] ?? true;
$latestTitle = $latestSettings['title'] ?? 'فهرست';
$latestSubtitle = $latestSettings['subtitle'] ?? 'فهرست منوی های بخش کاربری سایت';
$latestLimit = $latestSettings['limit'] ?? 100;
$latestAnimation = $latestSettings['animation'] ?? 'fade-in';

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// پاکسازی ورودی‌ها
$latestTitle = htmlspecialchars($latestTitle, ENT_QUOTES, 'UTF-8');
$latestSubtitle = htmlspecialchars($latestSubtitle, ENT_QUOTES, 'UTF-8');

// اگر ویجت غیرفعال است، نمایش نده
if (!$latestEnabled) {
    return;
}

// دریافت آخرین مطالب
try {
    $pdo = getDatabase();
    $stmt = $pdo->prepare("
        SELECT p.*
        FROM menus p 
        WHERE p.status = 'active' 
        ORDER BY p.ordering ASC 
        LIMIT ?
    ");
    $stmt->execute([$latestLimit]);
    $Menus = $stmt->fetchAll();
} catch (Exception $e) {
    $Menus = [];
    error_log('Latest menus widget error: ' . $e->getMessage());
}
?>

<!-- Latest Posts Section -->
<?php if (!empty($Menus)): ?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm w-100 container-fluid">
        <div class="container">            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                     <?php foreach ($Menus as $index => $menu): ?>
                     <li class="nav-item">
                        <a class="nav-link active" href="<?php echo $menu['link'];?>"><?php echo $menu['title'];?></a>
                     </li>
                     <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </nav>
<?php endif; ?>