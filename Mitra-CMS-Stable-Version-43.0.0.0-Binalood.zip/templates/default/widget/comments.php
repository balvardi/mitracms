<?php
// بررسی تنظیمات ویجت Comments
$commentsSettings = $settings['comments_widget'] ?? [];
$commentsEnabled = $commentsSettings['enabled'] ?? true;
$commentsLimit = $commentsSettings['limit'] ?? 5;
$commentsShowAvatar = $commentsSettings['show_avatar'] ?? true;
$commentsShowDate = $commentsSettings['show_date'] ?? true;
$commentsShowAuthor = $commentsSettings['show_author'] ?? true;
$commentsModeration = $commentsSettings['moderation'] ?? true;

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// اگر ویجت غیرفعال است، نمایش نده
if (!$commentsEnabled) {
    return;
}

// دریافت نظرات اخیر
try {
    $pdo = getDatabase();
    $stmt = $pdo->prepare("
        SELECT c.*, u.first_name, u.last_name, u.avatar, p.title as post_title, p.slug as post_slug
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN posts p ON c.post_id = p.id
        WHERE c.status = 'approved'
        ORDER BY c.created_at DESC
        LIMIT ?
    ");
    $stmt->execute([$commentsLimit]);
    $comments = $stmt->fetchAll();
} catch (Exception $e) {
    $comments = [];
    error_log('Comments widget error: ' . $e->getMessage());
}
?>

<!-- Comments Widget -->
<div class="comments-widget widget">
    <div class="widget-header">
        <h5 class="widget-title">
            <i class="bi bi-chat-dots"></i>
            آخرین نظرات
        </h5>
    </div>
    
    <div class="widget-content">
        <?php if (empty($comments)): ?>
            <div class="no-comments">
                <i class="bi bi-chat-dots text-muted"></i>
                <p class="text-muted mb-0">هنوز نظری ثبت نشده است</p>
            </div>
        <?php else: ?>
            <div class="comments-list">
                <?php foreach ($comments as $comment): ?>
                    <?php
                    // پاکسازی داده‌ها
                    $commentId = (int)$comment['id'];
                    $commentContent = htmlspecialchars($comment['content'], ENT_QUOTES, 'UTF-8');
                    $commentDate = $comment['created_at'];
                    $authorName = htmlspecialchars($comment['first_name'] . ' ' . $comment['last_name'], ENT_QUOTES, 'UTF-8');
                    $postTitle = htmlspecialchars($comment['post_title'], ENT_QUOTES, 'UTF-8');
                    $postSlug = htmlspecialchars($comment['post_slug'], ENT_QUOTES, 'UTF-8');
                    $avatar = $comment['avatar'] ? htmlspecialchars($comment['avatar'], ENT_QUOTES, 'UTF-8') : '';
                    
                    // محدود کردن طول محتوا
                    $shortContent = strlen($commentContent) > 100 ? 
                        substr($commentContent, 0, 100) . '...' : $commentContent;
                    ?>
                    
                    <div class="comment-item" data-comment-id="<?php echo $commentId; ?>">
                        <div class="comment-header">
                            <?php if ($commentsShowAvatar && $avatar): ?>
                                <div class="comment-avatar">
                                    <img src="<?php echo $avatar; ?>" 
                                         alt="<?php echo $authorName; ?>" 
                                         class="avatar-img"
                                         loading="lazy"
                                         onerror="this.src='public/placeholder-user.jpg'">
                                </div>
                            <?php elseif ($commentsShowAvatar): ?>
                                <div class="comment-avatar">
                                    <div class="avatar-placeholder">
                                        <i class="bi bi-person"></i>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="comment-meta">
                                <?php if ($commentsShowAuthor): ?>
                                    <h6 class="comment-author"><?php echo $authorName; ?></h6>
                                <?php endif; ?>
                                
                                <?php if ($commentsShowDate): ?>
                                    <span class="comment-date">
                                        <i class="bi bi-clock"></i>
                                        <?php echo formatPersianDate($commentDate); ?>
                                    </span>
                                <?php endif; ?>
                                
                                <div class="comment-post">
                                    <i class="bi bi-file-text"></i>
                                    <a href="post.php?slug=<?php echo $postSlug; ?>" 
                                       class="post-link"
                                       title="<?php echo $postTitle; ?>">
                                        <?php echo $postTitle; ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="comment-content">
                            <p class="comment-text"><?php echo $shortContent; ?></p>
                        </div>
                        
                        <div class="comment-actions">
                            <a href="post.php?slug=<?php echo $postSlug; ?>#comment-<?php echo $commentId; ?>" 
                               class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-arrow-left"></i>
                                مشاهده
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Comment Form Preview -->
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
        <div class="comment-form-preview">
            <div class="form-group">
                <textarea class="form-control" 
                          placeholder="نظر خود را بنویسید..." 
                          rows="3"
                          maxlength="500"></textarea>
                <div class="form-text">
                    <span class="char-count">0</span>/500 کاراکتر
                </div>
            </div>
            <button type="button" class="btn btn-primary btn-sm">
                <i class="bi bi-send"></i>
                ارسال نظر
            </button>
        </div>
    <?php else: ?>
        <div class="login-to-comment">
            <a href="auth.php" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-person-plus"></i>
                ورود برای نظر دادن
            </a>
        </div>
    <?php endif; ?>
</div>
