<?php
// بررسی تنظیمات ویجت Hero
$heroSettings = $settings['hero_widget'] ?? [];
$heroEnabled = $heroSettings['enabled'] ?? true;
$heroTitle = $heroSettings['title'] ?? $settings['site_name'];
$heroSubtitle = $heroSettings['subtitle'] ?? $settings['site_description'];
$heroImage = $heroSettings['image'] ?? '';
$heroButtons = $heroSettings['buttons'] ?? [
    ['text' => 'درباره ما', 'url' => 'page.php?slug=about', 'type' => 'primary'],
    ['text' => 'تماس با ما', 'url' => 'page.php?slug=contact', 'type' => 'outline-light']
];
$heroAnimation = $heroSettings['animation'] ?? 'fade-in';
$heroBackground = $heroSettings['background'] ?? 'gradient';

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// پاکسازی ورودی‌ها
$heroTitle = htmlspecialchars($heroTitle, ENT_QUOTES, 'UTF-8');
$heroSubtitle = htmlspecialchars($heroSubtitle, ENT_QUOTES, 'UTF-8');
$heroImage = htmlspecialchars($heroImage, ENT_QUOTES, 'UTF-8');

// اگر ویجت غیرفعال است، نمایش نده
if (!$heroEnabled) {
    return;
}
?>

<!-- Hero Section -->
<section class="hero-section position-relative overflow-hidden" 
         data-animation="<?php echo $heroAnimation; ?>"
         data-background="<?php echo $heroBackground; ?>">
    
    <!-- Background Overlay -->
    <div class="hero-background"></div>
    
    <div class="container position-relative">
        <div class="row align-items-center min-vh-75">
            <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
                <div class="hero-content">
                    <h1 class="display-4 fw-bold mb-4 text-gradient">
                        <?php echo $heroTitle; ?>
                    </h1>
                    
                    <p class="lead mb-4 text-muted">
                        <?php echo $heroSubtitle; ?>
                    </p>
                    
                    <div class="hero-buttons d-flex flex-wrap gap-3">
                        <?php foreach ($heroButtons as $button): ?>
                            <?php 
                            $buttonText = htmlspecialchars($button['text'] ?? '', ENT_QUOTES, 'UTF-8');
                            $buttonUrl = htmlspecialchars($button['url'] ?? '#', ENT_QUOTES, 'UTF-8');
                            $buttonType = htmlspecialchars($button['type'] ?? 'primary', ENT_QUOTES, 'UTF-8');
                            $buttonIcon = htmlspecialchars($button['icon'] ?? '', ENT_QUOTES, 'UTF-8');
                            ?>
                            <a href="<?php echo $buttonUrl; ?>" 
                               class="btn btn-<?php echo $buttonType; ?> btn-lg px-4 py-3"
                               <?php if (strpos($buttonUrl, 'http') === 0): ?>
                               target="_blank" rel="noopener noreferrer"
                               <?php endif; ?>>
                                <?php if ($buttonIcon): ?>
                                    <i class="bi bi-<?php echo $buttonIcon; ?> me-2"></i>
                                <?php endif; ?>
                                <?php echo $buttonText; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Stats Section -->
                    <?php if (!empty($heroSettings['stats'])): ?>
                        <div class="hero-stats mt-5 pt-4 border-top">
                            <div class="row text-center">
                                <?php foreach ($heroSettings['stats'] as $stat): ?>
                                    <div class="col-4">
                                        <div class="stat-item">
                                            <h3 class="fw-bold text-primary mb-1">
                                                <?php echo htmlspecialchars($stat['value'] ?? '0', ENT_QUOTES, 'UTF-8'); ?>
                                            </h3>
                                            <p class="text-muted small">
                                                <?php echo htmlspecialchars($stat['label'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
                <div class="hero-visual text-center">
                    <?php if ($heroImage && file_exists($heroImage)): ?>
                        <img src="<?php echo $heroImage; ?>" 
                             alt="<?php echo $heroTitle; ?>" 
                             class="img-fluid hero-image"
                             loading="lazy">
                    <?php else: ?>
                        <div class="hero-icon">
                            <i class="bi bi-laptop display-1 opacity-75 text-primary"></i>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scroll Indicator -->
    <div class="scroll-indicator">
        <a href="#content" class="scroll-down">
            <i class="bi bi-chevron-down"></i>
        </a>
    </div>
</section>