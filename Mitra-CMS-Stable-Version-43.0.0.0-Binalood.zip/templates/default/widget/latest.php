<?php
// بررسی تنظیمات ویجت Latest
$latestSettings = $settings['latest_widget'] ?? [];
$latestEnabled = $latestSettings['enabled'] ?? true;
$latestTitle = $latestSettings['title'] ?? 'آخرین مطالب';
$latestSubtitle = $latestSettings['subtitle'] ?? 'جدیدترین مقالات و مطالب ما';
$latestLimit = $latestSettings['limit'] ?? 6;
$latestShowFeatured = $latestSettings['show_featured'] ?? true;
$latestShowAuthor = $latestSettings['show_author'] ?? true;
$latestShowDate = $latestSettings['show_date'] ?? true;
$latestShowCategory = $latestSettings['show_category'] ?? true;
$latestShowExcerpt = $latestSettings['show_excerpt'] ?? true;
$latestLayout = $latestSettings['layout'] ?? 'grid';
$latestAnimation = $latestSettings['animation'] ?? 'fade-in';

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// پاکسازی ورودی‌ها
$latestTitle = htmlspecialchars($latestTitle, ENT_QUOTES, 'UTF-8');
$latestSubtitle = htmlspecialchars($latestSubtitle, ENT_QUOTES, 'UTF-8');

// اگر ویجت غیرفعال است، نمایش نده
if (!$latestEnabled) {
    return;
}

// دریافت آخرین مطالب
try {
    $pdo = getDatabase();
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name, c.slug as category_slug, u.first_name, u.last_name, u.avatar
        FROM posts p 
        LEFT JOIN categories c ON p.category_id = c.id 
        LEFT JOIN users u ON p.author_id = u.id 
        WHERE p.status = 'published' 
        ORDER BY p.published_at DESC 
        LIMIT ?
    ");
    $stmt->execute([$latestLimit]);
    $latestPosts = $stmt->fetchAll();
} catch (Exception $e) {
    $latestPosts = [];
    error_log('Latest posts widget error: ' . $e->getMessage());
}
?>

<!-- Latest Posts Section -->
<?php if (!empty($latestPosts)): ?>
<section class="latest-posts-section py-5" 
         data-animation="<?php echo $latestAnimation; ?>"
         data-layout="<?php echo $latestLayout; ?>">
    
    <div class="container">
        <!-- Section Header -->
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 col-xl-6 text-center">
                <div class="section-header" data-aos="fade-up">
                    <h2 class="section-title fw-bold mb-3">
                        <?php echo $latestTitle; ?>
                    </h2>
                    <?php if ($latestSubtitle): ?>
                        <p class="section-subtitle lead text-muted">
                            <?php echo $latestSubtitle; ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Posts Grid -->
        <div class="row g-4">
            <?php foreach (array_slice($latestPosts, 0, 3) as $index => $post): ?>
                <?php
                // پاکسازی داده‌ها
                $postId = (int)$post['id'];
                $postTitle = htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8');
                $postSlug = htmlspecialchars($post['slug'], ENT_QUOTES, 'UTF-8');
                $postExcerpt = htmlspecialchars($post['excerpt'], ENT_QUOTES, 'UTF-8');
                $postImage = $post['featured_image'] ? htmlspecialchars($post['featured_image'], ENT_QUOTES, 'UTF-8') : '';
                $postDate = $post['published_at'];
                $authorName = htmlspecialchars($post['first_name'] . ' ' . $post['last_name'], ENT_QUOTES, 'UTF-8');
                $categoryName = htmlspecialchars($post['category_name'], ENT_QUOTES, 'UTF-8');
                $categorySlug = htmlspecialchars($post['category_slug'], ENT_QUOTES, 'UTF-8');
                $authorAvatar = $post['avatar'] ? htmlspecialchars($post['avatar'], ENT_QUOTES, 'UTF-8') : '';
                
                // محدود کردن طول محتوا
                $shortExcerpt = strlen($postExcerpt) > 120 ? 
                    mb_substr($postExcerpt, 0, 120,'UTF-8') . '...' : $postExcerpt;
                ?>
                
                <div class="col-md-6 col-lg-4" 
                     data-aos="fade-up" 
                     data-aos-delay="<?php echo ($index * 100) + 100; ?>">
                    <div class="post-card h-100">
                        <!-- Post Image -->
                        <?php if ($latestShowFeatured && $postImage): ?>
                            <div class="post-image">
                                <img src="<?php echo $postImage; ?>" 
                                     alt="<?php echo $postTitle; ?>" 
                                     class="img-fluid"
                                     loading="lazy"
                                     onerror="this.src='public/placeholder.jpg'">
                                <div class="post-overlay">
                                    <a href="post.php?slug=<?php echo $postSlug; ?>" 
                                       class="btn btn-light btn-sm">
                                        <i class="bi bi-eye"></i>
                                        مشاهده
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="post-content h-100">
                            <!-- Category Badge -->
                            <?php if ($latestShowCategory && $categoryName): ?>
                                <div class="post-category">
                                    <a href="category.php?slug=<?php echo $categorySlug; ?>" 
                                       class="category-badge">
                                        <?php echo $categoryName; ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Post Title -->
                            <h5 class="post-title">
                                <a href="post.php?slug=<?php echo $postSlug; ?>">
                                    <?php echo $postTitle; ?>
                                </a>
                            </h5>
                            
                            <!-- Post Excerpt -->
                            <?php if ($latestShowExcerpt && $shortExcerpt): ?>
                                <p class="post-excerpt">
                                    <?php echo $shortExcerpt; ?>
                                </p>
                            <?php endif; ?>
                            
                            <!-- Post Meta -->
                            <div class="post-meta">
                                <?php if ($latestShowAuthor): ?>
                                    <div class="post-author">
                                        <?php if ($authorAvatar): ?>
                                            <img src="<?php echo $authorAvatar; ?>" 
                                                 alt="<?php echo $authorName; ?>" 
                                                 class="author-avatar"
                                                 loading="lazy"
                                                 onerror="this.src='public/placeholder-user.jpg'">
                                        <?php else: ?>
                                            <div class="author-avatar-placeholder">
                                                <i class="bi bi-person"></i>
                                            </div>
                                        <?php endif; ?>
                                        <span class="author-name"><?php echo $authorName; ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($latestShowDate): ?>
                                    <div class="post-date">
                                        <i class="bi bi-calendar3"></i>
                                        <span><?php echo formatPersianDate($postDate); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Post Actions -->
                            <div class="post-actions">
                                <a href="post.php?slug=<?php echo $postSlug; ?>" 
                                   class="btn btn-primary btn-sm">
                                    <i class="bi bi-arrow-left"></i>
                                    ادامه مطلب
                                </a>
                                
                                <div class="post-stats">
                                    <span class="stat-item">
                                        <i class="bi bi-eye"></i>
                                        <span>0</span>
                                    </span>
                                    <span class="stat-item">
                                        <i class="bi bi-chat"></i>
                                        <span>0</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- View All Button -->
        <div class="text-center mt-5">
            <a href="blog.php" class="btn btn-outline-primary btn-lg">
                <i class="bi bi-collection"></i>
                مشاهده همه مطالب
            </a>
        </div>
    </div>
</section>
<?php endif; ?>
