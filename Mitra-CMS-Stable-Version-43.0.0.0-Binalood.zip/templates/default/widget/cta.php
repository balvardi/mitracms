<?php
// بررسی تنظیمات ویجت CTA
$ctaSettings = $settings['cta_widget'] ?? [];
$ctaEnabled = $ctaSettings['enabled'] ?? true;
$ctaTitle = $ctaSettings['title'] ?? 'آماده شروع هستید؟';
$ctaSubtitle = $ctaSettings['subtitle'] ?? 'همین حالا با ما در ارتباط باشید';
$ctaButtons = $ctaSettings['buttons'] ?? [
    ['text' => 'تماس با ما', 'url' => 'page.php?slug=contact', 'type' => 'light', 'icon' => 'telephone'],
    ['text' => 'درباره ما', 'url' => 'page.php?slug=about', 'type' => 'outline-light', 'icon' => 'info-circle']
];
$ctaBackground = $ctaSettings['background'] ?? 'gradient';
$ctaAnimation = $ctaSettings['animation'] ?? 'fade-in';
$ctaShowStats = $ctaSettings['show_stats'] ?? false;
$ctaStats = $ctaSettings['stats'] ?? [];

// بررسی دسترسی و امنیت
if (!isset($settings) || !is_array($settings)) {
    $settings = [];
}

// پاکسازی ورودی‌ها
$ctaTitle = htmlspecialchars($ctaTitle, ENT_QUOTES, 'UTF-8');
$ctaSubtitle = htmlspecialchars($ctaSubtitle, ENT_QUOTES, 'UTF-8');

// اگر ویجت غیرفعال است، نمایش نده
if (!$ctaEnabled) {
    return;
}
?>

<!-- CTA Section -->
<section class="cta-section py-5 position-relative overflow-hidden" 
         data-animation="<?php echo $ctaAnimation; ?>"
         data-background="<?php echo $ctaBackground; ?>">
    
    <!-- Background Elements -->
    <div class="cta-background">
        <div class="bg-pattern"></div>
        <div class="floating-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </div>
    
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-6 text-center text-white">
                
                <!-- Main Content -->
                <div class="cta-content" data-aos="fade-up" data-aos-delay="100">
                    <h2 class="cta-title mb-4 fw-bold">
                        <?php echo $ctaTitle; ?>
                    </h2>
                    
                    <p class="cta-subtitle lead mb-5 opacity-90">
                        <?php echo $ctaSubtitle; ?>
                    </p>
                    
                    <!-- Action Buttons -->
                    <div class="cta-buttons d-flex flex-wrap justify-content-center gap-3 mb-4">
                        <?php foreach ($ctaButtons as $button): ?>
                            <?php 
                            $buttonText = htmlspecialchars($button['text'] ?? '', ENT_QUOTES, 'UTF-8');
                            $buttonUrl = htmlspecialchars($button['url'] ?? '#', ENT_QUOTES, 'UTF-8');
                            $buttonType = htmlspecialchars($button['type'] ?? 'light', ENT_QUOTES, 'UTF-8');
                            $buttonIcon = htmlspecialchars($button['icon'] ?? '', ENT_QUOTES, 'UTF-8');
                            $buttonTarget = strpos($buttonUrl, 'http') === 0 ? '_blank' : '_self';
                            ?>
                            <a href="<?php echo $buttonUrl; ?>" 
                               class="btn btn-<?php echo $buttonType; ?> btn-lg px-4 py-3 cta-btn"
                               target="<?php echo $buttonTarget; ?>"
                               <?php if ($buttonTarget === '_blank'): ?>
                               rel="noopener noreferrer"
                               <?php endif; ?>>
                                <?php if ($buttonIcon): ?>
                                    <i class="bi bi-<?php echo $buttonIcon; ?> me-2"></i>
                                <?php endif; ?>
                                <?php echo $buttonText; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Stats Section -->
                    <?php if ($ctaShowStats && !empty($ctaStats)): ?>
                        <div class="cta-stats mt-5 pt-4 border-top border-white border-opacity-25">
                            <div class="row text-center">
                                <?php foreach ($ctaStats as $stat): ?>
                                    <div class="col-4">
                                        <div class="stat-item">
                                            <div class="stat-number fw-bold mb-1">
                                                <?php echo htmlspecialchars($stat['value'] ?? '0', ENT_QUOTES, 'UTF-8'); ?>
                                            </div>
                                            <div class="stat-label small opacity-75">
                                                <?php echo htmlspecialchars($stat['label'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Trust Indicators -->
                <div class="trust-indicators mt-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="d-flex flex-wrap justify-content-center align-items-center gap-4 opacity-75">
                        <div class="trust-item">
                            <i class="bi bi-shield-check text-success"></i>
                            <span class="small">امن و قابل اعتماد</span>
                        </div>
                        <div class="trust-item">
                            <i class="bi bi-clock text-warning"></i>
                            <span class="small">پشتیبانی 24/7</span>
                        </div>
                        <div class="trust-item">
                            <i class="bi bi-star text-warning"></i>
                            <span class="small">کیفیت تضمین شده</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.cta-section {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    position: relative;
    overflow: hidden;
}

.cta-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
}

.bg-pattern {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        radial-gradient(circle at 25% 25%, rgba(255,255,255,0.1) 0%, transparent 50%),
        radial-gradient(circle at 75% 75%, rgba(255,255,255,0.1) 0%, transparent 50%);
    background-size: 100px 100px;
}

.floating-shapes {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    pointer-events: none;
}

.shape {
    position: absolute;
    border-radius: 50%;
    background: rgba(255,255,255,0.1);
    animation: float 6s ease-in-out infinite;
}

.shape-1 {
    width: 60px;
    height: 60px;
    top: 20%;
    left: 10%;
    animation-delay: 0s;
}

.shape-2 {
    width: 40px;
    height: 40px;
    top: 60%;
    right: 15%;
    animation-delay: 2s;
}

.shape-3 {
    width: 80px;
    height: 80px;
    bottom: 20%;
    left: 20%;
    animation-delay: 4s;
}

@keyframes float {
    0%, 100% { 
        transform: translateY(0px) rotate(0deg); 
        opacity: 0.7;
    }
    50% { 
        transform: translateY(-20px) rotate(180deg); 
        opacity: 1;
    }
}

.cta-section .container {
    position: relative;
    z-index: 2;
}

.cta-title {
    font-size: 2.5rem;
    font-weight: 700;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.cta-subtitle {
    font-size: 1.2rem;
    line-height: 1.6;
}

.cta-buttons {
    gap: 15px;
}

.cta-btn {
    border-radius: 50px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.cta-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s ease;
}

.cta-btn:hover::before {
    left: 100%;
}

.cta-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
}

.btn-light {
    background: rgba(255,255,255,0.9);
    border: 2px solid rgba(255,255,255,0.9);
    color: #667eea;
}

.btn-light:hover {
    background: white;
    border-color: white;
    color: #667eea;
}

.btn-outline-light {
    background: transparent;
    border: 2px solid rgba(255,255,255,0.8);
    color: white;
}

.btn-outline-light:hover {
    background: rgba(255,255,255,0.1);
    border-color: white;
    color: white;
}

.cta-stats {
    border-top: 1px solid rgba(255,255,255,0.2);
}

.stat-item {
    padding: 10px;
}

.stat-number {
    font-size: 2rem;
    font-weight: 700;
    color: white;
}

.stat-label {
    color: rgba(255,255,255,0.8);
}

.trust-indicators {
    margin-top: 30px;
}

.trust-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
}

.trust-item i {
    font-size: 1.1rem;
}

/* Animation Classes */
[data-animation="fade-in"] {
    opacity: 0;
    animation: fadeInUp 1s ease-out forwards;
}

[data-animation="slide-up"] {
    opacity: 0;
    transform: translateY(50px);
    animation: slideUp 1s ease-out forwards;
}

[data-animation="zoom-in"] {
    opacity: 0;
    transform: scale(0.9);
    animation: zoomIn 1s ease-out forwards;
}

@keyframes fadeInUp {
    to { 
        opacity: 1; 
        transform: translateY(0);
    }
}

@keyframes slideUp {
    to { 
        opacity: 1; 
        transform: translateY(0);
    }
}

@keyframes zoomIn {
    to { 
        opacity: 1; 
        transform: scale(1);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .cta-title {
        font-size: 2rem;
    }
    
    .cta-subtitle {
        font-size: 1.1rem;
    }
    
    .cta-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .cta-btn {
        width: 100%;
        max-width: 300px;
    }
    
    .trust-indicators {
        flex-direction: column;
        gap: 15px;
    }
    
    .trust-item {
        justify-content: center;
    }
}

@media (max-width: 576px) {
    .cta-title {
        font-size: 1.8rem;
    }
    
    .cta-subtitle {
        font-size: 1rem;
    }
    
    .stat-number {
        font-size: 1.5rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // CTA Animation
    const ctaSection = document.querySelector('.cta-section');
    const animation = ctaSection.dataset.animation;
    
    if (animation) {
        ctaSection.classList.add(animation);
    }
    
    // Button click tracking
    const ctaButtons = document.querySelectorAll('.cta-btn');
    ctaButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Track button click for analytics
            const buttonText = this.textContent.trim();
            const buttonUrl = this.getAttribute('href');
            
            // You can add analytics tracking here
            console.log('CTA Button clicked:', {
                text: buttonText,
                url: buttonUrl,
                timestamp: new Date().toISOString()
            });
        });
    });
    
    // Parallax effect for floating shapes
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const shapes = document.querySelectorAll('.shape');
        
        shapes.forEach((shape, index) => {
            const speed = 0.5 + (index * 0.1);
            shape.style.transform = `translateY(${scrolled * speed}px)`;
        });
    });
    
    // Intersection Observer for animation
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe CTA elements
    const ctaElements = document.querySelectorAll('.cta-content, .trust-indicators');
    ctaElements.forEach(element => {
        observer.observe(element);
    });
});
</script>
