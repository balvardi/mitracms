<a href="" title="">
<i class="bi bi-facebook-f"></i>
</a>
<a href="" title="">
<i class="bi bi-twitter"></i>
</a>
<a href="" title="">
<i class="bi bi-google"></i>
</a>
<a href="" title="">
<i class="bi bi-instagram"></i>
</a>
<a href="" title="">
<i class="bi bi-linkedin"></i>
</a>
<a href="" title="">
<i class="bi bi-pinterest"></i>
</a>
<a href="" title="">
<i class="bi bi-stack-overflow"></i>
</a>
<a href="" title="">
<i class="bi bi-youtube"></i>
</a>
<a href="" title="">
<i class="bi bi-github"></i>
</a>
<a href="" title="">
<i class="bi bi-dribbble"></i>
</a>
<a href="" title="">
<i class="bi bi-whatsapp"></i>
</a>
