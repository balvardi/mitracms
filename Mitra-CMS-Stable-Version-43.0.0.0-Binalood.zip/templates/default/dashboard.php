    <!-- Dashboard Header -->
    <section class="dashboard-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="display-5 fw-bold">خوش آمدید، <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h1>
                    <p class="lead">داشبورد شخصی شما در <?php echo htmlspecialchars($siteName) ?></p>
                    <div class="d-flex align-items-center mt-3">
                        <span class="badge bg-light text-dark me-2"><?php echo htmlspecialchars($user['role']) ?></span>
                        <small class="text-white-50">
                            آخرین ورود: <?php echo $user['last_login'] ? date('Y/m/d H:i', strtotime($user['last_login'])) : 'اولین ورود' ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Dashboard Content -->
    <section class="py-5">
        <div class="container">
            <!-- User Stats -->
            <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
            <div class="row mb-5">
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-file-text display-4 text-primary mb-3"></i>
                        <h3><?php echo $userStats['posts'] ?></h3>
                        <p class="text-muted">مطالب شما</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-file-earmark display-4 text-success mb-3"></i>
                        <h3><?php echo $userStats['pages'] ?></h3>
                        <p class="text-muted">صفحات شما</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card text-center">
                        <i class="bi bi-calendar-check display-4 text-info mb-3"></i>
                        <h3><?php echo date('Y/m/d') ?></h3>
                        <p class="text-muted">امروز</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <!-- Profile Info -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-person"></i> اطلاعات شخصی</h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <?php if ($user['avatar']): ?>
                                    <img src="<?php echo htmlspecialchars($user['avatar']) ?>" alt="آواتار" class="rounded-circle" width="80" height="80">
                                <?php else: ?>
                                    <i class="bi bi-person-circle display-4 text-muted"></i>
                                <?php endif; ?>
                            </div>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>نام:</strong></td>
                                    <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>نام کاربری:</strong></td>
                                    <td><?php echo htmlspecialchars($user['username']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>ایمیل:</strong></td>
                                    <td><?php echo htmlspecialchars($user['email']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>نقش:</strong></td>
                                    <td><span class="badge bg-primary"><?php echo htmlspecialchars($user['role']) ?></span></td>
                                </tr>
                                <tr>
                                    <td><strong>عضویت:</strong></td>
                                    <td><?php echo date('Y/m/d', strtotime($user['created_at'])) ?></td>
                                </tr>
                            </table>
                            <?php if ($user['bio']): ?>
                                <div class="mt-3">
                                    <strong>درباره من:</strong>
                                    <p class="text-muted mt-2"><?php echo htmlspecialchars($user['bio']) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-lightning"></i> عملیات سریع</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
                                    <a href="admin/index.php?page=posts&action=add" class="btn btn-primary">
                                        <i class="bi bi-plus-circle"></i> مطلب جدید
                                    </a>
                                    <a href="admin/index.php?page=pages&action=add" class="btn btn-outline-primary">
                                        <i class="bi bi-file-plus"></i> صفحه جدید
                                    </a>
                                <?php endif; ?>
                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                    <a href="admin/index.php?page=users" class="btn btn-outline-success">
                                        <i class="bi bi-people"></i> مدیریت کاربران
                                    </a>
                                    <a href="admin/index.php?page=settings" class="btn btn-outline-info">
                                        <i class="bi bi-gear"></i> تنظیمات
                                    </a>
                                <?php endif; ?>
                                <a href="profile.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-person-gear"></i> ویرایش پروفایل
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> فعالیت‌های اخیر</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($userStats['recent_posts'])): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($userStats['recent_posts'] as $post): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($post['title']) ?></h6>
                                                    <small class="text-muted"><?php echo date('Y/m/d', strtotime($post['created_at'])) ?></small>
                                                </div>
                                                <span class="badge bg-<?php echo $post['status'] === 'published' ? 'success' : 'warning' ?>">
                                                    <?php echo $post['status'] === 'published' ? 'منتشر شده' : 'پیش‌نویس' ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center">فعالیتی یافت نشد</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Info (Admin Only) -->
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-info-circle"></i> اطلاعات سیستم</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <strong>نسخه PHP:</strong><br>
                                    <span class="text-muted"><?php echo PHP_VERSION ?></span>
                                </div>
                                <div class="col-md-3">
                                    <strong>نسخه MySQL:</strong><br>
                                    <span class="text-muted">
                                        <?php
                                        try {
                                            $version = $pdo->query('SELECT VERSION()')->fetchColumn();
                                            echo htmlspecialchars($version);
                                        } catch (Exception $e) {
                                            echo 'نامشخص';
                                        }
                                        ?>
                                    </span>
                                </div>
                                <div class="col-md-3">
                                    <strong>حافظه استفاده شده:</strong><br>
                                    <span class="text-muted"><?php echo round(memory_get_usage() / 1024 / 1024, 2) ?> MB</span>
                                </div>
                                <div class="col-md-3">
                                    <strong>زمان اجرا:</strong><br>
                                    <span class="text-muted"><?php echo round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 3) ?> ثانیه</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

