    <div class="container-fluid mt-5 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="auth-card">
                    <div class="auth-header">
                        <h2 class="mb-0"><?php echo $action === 'register' ? 'ثبت نام' : 'ورود به سیستم' ?></h2>
                        <p class="mb-0 mt-2">Mitra CMS</p>
                    </div>
                    
                    <div class="auth-body">
                        <?php if ($message): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($message) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($action === 'login'): ?>
                            <!-- فرم ورود -->
                            <form method="post">
                                <div class="mb-3">
                                    <label class="form-label">نام کاربری یا ایمیل</label>
                                    <input type="text" class="form-control" name="username" required 
                                           value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">ورود</button>
                                </div>
                            </form>
                            
                            <hr>
                            <div class="text-center">
                                <p>حساب کاربری ندارید؟ <a href="?action=register">ثبت نام کنید</a></p>
                                <a href="index.php" class="text-muted">بازگشت به صفحه اصلی</a>
                            </div>
                            
                        <?php else: ?>
                            <!-- فرم ثبت نام -->
                            <form method="post">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">نام</label>
                                            <input type="text" class="form-control" name="first_name" required
                                                   value="<?php echo htmlspecialchars($_POST['first_name'] ?? '') ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">نام خانوادگی</label>
                                            <input type="text" class="form-control" name="last_name" required
                                                   value="<?php echo htmlspecialchars($_POST['last_name'] ?? '') ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" name="username" required
                                           value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" name="email" required
                                           value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">تکرار رمز عبور</label>
                                    <input type="password" class="form-control" name="confirm_password" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">ثبت نام</button>
                                </div>
                            </form>
                            
                            <hr>
                            <div class="text-center">
                                <p>قبلاً ثبت نام کرده‌اید؟ <a href="?action=login">وارد شوید</a></p>
                                <a href="index.php" class="text-muted">بازگشت به صفحه اصلی</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
