		<!-- Page Header -->
		<section class="page-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-8">
						<h1 class="display-5 fw-bold"><?php echo htmlspecialchars($post['title']) ?></h1>
						<?php if ($post['excerpt']): ?>
							<p class="lead"><?php echo htmlspecialchars($post['excerpt']) ?></p>
						<?php endif; ?>
						<div class="d-flex align-items-center mt-3">
							<small class="text-white-50">
								آخرین بروزرسانی: <?php echo date('Y/m/d', strtotime($post['updated_at'])) ?>
							</small>
						</div>
					</div>
				</div>
			</div>
		</section>
        <div class="container mb-5 mt-5">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <!-- Post Meta -->
                    <div class="post-meta mb-3">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <i class="bi bi-person-circle text-primary"></i>
                                <strong>نویسنده:</strong> <?php echo htmlspecialchars($post['author_name']) ?>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <i class="bi bi-calendar3 text-primary"></i>
                                <strong>تاریخ انتشار:</strong> <?php echo formatPersianDate($post['created_at']) ?>
                            </div>
                        </div>
                        <?php if ($post['updated_at'] != $post['created_at']): ?>
                            <div class="row mt-2">
                                <div class="col-12 text-muted">
                                    <small>
                                        <i class="bi bi-pencil-square"></i>
                                        آخرین بروزرسانی: <?php echo formatPersianDate($post['updated_at']) ?>
                                    </small>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Featured Image -->
                    <?php if (!empty($post['featured_image'])): ?>
                        <div class="text-center mb-4">
                            <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" 
                                 class="img-fluid rounded" 
                                 alt="<?php echo htmlspecialchars($post['title']) ?>"
                                 style="max-height: 400px; object-fit: cover;">
                        </div>
                    <?php endif; ?>

                    <!-- Post Content -->
                    <div class="post-content">
                        <?php echo $post['content'] ?>
                    </div>

                    <div class="post-comment">
                        <?php include 'widget/comments.php'; ?>
                    </div>

                    <!-- Share Buttons -->
                    <div class="share-buttons text-center">
                        <h6 class="mb-3"><i class="bi bi-share"></i> اشتراک‌گذاری این مطلب</h6>
                        <?php
                        $current_url = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        $post_title = urlencode($post['title']);
                        ?>
                        <a href="https://t.me/share/url?url=<?php echo $current_url ?>&text=<?php echo $post_title ?>" 
                           class="share-btn share-telegram" target="_blank">
                            <i class="bi bi-telegram"></i> تلگرام
                        </a>
                        <a href="https://wa.me/?text=<?php echo $post_title ?>%20<?php echo $current_url ?>" 
                           class="share-btn share-whatsapp" target="_blank">
                            <i class="bi bi-whatsapp"></i> واتساپ
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo $post_title ?>&url=<?php echo $current_url ?>" 
                           class="share-btn share-twitter" target="_blank">
                            <i class="bi bi-twitter"></i> توییتر
                        </a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url ?>" 
                           class="share-btn share-facebook" target="_blank">
                            <i class="bi bi-facebook"></i> فیسبوک
                        </a>
                    </div>


                    <!-- Navigation -->
                    <div class="d-flex justify-content-between mt-4">
                        <a href="blog.php" class="btn btn-outline-primary">
                            <i class="bi bi-arrow-right"></i> بازگشت به وبلاگ
                        </a>
                        <?php if (!empty($post['category_name'])): ?>
                            <a href="blog.php?category=<?php echo $post['category_id'] ?>" class="btn btn-outline-secondary">
                                مطالب <?php echo htmlspecialchars($post['category_name']) ?> <i class="bi bi-arrow-left"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4 mx-auto">
                    <!-- Related Posts -->
                    <?php if (!empty($related_posts)): ?>
                        <div class="related-posts">
                            <h4 class="fw-bold mb-4">
                                <i class="bi bi-collection"></i> مطالب مرتبط
                            </h4>
                            <div class="row">
                                <?php foreach ($related_posts as $related): ?>
                                    <div class="col-md-12 mb-3">
                                        <div class="post related-post-card h-100">
                                            <?php if (!empty($related['featured_image'])): ?>
                                                <img src="<?php echo htmlspecialchars($related['featured_image']) ?>" 
                                                     class="card-img-top" style="height: 150px; object-fit: cover;"
                                                     alt="<?php echo htmlspecialchars($related['title']) ?>">
                                            <?php endif; ?>
                                            <div class="post-body">
                                                <h6 class="post-title">
                                                    <a href="post.php?slug=<?php echo htmlspecialchars($related['slug']) ?>" 
                                                       class="text-decoration-none">
                                                        <?php echo htmlspecialchars($related['title']) ?>
                                                    </a>
                                                </h6>
                                                <?php if (!empty($related['excerpt'])): ?>
                                                    <p class="post-text small text-muted">
                                                        <?php echo htmlspecialchars(mb_substr($related['excerpt'], 0, 100)) ?>...
                                                    </p>
                                                <?php endif; ?>
                                                <small class="text-muted">
                                                    <i class="bi bi-calendar3"></i>
                                                    <?php echo formatPersianDate($related['created_at']) ?>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
