    <!-- Blog Header -->
    <div class="blog-header">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">وبلاگ</h1>
            <p class="lead">آخرین مطالب و مقالات</p>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Search and Filter Form -->
               <?php include 'widget/searchadv.php';?>
                <!-- Posts List -->
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> <?php echo $error ?>
                    </div>
                <?php elseif (empty($posts)): ?>
                    <div class="no-posts">
                        <i class="bi bi-journal-x" style="font-size: 4rem; color: #dee2e6;"></i>
                        <h3 class="mt-3">مطلبی یافت نشد</h3>
                        <p>متأسفانه مطلبی با این معیارها پیدا نشد.</p>
                        <?php if (!empty($search) || $category_id > 0): ?>
                            <a href="blog.php" class="btn btn-outline-primary">نمایش همه مطالب</a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                        <article class="card post-card">
                            <div class="row g-1">
                                <?php if (!empty($post['featured_image'])): ?>
                                    <div class="col-md-4">
                                        <img src="<?php echo htmlspecialchars($post['featured_image']) ?>" 
                                             class="post-image" alt="<?php echo htmlspecialchars($post['title']) ?>">
                                    </div>
                                    <div class="col-md-8">
                                <?php else: ?>
                                    <div class="col-12">
                                <?php endif; ?>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <?php if (!empty($post['category_name'])): ?>
                                                <a href="blog.php?category=<?php echo $post['category_id'] ?>" 
                                                   class="category-badge">
                                                    <?php echo htmlspecialchars($post['category_name']) ?>
                                                </a>
                                            <?php endif; ?>
                                            <small class="post-meta">
                                                <i class="bi bi-calendar3"></i>
                                                <?php echo formatPersianDate($post['created_at']) ?>
                                            </small>
                                        </div>
                                        <h5 class="card-title">
                                            <a href="post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" 
                                               class="post-title">
                                                <?php echo htmlspecialchars($post['title']) ?>
                                            </a>
                                        </h5>
                                        <p class="card-text text-muted">
                                            <?php echo htmlspecialchars(generateExcerpt($post['excerpt'] ?: $post['content'])) ?>
                                        </p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="post-meta">
                                                <i class="bi bi-person"></i>
                                                نویسنده: <?php echo htmlspecialchars($post['author_name']) ?>
                                            </small>
                                            <a href="post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" 
                                               class="btn btn-outline-primary btn-sm">
                                                ادامه مطلب <i class="bi bi-arrow-left"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="صفحه‌بندی مطالب" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1 ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <i class="bi bi-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                $start = max(1, $page - 2);
                                $end = min($total_pages, $page + 2);
                                for ($i = $start; $i <= $end; $i++):
                                ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?php echo $i ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <?php echo $i ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1 ?><?php echo !empty($search) ? '&search=' . urlencode($search) : '' ?><?php echo $category_id > 0 ? '&category=' . $category_id : '' ?>">
                                            <i class="bi bi-chevron-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <div class="text-center text-muted mt-3">
                            صفحه <?php echo $page ?> از <?php echo $total_pages ?> 
                            (<?php echo $total_posts ?> مطلب)
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <!-- Sidebar -->
            <div class="col-lg-4">
               <?php include 'widget/category.php';?>
               <?php include 'widget/list.php';?>
            </div>
        </div>
    </div>
