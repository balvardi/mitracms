    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold"><?php echo htmlspecialchars($page['title']) ?></h1>
                    <?php if ($page['excerpt']): ?>
                        <p class="lead"><?php echo htmlspecialchars($page['excerpt']) ?></p>
                    <?php endif; ?>
                    <div class="d-flex align-items-center mt-3">
                        <small class="text-white-50">
                            نویسنده: <?php echo htmlspecialchars($page['first_name'] . ' ' . $page['last_name']) ?>
                        </small>
                        <span class="mx-2 text-white-50">|</span>
                        <small class="text-white-50">
                            آخرین بروزرسانی: <?php echo date('Y/m/d', strtotime($page['updated_at'])) ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Content Area -->
    <section class="content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if ($page['featured_image']): ?>
                        <img src="<?php echo htmlspecialchars($page['featured_image']) ?>" 
                             alt="<?php echo htmlspecialchars($page['title']) ?>" 
                             class="img-fluid rounded mb-4">
                    <?php endif; ?>
                    
                    <div class="content">
                        <?php echo $page['content'] ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

