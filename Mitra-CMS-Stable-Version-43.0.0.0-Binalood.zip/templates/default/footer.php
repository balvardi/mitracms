<footer>
<?php
// فایل JSON را بخوانید (محتوای شما در اینجا قرار دارد)
$jsonContent = file_get_contents('templates/'.$settings['theme'].'/structure.json'); // یا از ورودی استرینگ استفاده کنید
$data = json_decode($jsonContent, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    die('خطا در خواندن JSON: ' . json_last_error_msg());
}
$prefix = $data['perfix'] ?? 'dima';
$framework = $data['framework'] ?? 'bootstrap';
$direction = $data['direction'] ?? 'ltr';
$unit = $data['unit'] ?? '%';
// تنظیم کلاس‌های RTL
$directionClass = $direction === 'rtl' ? ' direction-rtl' : '';
$sections = $data['column'][$prefix] ?? [];
?>
<?php foreach ($sections as $sectionName => $rows):?>
   <?php if($sectionName=='footer'):?>
	<section class="section <?php echo htmlspecialchars($sectionName);?>" id="<?php echo htmlspecialchars($sectionName);?>">
    <?php foreach ($rows as $rowIndex => $columns):?>
        <div class="row m-auto section-<?php echo $sectionName;?>-<?php echo $rowIndex;?>">
        <?php foreach ($columns as $colIndex => $col):?>
        	<?php if(file_exists('templates/'.$settings['theme'].'/widget/'.$col['title'].'.php')):?>
            <div class="col-md-<?php echo round(12/(100/$col['size']));?> position-<?php echo $col['title'];?> wow <?php echo $col['effect'];?>">
            	<?php require 'templates/'.$settings['theme'].'/widget/'.$col['title'].'.php';?>
           	</div>
           	<?php endif;?>
        <?php endforeach;?>
		</div>
    <?php endforeach;?>
	</section>
	<?php endif;?>
<?php endforeach;?>
</footer>
    <script src="scripts/bootstrap.bundle.min.js"></script>
</body>
</html>
