<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $settings['site_name']; ?> - <?php echo $settings['site_description']; ?></title>
    <meta name="description" content="<?php echo $settings['site_description']; ?>">
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/vazirmatn.css" rel="stylesheet">
    <link href="styles/bootstrap-icons.css" rel="stylesheet">
    <link href="templates/<?php echo $settings['theme']; ?>/style.rtl.css" rel="stylesheet">
</head>
<body class="user">
<header>
<?php
// فایل JSON را بخوانید (محتوای شما در اینجا قرار دارد)
$jsonContent = file_get_contents('templates/'.$settings['theme'].'/structure.json'); // یا از ورودی استرینگ استفاده کنید
$data = json_decode($jsonContent, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    die('خطا در خواندن JSON: ' . json_last_error_msg());
}
$prefix = $data['perfix'] ?? 'dima';
$framework = $data['framework'] ?? 'bootstrap';
$direction = $data['direction'] ?? 'ltr';
$unit = $data['unit'] ?? '%';
// تنظیم کلاس‌های RTL
$directionClass = $direction === 'rtl' ? ' direction-rtl' : '';
$sections = $data['column'][$prefix] ?? [];
?>
<?php foreach ($sections as $sectionName => $rows):?>
   <?php if($sectionName=='header'):?>
	<section class="section <?php echo htmlspecialchars($sectionName);?>" id="<?php echo htmlspecialchars($sectionName);?>">
    <?php foreach ($rows as $rowIndex => $columns):?>
        <div class="row m-auto section-<?php echo $sectionName;?>-<?php echo $rowIndex;?>">
        <?php foreach ($columns as $colIndex => $col):?>
        	<?php if(file_exists('templates/'.$settings['theme'].'/widget/'.$col['title'].'.php')):?>
            <div class="col-md-<?php echo round(12/(100/$col['size']));?> position-<?php echo $col['title'];?> wow <?php echo $col['effect'];?>">
            	<?php require 'templates/'.$settings['theme'].'/widget/'.$col['title'].'.php';?>
           	</div>
           	<?php endif;?>
        <?php endforeach;?>
		</div>
    <?php endforeach;?>
	</section>
	<?php endif;?>
<?php endforeach;?>
</header>