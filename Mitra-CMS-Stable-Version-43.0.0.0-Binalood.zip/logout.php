<?php
// شروع جلسه
session_start();

// ثبت خروج در لاگ
if (isset($_SESSION['user_id'])) {
    try {
        require_once 'config/connection.php';
        $pdo = getDatabase();
        
        $stmt = $pdo->prepare("UPDATE users SET last_logout = NOW() WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
    } catch (Exception $e) {
        error_log('Logout logging error: ' . $e->getMessage());
    }
}

// پاکسازی تمام متغیرهای جلسه
$_SESSION = array();

// حذف کوکی جلسه
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// نابودی جلسه
session_destroy();

// هدایت به صفحه ورود
header('Location: auth.php?message=logged_out');
exit;
?>
