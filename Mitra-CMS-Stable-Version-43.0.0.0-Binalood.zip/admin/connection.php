<?php
// تنظیمات امنیتی جلسه
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// تنظیمات امنیتی کوکی فقط در HTTPS
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}

session_start();

// تنظیمات امنیتی HTTP Headers (فقط در production)
if (!isset($_SERVER['HTTP_HOST']) || strpos($_SERVER['HTTP_HOST'], 'localhost') === false) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: https:; font-src \'self\' data:;');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

// بارگذاری متغیرهای محیطی
if (file_exists('.env')) {
    $env = parse_ini_file('.env');
    foreach ($env as $key => $value) {
        $_ENV[$key] = $value;
    }
}

// بررسی نصب (فقط در production)
if (!file_exists('.installed') && (!isset($_SERVER['HTTP_HOST']) || strpos($_SERVER['HTTP_HOST'], 'localhost') === false)) {
    header('Location: install.php');
    exit;
}

// تنظیمات امنیتی
define('SESSION_LIFETIME', 3600); // 1 ساعت
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 دقیقه
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SECURE_SALT', $_ENV['APP_SECRET'] ?? bin2hex(random_bytes(32)));

// تنظیمات آپلود
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_FILE_TYPES', ['pdf', 'doc', 'docx', 'txt', 'zip']);

// تابع تولید توکن CSRF
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

// تابع بررسی توکن CSRF
function verifyCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

// تابع پاکسازی ورودی پیشرفته
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    // حذف کاراکترهای خطرناک
    $input = preg_replace('/[^\p{L}\p{N}\s\-_\.@]/u', '', $input);
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// تابع بررسی دسترسی پیشرفته
function checkPermission($requiredRole) {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        return false;
    }
    
    // بررسی انقضای جلسه
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_LIFETIME) {
        session_destroy();
        return false;
    }
    
    $userRole = $_SESSION['role'] ?? 'user';
    $roleHierarchy = [
        'user' => 1,
        'author' => 2,
        'editor' => 3,
        'admin' => 4
    ];
    
    return ($roleHierarchy[$userRole] ?? 0) >= ($roleHierarchy[$requiredRole] ?? 0);
}

// تابع بررسی IP
function checkIP() {
    $allowedIPs = $_ENV['ALLOWED_IPS'] ?? '';
    if (!empty($allowedIPs)) {
        $clientIP = $_SERVER['REMOTE_ADDR'];
        $allowedIPs = explode(',', $allowedIPs);
        if (!in_array($clientIP, $allowedIPs)) {
            http_response_code(403);
            die('دسترسی غیرمجاز');
        }
    }
}

// تابع محدودیت Rate Limiting
function checkRateLimit($action, $limit = 10, $timeWindow = 60) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $key = "rate_limit_{$action}_{$ip}";
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = ['count' => 0, 'reset_time' => time() + $timeWindow];
    }
    
    if (time() > $_SESSION[$key]['reset_time']) {
        $_SESSION[$key] = ['count' => 0, 'reset_time' => time() + $timeWindow];
    }
    
    $_SESSION[$key]['count']++;
    
    if ($_SESSION[$key]['count'] > $limit) {
        http_response_code(429);
        die('تعداد درخواست‌ها بیش از حد مجاز است');
    }
}

// تابع بررسی فایل آپلود شده
function validateUploadedFile($file) {
    // بررسی خطاهای آپلود
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'خطا در آپلود فایل'];
    }
    
    // بررسی اندازه فایل
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'message' => 'حجم فایل بیش از حد مجاز است'];
    }
    
    // بررسی نوع فایل
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'text/plain' => 'txt',
        'application/zip' => 'zip'
    ];
    
    if (!array_key_exists($mimeType, $allowedMimeTypes)) {
        return ['success' => false, 'message' => 'نوع فایل مجاز نیست'];
    }
    
    // بررسی پسوند فایل
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $expectedExtension = $allowedMimeTypes[$mimeType];
    
    if ($extension !== $expectedExtension) {
        return ['success' => false, 'message' => 'پسوند فایل با نوع آن مطابقت ندارد'];
    }
    
    // بررسی محتوای فایل (برای تصاویر)
    if (strpos($mimeType, 'image/') === 0) {
        $imageInfo = getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            return ['success' => false, 'message' => 'فایل تصویر نامعتبر است'];
        }
        
        // محدودیت ابعاد تصویر
        if ($imageInfo[0] > 4000 || $imageInfo[1] > 4000) {
            return ['success' => false, 'message' => 'ابعاد تصویر بیش از حد مجاز است'];
        }
    }
    
    return ['success' => true, 'message' => 'فایل معتبر است'];
}

// تابع تولید نام فایل امن
function generateSecureFilename($originalName, $extension) {
    $timestamp = time();
    $randomString = bin2hex(random_bytes(8));
    return $timestamp . '_' . $randomString . '.' . $extension;
}

// تابع بررسی مسیر فایل
function validateFilePath($path) {
    $realPath = realpath($path);
    $uploadDir = realpath('uploads');
    
    if ($realPath === false || strpos($realPath, $uploadDir) !== 0) {
        return false;
    }
    
    return true;
}

// تابع لاگ امنیتی
function logSecurityEvent($event, $details = []) {
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'ip' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'event' => $event,
        'details' => $details
    ];
    
    $logFile = 'logs/security.log';
    if (!is_dir('logs')) {
        mkdir('logs', 0755, true);
    }
    
    file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
}

// تابع بررسی تلاش‌های ورود
function checkLoginAttempts($username) {
    try {
        $pdo = getDatabase();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM login_attempts 
            WHERE username = ? AND success = 0 AND attempt_time > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        $stmt->execute([$username, LOGIN_LOCKOUT_TIME]);
        $attempts = $stmt->fetchColumn();
        
        return $attempts < MAX_LOGIN_ATTEMPTS;
    } catch (Exception $e) {
        return true; // در صورت خطا، اجازه ورود بده
    }
}

// تابع ثبت تلاش ورود
function logLoginAttempt($username, $success) {
    try {
        $pdo = getDatabase();
        $stmt = $pdo->prepare("
            INSERT INTO login_attempts (username, ip_address, success, attempt_time, user_agent) 
            VALUES (?, ?, ?, NOW(), ?)
        ");
        $stmt->execute([
            $username,
            $_SERVER['REMOTE_ADDR'],
            $success ? 1 : 0,
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    } catch (Exception $e) {
        error_log('Login attempt logging error: ' . $e->getMessage());
    }
}

// تابع پاکسازی تلاش‌های قدیمی
function cleanupOldAttempts() {
    try {
        $pdo = getDatabase();
        $stmt = $pdo->prepare("
            DELETE FROM login_attempts 
            WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->execute();
    } catch (Exception $e) {
        error_log('Cleanup error: ' . $e->getMessage());
    }
}

// بارگذاری تنظیمات
$dbConfig = [];
if (file_exists('../config/database.php')) {
    $dbConfig = require '../config/database.php';
}

require_once 'functions.php';

// اتصال به پایگاه داده
function getDatabase() {
    global $dbConfig;
    if (empty($dbConfig)) {
        logSecurityEvent('database_config_missing');
        die('فایل پیکربندی پایگاه داده یافت نشد');
    }
    
    try {
        $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options'] ?? []);
        
        // تنظیمات امنیتی اضافی PDO
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        
        return $pdo;
    } catch (PDOException $e) {
        logSecurityEvent('database_connection_failed', ['error' => $e->getMessage()]);
        error_log('Database connection error: ' . $e->getMessage());
        die('خطا در اتصال به پایگاه داده');
    }
}

try {
    $pdo = getDatabase();
    
    // دریافت تنظیمات سایت
    $stmt = $pdo->prepare("SELECT * FROM settings");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (PDOException $e) {
    logSecurityEvent('settings_loading_failed', ['error' => $e->getMessage()]);
    error_log('Settings loading error: ' . $e->getMessage());
    die('خطا در بارگذاری تنظیمات');
}
