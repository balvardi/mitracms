<?php

// بارگذاری تنظیمات
require_once 'connection.php';

// بررسی ورود و دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || !in_array($_SESSION['role'], ['admin', 'editor'])) {
    header('Location: ../auth.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// بررسی انقضای جلسه
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_LIFETIME) {
    session_destroy();
    header('Location: ../auth.php?message=session_expired');
    exit;
}

// بروزرسانی زمان جلسه
$_SESSION['login_time'] = time();

// بررسی نصب
if (!file_exists('../.installed')) {
    header('Location: ../install/simple-installer.php');
    exit;
}

// بارگذاری سیستم ماژول‌ها
require_once '../core/ModuleLoader.php';
$moduleLoader = new ModuleLoader($pdo);

// بررسی دسترسی به صفحه
$currentPage = $_GET['page'] ?? 'dashboard';
$allowedPages = [
    'dashboard' => ['admin', 'editor', 'author'],
    'posts' => ['admin', 'editor', 'author'],
    'pages' => ['admin', 'editor', 'author'],
    'menus' => ['admin', 'editor', 'author'],
    'comments' => ['admin', 'editor', 'author'],
    'media' => ['admin', 'editor', 'author'],
    'users' => ['admin'],
    'categories' => ['admin'],
    'modules' => ['admin'],
    'settings' => ['admin']
];

// اضافه کردن صفحات ماژول‌ها
$moduleMenus = $moduleLoader->getModuleMenus();
foreach ($moduleMenus as $moduleName => $menu) {
    if (isset($menu['admin_menu'])) {
        foreach ($menu['admin_menu'] as $menuItem) {
            if (isset($menuItem['submenu'])) {
                foreach ($menuItem['submenu'] as $subItem) {
                    $pageKey = str_replace('admin/', '', $subItem['url']);
                    $allowedPages[$pageKey] = ['admin', 'editor'];
                }
            }
        }
    }
}

if (!isset($allowedPages[$currentPage]) || !in_array($_SESSION['role'], $allowedPages[$currentPage])) {
    header('Location: ?page=dashboard');
    exit;
}

$pdo = getDatabase();

// دریافت تنظیمات سایت
$stmt = $pdo->prepare("SELECT * FROM settings");
$stmt->execute();
$settings = [];
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$siteName = $settings['site_name'] ?? 'Mitra CMS';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت - <?php echo htmlspecialchars($siteName) ?></title>
    <link href="../styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="../styles/vazirmatn.css" rel="stylesheet">
    <link href="../styles/bootstrap-icons.css" rel="stylesheet">
    <link href="../styles/style.rtl.css" rel="stylesheet">
    <script src="../scripts/tinymce.min.js" referrerpolicy="origin"></script>
    <meta name="csrf-token" content="<?php echo generateCSRFToken(); ?>">
</head>
<body class="admin">
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="p-3">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4>پنل مدیریت</h4>
                <button class="btn btn-link text-white d-md-none" id="closeSidebar">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <div class="text-center mb-4">
                <i class="bi bi-person-circle display-6"></i>
                <div class="mt-2">
                    <strong><?php echo htmlspecialchars($_SESSION['username']) ?></strong>
                    <br>
                    <small class="text-white-50"><?php echo htmlspecialchars($_SESSION['role']) ?></small>
                </div>
            </div>
        </div>
        
        <nav class="nav flex-column px-3">
            <a class="nav-link <?php echo $currentPage === 'dashboard' ? 'active' : '' ?>" href="?page=dashboard">
                <i class="bi bi-speedometer2 me-2"></i> داشبورد
            </a>
            
            <?php if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])): ?>
            <a class="nav-link <?php echo $currentPage === 'posts' ? 'active' : '' ?>" href="?page=posts">
                <i class="bi bi-file-text me-2"></i> مطالب
            </a>
            <a class="nav-link <?php echo $currentPage === 'pages' ? 'active' : '' ?>" href="?page=pages">
                <i class="bi bi-file-earmark me-2"></i> صفحات
            </a>
            <a class="nav-link <?php echo $currentPage === 'comments' ? 'active' : '' ?>" href="?page=comments">
                <i class="bi bi-chat-dots me-2"></i> نظرات
            </a>
            <a class="nav-link <?php echo $currentPage === 'media' ? 'active' : '' ?>" href="?page=media">
                <i class="bi bi-images me-2"></i> رسانه
            </a>
            <?php endif; ?>
            
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a class="nav-link <?php echo $currentPage === 'menus' ? 'active' : '' ?>" href="?page=menus">
                <i class="bi bi-menu-app me-2"></i> منوها
            </a>
            <a class="nav-link <?php echo $currentPage === 'users' ? 'active' : '' ?>" href="?page=users">
                <i class="bi bi-people me-2"></i> کاربران
            </a>
            <a class="nav-link <?php echo $currentPage === 'categories' ? 'active' : '' ?>" href="?page=categories">
                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
            </a>
            <a class="nav-link <?php echo $currentPage === 'modules' ? 'active' : '' ?>" href="?page=modules">
                <i class="bi bi-puzzle me-2"></i> ماژول‌ها
            </a>
            <a class="nav-link <?php echo $currentPage === 'settings' ? 'active' : '' ?>" href="?page=settings">
                <i class="bi bi-gear me-2"></i> تنظیمات
            </a>
            <?php endif; ?>
            
            <!-- منوهای ماژول‌ها -->
            <?php foreach ($moduleMenus as $moduleName => $menu): ?>
                <?php if (isset($menu['admin_menu'])): ?>
                    <?php foreach ($menu['admin_menu'] as $menuItem): ?>
                        <?php if (checkPermission($menuItem['permission'] ?? 'admin')): ?>
                            <div class="nav-item">
                                <a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#<?php echo $moduleName ?>Menu">
                                    <i class="<?php echo $menuItem['icon'] ?> me-2"></i> <?php echo htmlspecialchars($menuItem['title']) ?>
                                    <i class="bi bi-chevron-down ms-auto"></i>
                                </a>
                                <div class="collapse" id="<?php echo $moduleName ?>Menu">
                                    <nav class="nav flex-column ms-3">
                                        <?php foreach ($menuItem['submenu'] as $subItem): ?>
                                            <a class="nav-link" href="<?php echo $subItem['url'] ?>">
                                                <i class="<?php echo $subItem['icon'] ?> me-2"></i> <?php echo htmlspecialchars($subItem['title']) ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </nav>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            <?php endforeach; ?>
            
            <hr class="text-white-50">
            <a class="nav-link" href="../index.php" target="_blank">
                <i class="bi bi-eye me-2"></i> مشاهده سایت
            </a>
            <a class="nav-link" href="../dashboard.php">
                <i class="bi bi-person me-2"></i> داشبورد شخصی
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> خروج
            </a>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-admin px-4">
            <div class="d-flex align-items-center">
                <div class="hamburger me-3" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <h5 class="mb-0">
                    <?php
                    $pageTitle = [
                        'dashboard' => 'داشبورد',
                        'posts' => 'مدیریت مطالب',
                        'pages' => 'مدیریت صفحات',
                        'users' => 'مدیریت کاربران',
                        'categories' => 'مدیریت دسته‌بندی‌ها',
                        'modules' => 'مدیریت ماژول‌ها',
                        'comments' => 'مدیریت نظرات',
                        'media' => 'مدیریت رسانه',
                        'settings' => 'تنظیمات سیستم'
                    ];
                    echo $pageTitle[$currentPage] ?? 'پنل مدیریت';
                    ?>
                </h5>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><?php echo date('Y/m/d H:i') ?></span>
                <a href="../index.php" class="btn btn-outline-primary btn-sm" target="_blank">
                    <i class="bi bi-eye"></i> مشاهده سایت
                </a>
            </div>
        </nav>
        
        <!-- Page Content -->
        <div class="p-4">
            <?php
            // بارگذاری محتوای صفحه
            $pageFile = 'pages/' . $currentPage . '.php';
            if (file_exists($pageFile) && in_array($currentPage, array_keys($allowedPages))) {
                include $pageFile;
            } else {
                echo '<div class="alert alert-warning">صفحه مورد نظر یافت نشد.</div>';
            }
            ?>
        </div>
    </div>
    
    <script src="../scripts/bootstrap.bundle.min.js"></script>
    <script>
        // Responsive Sidebar
        const hamburger = document.getElementById('hamburger');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const closeSidebar = document.getElementById('closeSidebar');
        
        function toggleSidebar() {
            sidebar.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');
        }
        
        hamburger.addEventListener('click', toggleSidebar);
        closeSidebar.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);
        
        // Close sidebar on window resize if mobile
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('show');
            }
        });
        
        // CSRF Token for AJAX requests
        function getCSRFToken() {
            return document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        }
        
        // Add CSRF token to all forms
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                if (!form.querySelector('input[name="csrf_token"]')) {
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = 'csrf_token';
                    csrfInput.value = getCSRFToken();
                    form.appendChild(csrfInput);
                }
            });
        });
    </script>
</body>
</html>
