<?php
require_once '../config/connection.php';

// بررسی دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    http_response_code(401);
    echo json_encode(['error' => 'دسترسی غیرمجاز']);
    exit;
}

// بررسی Rate Limiting
checkRateLimit('upload', 10, 60); // 10 آپلود در دقیقه

// بررسی CSRF Token
if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    logSecurityEvent('upload_csrf_invalid', ['ip' => $_SERVER['REMOTE_ADDR']]);
    http_response_code(403);
    echo json_encode(['error' => 'توکن امنیتی نامعتبر است']);
    exit;
}

// بررسی فایل آپلود شده
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    logSecurityEvent('upload_no_file');
    http_response_code(400);
    echo json_encode(['error' => 'فایل آپلود نشده است']);
    exit;
}

$file = $_FILES['file'];

// اعتبارسنجی فایل
$validation = validateUploadedFile($file);
if (!$validation['success']) {
    logSecurityEvent('upload_validation_failed', ['error' => $validation['message']]);
    http_response_code(400);
    echo json_encode(['error' => $validation['message']]);
    exit;
}

try {
    // تعیین نوع فایل
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'text/plain' => 'txt',
        'application/zip' => 'zip'
    ];
    
    if (!array_key_exists($mimeType, $allowedMimeTypes)) {
        logSecurityEvent('upload_invalid_mime', ['mime' => $mimeType]);
        http_response_code(400);
        echo json_encode(['error' => 'نوع فایل مجاز نیست']);
        exit;
    }
    
    $extension = $allowedMimeTypes[$mimeType];
    
    // تولید نام فایل امن
    $secureFilename = generateSecureFilename($file['name'], $extension);
    
    // تعیین مسیر آپلود
    $uploadDir = 'uploads/' . date('Y/m/');
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            logSecurityEvent('upload_directory_creation_failed', ['path' => $uploadDir]);
            http_response_code(500);
            echo json_encode(['error' => 'خطا در ایجاد پوشه آپلود']);
            exit;
        }
    }
    
    $filepath = $uploadDir . $secureFilename;
    
    // بررسی مسیر فایل برای جلوگیری از Path Traversal
    if (!validateFilePath($filepath)) {
        logSecurityEvent('upload_path_traversal_attempt', ['path' => $filepath]);
        http_response_code(400);
        echo json_encode(['error' => 'مسیر فایل نامعتبر است']);
        exit;
    }
    
    // آپلود فایل
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        logSecurityEvent('upload_move_failed', ['path' => $filepath]);
        http_response_code(500);
        echo json_encode(['error' => 'خطا در آپلود فایل']);
        exit;
    }
    
    // تنظیم مجوزهای فایل
    chmod($filepath, 0644);
    
    // بررسی محتوای فایل برای تصاویر
    if (strpos($mimeType, 'image/') === 0) {
        $imageInfo = getimagesize($filepath);
        if ($imageInfo === false) {
            // حذف فایل نامعتبر
            unlink($filepath);
            logSecurityEvent('upload_invalid_image', ['path' => $filepath]);
            http_response_code(400);
            echo json_encode(['error' => 'فایل تصویر نامعتبر است']);
            exit;
        }
        
        // محدودیت ابعاد تصویر
        if ($imageInfo[0] > 4000 || $imageInfo[1] > 4000) {
            unlink($filepath);
            logSecurityEvent('upload_image_too_large', ['dimensions' => $imageInfo[0] . 'x' . $imageInfo[1]]);
            http_response_code(400);
            echo json_encode(['error' => 'ابعاد تصویر بیش از حد مجاز است']);
            exit;
        }
    }
    
    // ذخیره در پایگاه داده
    $pdo = getDatabase();
    $stmt = $pdo->prepare("
        INSERT INTO uploads (filename, original_name, file_path, file_size, mime_type, uploaded_by, uploaded_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $secureFilename,
        $file['name'],
        $filepath,
        $file['size'],
        $mimeType,
        $_SESSION['user_id']
    ]);
    
    $uploadId = $pdo->lastInsertId();
    
    // لاگ موفقیت‌آمیز
    logSecurityEvent('upload_successful', [
        'filename' => $secureFilename,
        'size' => $file['size'],
        'mime' => $mimeType,
        'user_id' => $_SESSION['user_id']
    ]);
    
    // پاسخ موفقیت‌آمیز
    echo json_encode([
        'success' => true,
        'file' => [
            'id' => $uploadId,
            'name' => $secureFilename,
            'original_name' => $file['name'],
            'path' => $filepath,
            'size' => $file['size'],
            'mime_type' => $mimeType,
            'url' => $filepath
        ]
    ]);
    
} catch (Exception $e) {
    logSecurityEvent('upload_exception', ['error' => $e->getMessage()]);
    error_log('Upload error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'خطا در آپلود فایل']);
}
?>
