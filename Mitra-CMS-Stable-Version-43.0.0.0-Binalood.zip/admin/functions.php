<?php
require_once '../lib/jdf.php';
// Helper function to format date
function formatPersianDate($date) {
    $timestamp = strtotime($date);
    return jdate('Y/m/d H:i', $timestamp);
}
// تابع تبدیل اندازه به کلاس Bootstrap
function getBootstrapClass($size, $smsize, $mdsize, $lgsize, $unit = '%') {
    // تبدیل درصد به ستون (مثلاً 25% ≈ col-md-3)
    $toCol = function($percent) {
        $cols = (int)(($percent / 100) * 12);
        return max(1, min(12, $cols)); // بین 1 تا 12
    };

    $smCol = $toCol($smsize);
    $mdCol = $toCol($mdsize);
    $lgCol = $toCol($lgsize);
    $defaultCol = $toCol($size);

    return "col-{$smCol} col-md-{$mdCol} col-lg-{$lgCol} col-{$defaultCol}";
}
