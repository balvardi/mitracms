<?php
// بررسی ورود کاربر
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth.php');
    exit;
}

$message = '';
$error = '';

// پردازش عملیات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $comment_id = (int)($_POST['comment_id'] ?? 0);
    
    try {
        switch ($action) {
            case 'approve':
                $stmt = $pdo->prepare("UPDATE comments SET status = 'approved' WHERE id = ?");
                $stmt->execute([$comment_id]);
                $message = "نظر تأیید شد.";
                break;
                
            case 'reject':
                $stmt = $pdo->prepare("UPDATE comments SET status = 'rejected' WHERE id = ?");
                $stmt->execute([$comment_id]);
                $message = "نظر رد شد.";
                break;
                
            case 'spam':
                $stmt = $pdo->prepare("UPDATE comments SET status = 'spam' WHERE id = ?");
                $stmt->execute([$comment_id]);
                $message = "نظر به عنوان اسپم علامت‌گذاری شد.";
                break;
                
            case 'delete':
                $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
                $stmt->execute([$comment_id]);
                $message = "نظر حذف شد.";
                break;
                
            case 'reply':
                $reply_content = trim($_POST['reply_content'] ?? '');
                if ($reply_content) {
                    $stmt = $pdo->prepare("
                        INSERT INTO comments (post_id, parent_id, author_name, author_email, content, status, created_at) 
                        SELECT post_id, id, ?, ?, ?, 'approved', NOW() 
                        FROM comments WHERE id = ?
                    ");
                    $stmt->execute([
                        $_SESSION['first_name'] . ' ' . $_SESSION['last_name'],
                        $_SESSION['email'],
                        $reply_content,
                        $comment_id
                    ]);
                    $message = "پاسخ شما ثبت شد.";
                }
                break;
                
            case 'bulk':
                $selected_comments = $_POST['selected_comments'] ?? [];
                $bulk_action = $_POST['bulk_action'] ?? '';
                
                if (!empty($selected_comments) && $bulk_action) {
                    $placeholders = str_repeat('?,', count($selected_comments) - 1) . '?';
                    
                    switch ($bulk_action) {
                        case 'approve':
                            $stmt = $pdo->prepare("UPDATE comments SET status = 'approved' WHERE id IN ($placeholders)");
                            $stmt->execute($selected_comments);
                            $message = count($selected_comments) . " نظر تأیید شد.";
                            break;
                            
                        case 'reject':
                            $stmt = $pdo->prepare("UPDATE comments SET status = 'rejected' WHERE id IN ($placeholders)");
                            $stmt->execute($selected_comments);
                            $message = count($selected_comments) . " نظر رد شد.";
                            break;
                            
                        case 'spam':
                            $stmt = $pdo->prepare("UPDATE comments SET status = 'spam' WHERE id IN ($placeholders)");
                            $stmt->execute($selected_comments);
                            $message = count($selected_comments) . " نظر به عنوان اسپم علامت‌گذاری شد.";
                            break;
                            
                        case 'delete':
                            $stmt = $pdo->prepare("DELETE FROM comments WHERE id IN ($placeholders)");
                            $stmt->execute($selected_comments);
                            $message = count($selected_comments) . " نظر حذف شد.";
                            break;
                    }
                }
                break;
        }
    } catch (PDOException $e) {
        $error = "خطا در انجام عملیات: " . $e->getMessage();
    }
}

// دریافت نظرات با فیلتر و جستجو
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(c.author_name LIKE ? OR c.author_email LIKE ? OR c.content LIKE ? OR p.title LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($status_filter) {
    $where_conditions[] = "c.status = ?";
    $params[] = $status_filter;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// شمارش کل نظرات
$count_sql = "
    SELECT COUNT(*) 
    FROM comments c 
    LEFT JOIN posts p ON c.post_id = p.id 
    {$where_clause}
";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_comments = $stmt->fetchColumn();
$total_pages = ceil($total_comments / $per_page);

// دریافت نظرات
$sql = "
    SELECT c.*, p.title as post_title, p.slug as post_slug,
           parent.author_name as parent_author
    FROM comments c
    LEFT JOIN posts p ON c.post_id = p.id
    LEFT JOIN comments parent ON c.parent_id = parent.id
    {$where_clause}
    ORDER BY c.created_at DESC
    LIMIT {$per_page} OFFSET {$offset}
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$comments = $stmt->fetchAll();

// دریافت آمار
$stats_sql = "
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status = 'spam' THEN 1 ELSE 0 END) as spam
    FROM comments
";
$stmt = $pdo->query($stats_sql);
$stats = $stmt->fetch();

// تابع فرمت تاریخ
function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'همین الان';
    if ($time < 3600) return floor($time/60) . ' دقیقه پیش';
    if ($time < 86400) return floor($time/3600) . ' ساعت پیش';
    if ($time < 2592000) return floor($time/86400) . ' روز پیش';
    if ($time < 31536000) return floor($time/2592000) . ' ماه پیش';
    return floor($time/31536000) . ' سال پیش';
}
?>

<!-- نمایش پیام‌ها -->
<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- آمار کلی -->
<div class="row mb-4">
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-primary"><?php echo number_format((int)$stats['total']) ?></div>
            <div class="stats-label">کل نظرات</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-success"><?php echo number_format((int)$stats['approved']) ?></div>
            <div class="stats-label">تأیید شده</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-warning"><?php echo number_format((int)$stats['pending']) ?></div>
            <div class="stats-label">در انتظار</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-danger"><?php echo number_format((int)$stats['rejected']) ?></div>
            <div class="stats-label">رد شده</div>
        </div>
    </div>
    <div class="col-md-2 mb-3">
        <div class="stats-card">
            <div class="stats-number text-dark"><?php echo number_format((int)$stats['spam']) ?></div>
            <div class="stats-label">اسپم</div>
        </div>
    </div>
</div>

<!-- فیلتر و جستجو -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <input type="hidden" name="page" value="comments">
            <div class="col-md-5">
                <label for="search" class="form-label">جستجو</label>
                <input type="text" class="form-control" id="search" name="search" 
                       value="<?php echo htmlspecialchars($search) ?>" 
                       placeholder="نام، ایمیل، محتوا یا عنوان مطلب...">
            </div>
            <div class="col-md-3">
                <label for="status" class="form-label">وضعیت</label>
                <select class="form-select" id="status" name="status">
                    <option value="">همه وضعیت‌ها</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : '' ?>>در انتظار</option>
                    <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : '' ?>>تأیید شده</option>
                    <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : '' ?>>رد شده</option>
                    <option value="spam" <?php echo $status_filter === 'spam' ? 'selected' : '' ?>>اسپم</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> جستجو
                    </button>
                </div>
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <div>
                    <a href="?page=comments" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise"></i> پاک کردن
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- عملیات گروهی -->
<form method="POST" id="bulkForm">
    <input type="hidden" name="action" value="bulk">
    
    <div class="card mb-4">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <select name="bulk_action" class="form-select">
                        <option value="">انتخاب عملیات...</option>
                        <option value="approve">تأیید</option>
                        <option value="reject">رد</option>
                        <option value="spam">علامت‌گذاری به عنوان اسپم</option>
                        <option value="delete">حذف</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-warning" onclick="return confirm('آیا از انجام این عملیات اطمینان دارید؟')">
                        <i class="bi bi-gear"></i> اعمال عملیات
                    </button>
                </div>
                <div class="col-md-6 text-end">
                    <button type="button" class="btn btn-outline-primary btn-sm" onclick="selectAll()">
                        انتخاب همه
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" onclick="deselectAll()">
                        لغو انتخاب
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- لیست نظرات -->
    <div class="row">
        <?php if (empty($comments)): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="bi bi-chat-dots display-1 text-muted"></i>
                    <h4 class="mt-3">هیچ نظری یافت نشد</h4>
                    <p class="text-muted">نظری با این فیلترها وجود ندارد.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($comments as $comment): ?>
                <div class="col-12 mb-3">
                    <div class="card comment-card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-1">
                                    <input type="checkbox" name="selected_comments[]" 
                                           value="<?php echo $comment['id'] ?>" class="form-check-input">
                                </div>
                                <div class="col-md-11">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <div>
                                            <h6 class="mb-1">
                                                <i class="bi bi-person-circle"></i>
                                                <?php echo htmlspecialchars($comment['author_name']) ?>
                                                <small class="text-muted">
                                                    (<?php echo htmlspecialchars($comment['author_email']) ?>)
                                                </small>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="bi bi-clock"></i> <?php echo timeAgo($comment['created_at']) ?>
                                                | 
                                                <i class="bi bi-file-text"></i>
                                                <a href="../post.php?slug=<?php echo htmlspecialchars($comment['post_slug']) ?>" 
                                                   target="_blank" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($comment['post_title']) ?>
                                                </a>
                                                <?php if ($comment['parent_id']): ?>
                                                    | <i class="bi bi-reply"></i> پاسخ به <?php echo htmlspecialchars($comment['parent_author']) ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                        <div>
                                            <span class="badge bg-<?php
                                                echo match($comment['status']) {
                                                    'approved' => 'success',
                                                    'pending' => 'warning',
                                                    'rejected' => 'danger',
                                                    'spam' => 'dark',
                                                    default => 'secondary'
                                                };
                                            ?>">
                                                <?php
                                                echo match($comment['status']) {
                                                    'approved' => 'تأیید شده',
                                                    'pending' => 'در انتظار',
                                                    'rejected' => 'رد شده',
                                                    'spam' => 'اسپم',
                                                    default => 'نامشخص'
                                                };
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="comment-content mb-3">
                                        <p><?php echo nl2br(htmlspecialchars($comment['content'])) ?></p>
                                    </div>
                                    
                                    <div class="comment-actions">
                                        <div class="btn-group" role="group">
                                            <?php if ($comment['status'] !== 'approved'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="approve">
                                                    <input type="hidden" name="comment_id" value="<?php echo $comment['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-success">
                                                        <i class="bi bi-check-circle"></i> تأیید
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <?php if ($comment['status'] !== 'rejected'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="reject">
                                                    <input type="hidden" name="comment_id" value="<?php echo $comment['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-warning">
                                                        <i class="bi bi-x-circle"></i> رد
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="action" value="spam">
                                                <input type="hidden" name="comment_id" value="<?php echo $comment['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-dark">
                                                    <i class="bi bi-shield-exclamation"></i> اسپم
                                                </button>
                                            </form>
                                            
                                            <button type="button" class="btn btn-sm btn-info" 
                                                    onclick="toggleReplyForm(<?php echo $comment['id'] ?>)">
                                                <i class="bi bi-reply"></i> پاسخ
                                            </button>
                                            
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="comment_id" value="<?php echo $comment['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('آیا از حذف این نظر اطمینان دارید؟')">
                                                    <i class="bi bi-trash"></i> حذف
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <!-- فرم پاسخ -->
                                    <div id="replyForm<?php echo $comment['id'] ?>" class="reply-form mt-3" style="display: none;">
                                        <form method="POST">
                                            <input type="hidden" name="action" value="reply">
                                            <input type="hidden" name="comment_id" value="<?php echo $comment['id'] ?>">
                                            <div class="mb-3">
                                                <label class="form-label">پاسخ شما:</label>
                                                <textarea name="reply_content" class="form-control" rows="3" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-primary btn-sm">
                                                <i class="bi bi-send"></i> ارسال پاسخ
                                            </button>
                                            <button type="button" class="btn btn-secondary btn-sm" 
                                                    onclick="toggleReplyForm(<?php echo $comment['id'] ?>)">
                                                انصراف
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</form>

<!-- صفحه‌بندی -->
<?php if ($total_pages > 1): ?>
    <nav aria-label="صفحه‌بندی نظرات">
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=comments&search=<?php echo urlencode($search) ?>&status=<?php echo urlencode($status_filter) ?>&page=<?php echo $page - 1 ?>">قبلی</a>
                </li>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                <li class="page-item <?php echo $i === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=comments&search=<?php echo urlencode($search) ?>&status=<?php echo urlencode($status_filter) ?>&page=<?php echo $i ?>"><?php echo $i ?></a>
                </li>
            <?php endfor; ?>
            
            <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=comments&search=<?php echo urlencode($search) ?>&status=<?php echo urlencode($status_filter) ?>&page=<?php echo $page + 1 ?>">بعدی</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<style>
.stats-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: transform 0.3s;
    text-align: center;
}

.stats-card:hover {
    transform: translateY(-3px);
}

.stats-number {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
}

.stats-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.comment-card {
    transition: transform 0.2s;
}

.comment-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.comment-content {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 8px;
    border-left: 4px solid #007bff;
}

.comment-actions .btn {
    margin-left: 5px;
}

.reply-form {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 8px;
    border: 1px solid #dee2e6;
}
</style>

<script>
function selectAll() {
    const checkboxes = document.querySelectorAll('input[name="selected_comments[]"]');
    checkboxes.forEach(checkbox => checkbox.checked = true);
}

function deselectAll() {
    const checkboxes = document.querySelectorAll('input[name="selected_comments[]"]');
    checkboxes.forEach(checkbox => checkbox.checked = false);
}

function toggleReplyForm(commentId) {
    const form = document.getElementById('replyForm' + commentId);
    if (form.style.display === 'none') {
        form.style.display = 'block';
    } else {
        form.style.display = 'none';
    }
}

// تأیید عملیات گروهی
document.getElementById('bulkForm').addEventListener('submit', function(e) {
    const selectedComments = document.querySelectorAll('input[name="selected_comments[]"]:checked');
    const bulkAction = document.querySelector('select[name="bulk_action"]').value;
    
    if (selectedComments.length === 0) {
        e.preventDefault();
        alert('لطفاً حداقل یک نظر را انتخاب کنید.');
        return;
    }
    
    if (!bulkAction) {
        e.preventDefault();
        alert('لطفاً عملیات مورد نظر را انتخاب کنید.');
        return;
    }
    
    if (!confirm(`آیا از انجام این عملیات روی ${selectedComments.length} نظر اطمینان دارید؟`)) {
        e.preventDefault();
    }
});
</script>
