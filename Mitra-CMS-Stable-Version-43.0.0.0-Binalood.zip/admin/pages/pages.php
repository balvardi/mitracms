<?php
// مدیریت صفحات
$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

// پردازش فرم‌ها
if ($_POST) {
    if ($action === 'add' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $excerpt = trim($_POST['excerpt'] ?? '');
        $status = $_POST['status'] ?? 'draft';
        $template = $_POST['template'] ?? 'default';
        $meta_title = trim($_POST['meta_title'] ?? '');
        $meta_description = trim($_POST['meta_description'] ?? '');
        $meta_keywords = trim($_POST['meta_keywords'] ?? '');
        
        if (empty($title) || empty($slug)) {
            $error = 'عنوان و نامک الزامی هستند';
        } else {
            try {
                if ($action === 'add') {
                    // بررسی تکراری نبودن slug
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM pages WHERE slug = ?");
                    $stmt->execute([$slug]);
                    
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'این نامک قبلاً استفاده شده است';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO pages (title, slug, content, excerpt, status, template, meta_title, meta_description, meta_keywords, author_id) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        if ($stmt->execute([$title, $slug, $content, $excerpt, $status, $template, $meta_title, $meta_description, $meta_keywords, $_SESSION['user_id']])) {
                            $message = 'صفحه با موفقیت ایجاد شد';
                            $action = 'list';
                        } else {
                            $error = 'خطا در ایجاد صفحه';
                        }
                    }
                } elseif ($action === 'edit') {
                    $id = $_POST['id'] ?? 0;
                    $stmt = $pdo->prepare("
                        UPDATE pages 
                        SET title = ?, slug = ?, content = ?, excerpt = ?, status = ?, template = ?, meta_title = ?, meta_description = ?, meta_keywords = ? 
                        WHERE id = ?
                    ");
                    if ($stmt->execute([$title, $slug, $content, $excerpt, $status, $template, $meta_title, $meta_description, $meta_keywords, $id])) {
                        $message = 'صفحه با موفقیت به‌روزرسانی شد';
                        $action = 'list';
                    } else {
                        $error = 'خطا در به‌روزرسانی صفحه';
                    }
                }
            } catch (PDOException $e) {
                $error = 'خطا: ' . $e->getMessage();
            }
        }
    }
}

// حذف صفحه
if ($action === 'delete' && isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM pages WHERE id = ?");
        if ($stmt->execute([$_GET['id']])) {
            $message = 'صفحه با موفقیت حذف شد';
        } else {
            $error = 'خطا در حذف صفحه';
        }
        $action = 'list';
    } catch (PDOException $e) {
        $error = 'خطا: ' . $e->getMessage();
    }
}

// دریافت صفحات
$pages = [];
if ($action === 'list') {
    try {
        $stmt = $pdo->query("
            SELECT p.*, u.username 
            FROM pages p 
            LEFT JOIN users u ON p.author_id = u.id 
            ORDER BY p.created_at DESC
        ");
        $pages = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = 'خطا در دریافت صفحات: ' . $e->getMessage();
    }
}

// دریافت صفحه برای ویرایش
$editPage = null;
if ($action === 'edit' && isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM pages WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $editPage = $stmt->fetch();
        
        if (!$editPage) {
            $error = 'صفحه یافت نشد';
            $action = 'list';
        }
    } catch (PDOException $e) {
        $error = 'خطا: ' . $e->getMessage();
        $action = 'list';
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>مدیریت صفحات</h2>
    <?php if ($action === 'list'): ?>
        <a href="?page=pages&action=add" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> افزودن صفحه جدید
        </a>
    <?php else: ?>
        <a href="?page=pages" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت به لیست
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'list'): ?>
    <!-- لیست صفحات -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($pages)): ?>
                <div class="alert alert-info text-center">
                    <i class="bi bi-info-circle display-6 d-block mb-3"></i>
                    <h5>هنوز صفحه‌ای ایجاد نشده است</h5>
                    <p>برای شروع، اولین صفحه خود را ایجاد کنید.</p>
                    <a href="?page=pages&action=add" class="btn btn-primary">ایجاد صفحه جدید</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>عنوان</th>
                                <th>نامک</th>
                                <th>وضعیت</th>
                                <th>نویسنده</th>
                                <th>تاریخ ایجاد</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pages as $page): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($page['title']) ?></strong>
                                        <?php if ($page['excerpt']): ?>
                                            <br><small class="text-muted"><?php echo htmlspecialchars(substr($page['excerpt'], 0, 100)) ?>...</small>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?php echo htmlspecialchars($page['slug']) ?></code></td>
                                    <td>
                                        <span class="badge bg-<?php echo $page['status'] === 'published' ? 'success' : ($page['status'] === 'draft' ? 'warning' : 'secondary') ?>">
                                            <?php echo $page['status'] === 'published' ? 'منتشر شده' : ($page['status'] === 'draft' ? 'پیش‌نویس' : 'خصوصی') ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($page['username'] ?? 'نامشخص') ?></td>
                                    <td><?php echo date('Y/m/d H:i', strtotime($page['created_at'])) ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="../page.php?slug=<?php echo urlencode($page['slug']) ?>" class="btn btn-outline-info" target="_blank" title="مشاهده">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="?page=pages&action=edit&id=<?php echo $page['id'] ?>" class="btn btn-outline-primary" title="ویرایش">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="?page=pages&action=delete&id=<?php echo $page['id'] ?>" class="btn btn-outline-danger" title="حذف"
                                               onclick="return confirm('آیا از حذف این صفحه مطمئن هستید؟')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php elseif ($action === 'add' || $action === 'edit'): ?>
    <!-- فرم افزودن/ویرایش صفحه -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-<?php echo $action === 'add' ? 'plus-circle' : 'pencil' ?>"></i>
                <?php echo $action === 'add' ? 'افزودن صفحه جدید' : 'ویرایش صفحه' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="post">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?php echo $editPage['id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label">عنوان صفحه <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="title" 
                                   value="<?php echo htmlspecialchars($editPage['title'] ?? '') ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نامک (URL) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="slug" 
                                   value="<?php echo htmlspecialchars($editPage['slug'] ?? '') ?>" required>
                            <div class="form-text">فقط حروف انگلیسی، اعداد و خط تیره استفاده کنید</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">خلاصه</label>
                            <textarea class="form-control" name="excerpt" rows="3"><?php echo htmlspecialchars($editPage['excerpt'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">محتوای صفحه</label>
                            <textarea class="form-control" name="content" rows="15"><?php echo htmlspecialchars($editPage['content'] ?? '') ?></textarea>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">وضعیت</label>
                            <select class="form-select" name="status">
                                <option value="draft" <?php echo ($editPage['status'] ?? '') === 'draft' ? 'selected' : '' ?>>
                                    پیش‌نویس
                                </option>
                                <option value="published" <?php echo ($editPage['status'] ?? '') === 'published' ? 'selected' : '' ?>>
                                    منتشر شده
                                </option>
                                <option value="private" <?php echo ($editPage['status'] ?? '') === 'private' ? 'selected' : '' ?>>
                                    خصوصی
                                </option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">قالب</label>
                            <select class="form-select" name="template">
                                <option value="default" <?php echo ($editPage['template'] ?? '') === 'default' ? 'selected' : '' ?>>
                                    پیش‌فرض
                                </option>
                                <option value="home" <?php echo ($editPage['template'] ?? '') === 'home' ? 'selected' : '' ?>>
                                    صفحه اصلی
                                </option>
                                <option value="contact" <?php echo ($editPage['template'] ?? '') === 'contact' ? 'selected' : '' ?>>
                                    تماس با ما
                                </option>
                            </select>
                        </div>
                        
                        <hr>
                        <h6>تنظیمات SEO</h6>
                        
                        <div class="mb-3">
                            <label class="form-label">عنوان متا</label>
                            <input type="text" class="form-control" name="meta_title" 
                                   value="<?php echo htmlspecialchars($editPage['meta_title'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">توضیحات متا</label>
                            <textarea class="form-control" name="meta_description" rows="3"><?php echo htmlspecialchars($editPage['meta_description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">کلمات کلیدی</label>
                            <input type="text" class="form-control" name="meta_keywords" 
                                   value="<?php echo htmlspecialchars($editPage['meta_keywords'] ?? '') ?>">
                            <div class="form-text">کلمات را با کاما جدا کنید</div>
                        </div>
                    </div>
                </div>
                
                <hr>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i>
                        <?php echo $action === 'add' ? 'ایجاد صفحه' : 'به‌روزرسانی صفحه' ?>
                    </button>
                    <a href="?page=pages" class="btn btn-secondary">
                        <i class="bi bi-x-circle"></i> انصراف
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
