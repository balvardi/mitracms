<?php
require_once '../config/connection.php';

// بررسی دسترسی ادمین
if (!checkPermission('admin')) {
    header('Location: ../auth.php');
    exit;
}

// بارگذاری تنظیمات ویجت‌ها
$widgetSettings = require '../config/widget-settings.php';

$message = '';
$error = '';

// پردازش فرم‌ها
if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'توکن امنیتی نامعتبر است';
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'update_widget_settings':
                try {
                    $widgetType = sanitizeInput($_POST['widget_type']);
                    $settings = json_decode($_POST['settings'], true);
                    
                    if ($settings) {
                        // بروزرسانی تنظیمات در دیتابیس
                        $stmt = $pdo->prepare("
                            INSERT INTO settings (setting_key, setting_value) 
                            VALUES (?, ?) 
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                        ");
                        
                        $settingKey = $widgetType . '_widget';
                        $settingValue = json_encode($settings);
                        
                        $stmt->execute([$settingKey, $settingValue]);
                        
                        logSecurityEvent('widget_settings_updated', [
                            'widget_type' => $widgetType,
                            'user_id' => $_SESSION['user_id']
                        ]);
                        
                        $message = 'تنظیمات ویجت با موفقیت بروزرسانی شد';
                    }
                } catch (Exception $e) {
                    $error = 'خطا در بروزرسانی تنظیمات: ' . $e->getMessage();
                }
                break;
                
            case 'toggle_widget':
                try {
                    $widgetType = sanitizeInput($_POST['widget_type']);
                    $enabled = (int)$_POST['enabled'];
                    
                    // بروزرسانی وضعیت ویجت
                    $stmt = $pdo->prepare("
                        INSERT INTO settings (setting_key, setting_value) 
                        VALUES (?, ?) 
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                    ");
                    
                    $settingKey = $widgetType . '_widget';
                    $currentSettings = $widgetSettings[$settingKey] ?? [];
                    $currentSettings['enabled'] = (bool)$enabled;
                    $settingValue = json_encode($currentSettings);
                    
                    $stmt->execute([$settingKey, $settingValue]);
                    
                    $message = 'وضعیت ویجت بروزرسانی شد';
                } catch (Exception $e) {
                    $error = 'خطا در تغییر وضعیت ویجت: ' . $e->getMessage();
                }
                break;
        }
    }
}

// دریافت تنظیمات فعلی از دیتابیس
try {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE '%_widget'");
    $stmt->execute();
    $currentSettings = [];
    while ($row = $stmt->fetch()) {
        $currentSettings[$row['setting_key']] = json_decode($row['setting_value'], true);
    }
} catch (Exception $e) {
    $currentSettings = [];
}

// تولید توکن CSRF
$csrfToken = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت ویجت‌ها - پنل ادمین</title>
    <link href="../styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="../styles/bootstrap-icons.css" rel="stylesheet">
    <style>
        .widget-card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        
        .widget-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.12);
        }
        
        .widget-preview {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 15px 0;
            border: 2px dashed #dee2e6;
        }
        
        .settings-form {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 10px 25px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .widget-status {
            position: absolute;
            top: 15px;
            right: 15px;
        }
        
        .widget-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="bi bi-grid-3x3-gap"></i>
                        مدیریت ویجت‌ها
                    </h1>
                </div>
                
                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i>
                        <?php echo htmlspecialchars($message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle"></i>
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- ویجت‌های موجود -->
                <div class="row g-4">
                    <!-- Hero Widget -->
                    <div class="col-lg-6">
                        <div class="widget-card card h-100 position-relative">
                            <div class="card-body">
                                <div class="widget-status">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" 
                                               id="hero_enabled" 
                                               <?php echo ($currentSettings['hero_widget']['enabled'] ?? true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="hero_enabled">فعال</label>
                                    </div>
                                </div>
                                
                                <div class="widget-icon bg-primary">
                                    <i class="bi bi-stars"></i>
                                </div>
                                
                                <h5 class="card-title">ویجت Hero</h5>
                                <p class="card-text">بخش اصلی صفحه که شامل عنوان، توضیحات و دکمه‌های عملیاتی است.</p>
                                
                                <div class="widget-preview">
                                    <h6>پیش‌نمایش:</h6>
                                    <div class="text-center">
                                        <h4>عنوان Hero</h4>
                                        <p class="text-muted">توضیحات کوتاه</p>
                                        <div class="d-flex gap-2 justify-content-center">
                                            <button class="btn btn-primary btn-sm">دکمه 1</button>
                                            <button class="btn btn-outline-primary btn-sm">دکمه 2</button>
                                        </div>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-sm" onclick="editWidget('hero')">
                                    <i class="bi bi-gear"></i>
                                    تنظیمات
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Comments Widget -->
                    <div class="col-lg-6">
                        <div class="widget-card card h-100 position-relative">
                            <div class="card-body">
                                <div class="widget-status">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" 
                                               id="comments_enabled" 
                                               <?php echo ($currentSettings['comments_widget']['enabled'] ?? true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="comments_enabled">فعال</label>
                                    </div>
                                </div>
                                
                                <div class="widget-icon bg-success">
                                    <i class="bi bi-chat-dots"></i>
                                </div>
                                
                                <h5 class="card-title">ویجت نظرات</h5>
                                <p class="card-text">نمایش آخرین نظرات کاربران با امکان مدیریت و تایید.</p>
                                
                                <div class="widget-preview">
                                    <h6>پیش‌نمایش:</h6>
                                    <div class="border rounded p-2">
                                        <small class="text-muted">کاربر: نظر کاربر...</small>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-sm" onclick="editWidget('comments')">
                                    <i class="bi bi-gear"></i>
                                    تنظیمات
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- CTA Widget -->
                    <div class="col-lg-6">
                        <div class="widget-card card h-100 position-relative">
                            <div class="card-body">
                                <div class="widget-status">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" 
                                               id="cta_enabled" 
                                               <?php echo ($currentSettings['cta_widget']['enabled'] ?? true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="cta_enabled">فعال</label>
                                    </div>
                                </div>
                                
                                <div class="widget-icon bg-warning">
                                    <i class="bi bi-megaphone"></i>
                                </div>
                                
                                <h5 class="card-title">ویجت CTA</h5>
                                <p class="card-text">بخش دعوت به عمل برای هدایت کاربران به صفحات مهم.</p>
                                
                                <div class="widget-preview">
                                    <h6>پیش‌نمایش:</h6>
                                    <div class="bg-primary text-white p-3 rounded text-center">
                                        <h6>آماده شروع هستید؟</h6>
                                        <button class="btn btn-light btn-sm">تماس با ما</button>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-sm" onclick="editWidget('cta')">
                                    <i class="bi bi-gear"></i>
                                    تنظیمات
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Featured Widget -->
                    <div class="col-lg-6">
                        <div class="widget-card card h-100 position-relative">
                            <div class="card-body">
                                <div class="widget-status">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" 
                                               id="featured_enabled" 
                                               <?php echo ($currentSettings['featured_widget']['enabled'] ?? true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="featured_enabled">فعال</label>
                                    </div>
                                </div>
                                
                                <div class="widget-icon bg-info">
                                    <i class="bi bi-star"></i>
                                </div>
                                
                                <h5 class="card-title">ویجت ویژگی‌ها</h5>
                                <p class="card-text">نمایش ویژگی‌های کلیدی سیستم با آیکون‌ها و توضیحات.</p>
                                
                                <div class="widget-preview">
                                    <h6>پیش‌نمایش:</h6>
                                    <div class="row g-2">
                                        <div class="col-4 text-center">
                                            <i class="bi bi-speedometer2 text-primary"></i>
                                            <small>سرعت</small>
                                        </div>
                                        <div class="col-4 text-center">
                                            <i class="bi bi-shield-check text-success"></i>
                                            <small>امنیت</small>
                                        </div>
                                        <div class="col-4 text-center">
                                            <i class="bi bi-phone text-info"></i>
                                            <small>ریسپانسیو</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-sm" onclick="editWidget('featured')">
                                    <i class="bi bi-gear"></i>
                                    تنظیمات
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Latest Widget -->
                    <div class="col-lg-6">
                        <div class="widget-card card h-100 position-relative">
                            <div class="card-body">
                                <div class="widget-status">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" 
                                               id="latest_enabled" 
                                               <?php echo ($currentSettings['latest_widget']['enabled'] ?? true) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="latest_enabled">فعال</label>
                                    </div>
                                </div>
                                
                                <div class="widget-icon bg-secondary">
                                    <i class="bi bi-newspaper"></i>
                                </div>
                                
                                <h5 class="card-title">ویجت آخرین مطالب</h5>
                                <p class="card-text">نمایش آخرین مقالات و مطالب منتشر شده در سایت.</p>
                                
                                <div class="widget-preview">
                                    <h6>پیش‌نمایش:</h6>
                                    <div class="border rounded p-2">
                                        <h6 class="mb-1">عنوان مقاله</h6>
                                        <small class="text-muted">تاریخ انتشار</small>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-sm" onclick="editWidget('latest')">
                                    <i class="bi bi-gear"></i>
                                    تنظیمات
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Modal تنظیمات ویجت -->
                <div class="modal fade" id="widgetSettingsModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">تنظیمات ویجت</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form id="widgetSettingsForm" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                    <input type="hidden" name="action" value="update_widget_settings">
                                    <input type="hidden" name="widget_type" id="widgetType">
                                    <input type="hidden" name="settings" id="widgetSettings">
                                    
                                    <div id="widgetSettingsContent">
                                        <!-- محتوای تنظیمات اینجا لود می‌شود -->
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                                <button type="submit" form="widgetSettingsForm" class="btn btn-primary">ذخیره تنظیمات</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="../scripts/bootstrap.bundle.min.js"></script>
    <script>
        // مدیریت وضعیت ویجت‌ها
        document.querySelectorAll('.form-check-input').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const widgetType = this.id.replace('_enabled', '');
                const enabled = this.checked ? 1 : 0;
                
                const formData = new FormData();
                formData.append('csrf_token', '<?php echo $csrfToken; ?>');
                formData.append('action', 'toggle_widget');
                formData.append('widget_type', widgetType);
                formData.append('enabled', enabled);
                
                fetch('widgets.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(() => {
                    // نمایش پیام موفقیت
                    const alert = document.createElement('div');
                    alert.className = 'alert alert-success alert-dismissible fade show';
                    alert.innerHTML = `
                        <i class="bi bi-check-circle"></i>
                        وضعیت ویجت بروزرسانی شد
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    `;
                    document.querySelector('main').insertBefore(alert, document.querySelector('main').firstChild);
                    
                    setTimeout(() => {
                        alert.remove();
                    }, 3000);
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            });
        });
        
        // ویرایش تنظیمات ویجت
        function editWidget(widgetType) {
            document.getElementById('widgetType').value = widgetType;
            
            // لود کردن تنظیمات ویجت
            const settings = <?php echo json_encode($currentSettings); ?>;
            const widgetSettings = settings[widgetType + '_widget'] || {};
            
            // نمایش فرم تنظیمات
            const content = generateSettingsForm(widgetType, widgetSettings);
            document.getElementById('widgetSettingsContent').innerHTML = content;
            
            // نمایش مودال
            const modal = new bootstrap.Modal(document.getElementById('widgetSettingsModal'));
            modal.show();
        }
        
        // تولید فرم تنظیمات
        function generateSettingsForm(widgetType, settings) {
            let form = '';
            
            switch (widgetType) {
                case 'hero':
                    form = `
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">عنوان</label>
                                    <input type="text" class="form-control" name="title" value="${settings.title || ''}">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">زیرعنوان</label>
                                    <input type="text" class="form-control" name="subtitle" value="${settings.subtitle || ''}">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تصویر پس‌زمینه</label>
                            <input type="text" class="form-control" name="image" value="${settings.image || ''}">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">نوع پس‌زمینه</label>
                                    <select class="form-select" name="background">
                                        <option value="gradient" ${settings.background === 'gradient' ? 'selected' : ''}>گرادیانت</option>
                                        <option value="solid" ${settings.background === 'solid' ? 'selected' : ''}>رنگ ثابت</option>
                                        <option value="image" ${settings.background === 'image' ? 'selected' : ''}>تصویر</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">انیمیشن</label>
                                    <select class="form-select" name="animation">
                                        <option value="fade-in" ${settings.animation === 'fade-in' ? 'selected' : ''}>محو شدن</option>
                                        <option value="slide-up" ${settings.animation === 'slide-up' ? 'selected' : ''}>اسلاید بالا</option>
                                        <option value="zoom-in" ${settings.animation === 'zoom-in' ? 'selected' : ''}>بزرگنمایی</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    `;
                    break;
                    
                case 'comments':
                    form = `
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">تعداد نظرات</label>
                                    <input type="number" class="form-control" name="limit" value="${settings.limit || 5}" min="1" max="20">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">حداکثر طول نظر</label>
                                    <input type="number" class="form-control" name="max_length" value="${settings.max_length || 500}" min="100" max="1000">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="show_avatar" ${settings.show_avatar ? 'checked' : ''}>
                                    <label class="form-check-label">نمایش آواتار</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="show_date" ${settings.show_date ? 'checked' : ''}>
                                    <label class="form-check-label">نمایش تاریخ</label>
                                </div>
                            </div>
                        </div>
                    `;
                    break;
                    
                // سایر ویجت‌ها...
            }
            
            return form;
        }
        
        // ذخیره تنظیمات
        document.getElementById('widgetSettingsForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const settings = {};
            
            // تبدیل فرم به آبجکت تنظیمات
            for (let [key, value] of formData.entries()) {
                if (key !== 'csrf_token' && key !== 'action' && key !== 'widget_type') {
                    if (value === 'on') {
                        settings[key] = true;
                    } else if (value === 'off') {
                        settings[key] = false;
                    } else {
                        settings[key] = value;
                    }
                }
            }
            
            document.getElementById('widgetSettings').value = JSON.stringify(settings);
            
            // ارسال فرم
            this.submit();
        });
    </script>
</body>
</html> 