<?php
// بررسی دسترسی
if ($_SESSION['role'] !== 'admin') {
    echo '<div class="alert alert-danger">شما دسترسی لازم را ندارید.</div>';
    return;
}

$action = $_GET['action'] ?? 'list';
$moduleName = $_GET['module'] ?? '';
$message = '';
$messageType = '';

// پردازش عملیات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['toggle_module'])) {
            $moduleName = sanitizeInput($_POST['module_name']);
            $status = $_POST['status'] === 'active' ? 'active' : 'inactive';
            
            // بررسی وجود ماژول
            $modulePath = "../modules/$moduleName";
            if (!is_dir($modulePath)) {
                throw new Exception('ماژول مورد نظر یافت نشد');
            }
            
            // بروزرسانی وضعیت ماژول
            $stmt = $pdo->prepare("INSERT INTO modules (name, status, updated_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE status = ?, updated_at = NOW()");
            $stmt->execute([$moduleName, $status, $status]);
            
            $message = "وضعیت ماژول $moduleName با موفقیت تغییر کرد";
            $messageType = 'success';
            
        } elseif (isset($_POST['save_settings'])) {
            $moduleName = sanitizeInput($_POST['module_name']);
            $settings = $_POST['settings'] ?? [];
            
            // ذخیره تنظیمات ماژول
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO module_settings (module_name, setting_key, setting_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$moduleName, $key, $value, $value]);
            }
            
            $message = "تنظیمات ماژول $moduleName با موفقیت ذخیره شد";
            $messageType = 'success';
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}

// دریافت ماژول‌های موجود
function getAvailableModules() {
    $modules = [];
    $modulesDir = '../modules';
    
    if (is_dir($modulesDir)) {
        $dirs = scandir($modulesDir);
        foreach ($dirs as $dir) {
            if ($dir !== '.' && $dir !== '..' && is_dir($modulesDir . '/' . $dir)) {
                $configFile = $modulesDir . '/' . $dir . '/config.php';
                if (file_exists($configFile)) {
                    $config = include $configFile;
                    $modules[$dir] = $config;
                } else {
                    // ماژول بدون فایل config
                    $modules[$dir] = [
                        'name' => ucfirst($dir),
                        'description' => 'ماژول ' . ucfirst($dir),
                        'version' => '1.0.0',
                        'author' => 'Dima CMS',
                        'category' => 'general'
                    ];
                }
            }
        }
    }
    
    return $modules;
}

// دریافت وضعیت ماژول‌ها
function getModuleStatus($pdo) {
    $stmt = $pdo->query("SELECT name, status FROM modules");
    $statuses = [];
    while ($row = $stmt->fetch()) {
        $statuses[$row['name']] = $row['status'];
    }
    return $statuses;
}

// دریافت تنظیمات ماژول
function getModuleSettings($pdo, $moduleName) {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM module_settings WHERE module_name = ?");
    $stmt->execute([$moduleName]);
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

$availableModules = getAvailableModules();
$moduleStatuses = getModuleStatus($pdo);

if ($action === 'list') {
    ?>
    
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="bi bi-puzzle"></i> مدیریت ماژول‌ها</h4>
        <div>
            <a href="?page=modules&action=install" class="btn btn-primary">
                <i class="bi bi-download"></i> نصب ماژول جدید
            </a>
        </div>
    </div>
    
    <div class="row">
        <?php foreach ($availableModules as $moduleName => $moduleInfo): ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><?php echo htmlspecialchars($moduleInfo['name']) ?></h6>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" 
                               <?php echo ($moduleStatuses[$moduleName] ?? 'inactive') === 'active' ? 'checked' : '' ?>
                               onchange="toggleModule('<?php echo $moduleName ?>', this.checked)">
                    </div>
                </div>
                <div class="card-body">
                    <p class="text-muted small"><?php echo htmlspecialchars($moduleInfo['description']) ?></p>
                    <div class="row text-center">
                        <div class="col-4">
                            <small class="text-muted">نسخه</small><br>
                            <strong><?php echo htmlspecialchars($moduleInfo['version']) ?></strong>
                        </div>
                        <div class="col-4">
                            <small class="text-muted">نویسنده</small><br>
                            <strong><?php echo htmlspecialchars($moduleInfo['author']) ?></strong>
                        </div>
                        <div class="col-4">
                            <small class="text-muted">دسته</small><br>
                            <strong><?php echo htmlspecialchars($moduleInfo['category']) ?></strong>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="btn-group btn-group-sm w-100">
                        <a href="?page=modules&action=settings&module=<?php echo urlencode($moduleName) ?>" 
                           class="btn btn-outline-primary">
                            <i class="bi bi-gear"></i> تنظیمات
                        </a>
                        <a href="?page=modules&action=info&module=<?php echo urlencode($moduleName) ?>" 
                           class="btn btn-outline-info">
                            <i class="bi bi-info-circle"></i> اطلاعات
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <script>
    function toggleModule(moduleName, isActive) {
        const status = isActive ? 'active' : 'inactive';
        
        fetch('?page=modules', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `toggle_module=1&module_name=${encodeURIComponent(moduleName)}&status=${status}&csrf_token=${getCSRFToken()}`
        })
        .then(response => response.text())
        .then(() => {
            // نمایش پیام موفقیت
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show';
            alert.innerHTML = `
                وضعیت ماژول ${moduleName} با موفقیت تغییر کرد
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.querySelector('.container').insertBefore(alert, document.querySelector('.container').firstChild);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('خطا در تغییر وضعیت ماژول');
        });
    }
    </script>
    
    <?php
} elseif ($action === 'settings' && $moduleName) {
    $moduleSettings = getModuleSettings($pdo, $moduleName);
    $moduleInfo = $availableModules[$moduleName] ?? [];
    
    // تنظیمات پیش‌فرض ماژول‌ها
    $defaultSettings = [
        'Ecommerce' => [
            'currency' => 'تومان',
            'tax_rate' => '9',
            'shipping_cost' => '50000',
            'enable_reviews' => '1'
        ],
        'FormBuilder' => [
            'max_forms' => '10',
            'enable_captcha' => '1',
            'email_notifications' => '1'
        ],
        'UserManagement' => [
            'allow_registration' => '1',
            'email_verification' => '1',
            'max_users' => '1000'
        ]
    ];
    
    $currentSettings = $defaultSettings[$moduleName] ?? [];
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="bi bi-gear"></i> تنظیمات ماژول <?php echo htmlspecialchars($moduleInfo['name'] ?? $moduleName) ?>
        </h4>
        <a href="?page=modules" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت
        </a>
    </div>
    
    <form method="POST">
        <input type="hidden" name="module_name" value="<?php echo htmlspecialchars($moduleName) ?>">
        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
        
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">تنظیمات عمومی</h6>
            </div>
            <div class="card-body">
                <?php foreach ($currentSettings as $key => $defaultValue): ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo ucfirst(str_replace('_', ' ', $key)) ?></label>
                    <?php if (strpos($key, 'enable') === 0 || strpos($key, 'allow') === 0): ?>
                    <select name="settings[<?php echo $key ?>]" class="form-select">
                        <option value="1" <?php echo ($moduleSettings[$key] ?? $defaultValue) === '1' ? 'selected' : '' ?>>فعال</option>
                        <option value="0" <?php echo ($moduleSettings[$key] ?? $defaultValue) === '0' ? 'selected' : '' ?>>غیرفعال</option>
                    </select>
                    <?php else: ?>
                    <input type="text" name="settings[<?php echo $key ?>]" class="form-control"
                           value="<?php echo htmlspecialchars($moduleSettings[$key] ?? $defaultValue) ?>">
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="mt-3">
            <button type="submit" name="save_settings" class="btn btn-primary">
                <i class="bi bi-check"></i> ذخیره تنظیمات
            </button>
        </div>
    </form>
    
    <?php
} elseif ($action === 'info' && $moduleName) {
    $moduleInfo = $availableModules[$moduleName] ?? [];
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="bi bi-info-circle"></i> اطلاعات ماژول <?php echo htmlspecialchars($moduleInfo['name'] ?? $moduleName) ?>
        </h4>
        <a href="?page=modules" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت
        </a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>اطلاعات عمومی</h6>
                    <table class="table table-sm">
                        <tr>
                            <td><strong>نام:</strong></td>
                            <td><?php echo htmlspecialchars($moduleInfo['name'] ?? $moduleName) ?></td>
                        </tr>
                        <tr>
                            <td><strong>نسخه:</strong></td>
                            <td><?php echo htmlspecialchars($moduleInfo['version'] ?? '1.0.0') ?></td>
                        </tr>
                        <tr>
                            <td><strong>نویسنده:</strong></td>
                            <td><?php echo htmlspecialchars($moduleInfo['author'] ?? 'Dima CMS') ?></td>
                        </tr>
                        <tr>
                            <td><strong>دسته:</strong></td>
                            <td><?php echo htmlspecialchars($moduleInfo['category'] ?? 'عمومی') ?></td>
                        </tr>
                        <tr>
                            <td><strong>وضعیت:</strong></td>
                            <td>
                                <span class="badge bg-<?php echo ($moduleStatuses[$moduleName] ?? 'inactive') === 'active' ? 'success' : 'secondary' ?>">
                                    <?php echo ($moduleStatuses[$moduleName] ?? 'inactive') === 'active' ? 'فعال' : 'غیرفعال' ?>
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>توضیحات</h6>
                    <p><?php echo htmlspecialchars($moduleInfo['description'] ?? 'توضیحی برای این ماژول موجود نیست.') ?></p>
                    
                    <?php if (!empty($moduleInfo['features'])): ?>
                    <h6>ویژگی‌ها</h6>
                    <ul>
                        <?php foreach ($moduleInfo['features'] as $feature): ?>
                        <li><?php echo htmlspecialchars($feature) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php
} elseif ($action === 'install') {
    ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="bi bi-download"></i> نصب ماژول جدید</h4>
        <a href="?page=modules" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت
        </a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i>
                برای نصب ماژول جدید، فایل ZIP ماژول را در پوشه <code>modules/</code> قرار دهید.
            </div>
            
            <h6>ماژول‌های پیشنهادی:</h6>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-cart display-4 text-primary"></i>
                            <h6 class="mt-2">ماژول فروشگاه</h6>
                            <p class="text-muted small">سیستم فروشگاه آنلاین کامل</p>
                            <span class="badge bg-success">نصب شده</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-file-earmark-text display-4 text-warning"></i>
                            <h6 class="mt-2">ماژول فرم‌ساز</h6>
                            <p class="text-muted small">ایجاد فرم‌های سفارشی</p>
                            <span class="badge bg-success">نصب شده</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-people display-4 text-info"></i>
                            <h6 class="mt-2">ماژول مدیریت کاربران</h6>
                            <p class="text-muted small">مدیریت پیشرفته کاربران</p>
                            <span class="badge bg-success">نصب شده</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php
}
?>
