<?php
// بررسی دسترسی
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth.php');
    exit;
}

// دریافت آمار
try {
    // آمار کلی
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $stats['users'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM posts WHERE status = 'published'");
    $stats['posts'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM pages WHERE status = 'published'");
    $stats['pages'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM comments WHERE status = 'approved'");
    $stats['comments'] = $stmt->fetchColumn();
    
    // آخرین مطالب
    $stmt = $pdo->query("
        SELECT p.title, p.slug, p.created_at, u.username 
        FROM posts p 
        LEFT JOIN users u ON p.author_id = u.id 
        ORDER BY p.created_at DESC 
        LIMIT 5
    ");
    $recent_posts = $stmt->fetchAll();
    
    // آخرین نظرات
    $stmt = $pdo->query("
        SELECT c.content, c.author_name, c.created_at, p.title as post_title
        FROM comments c 
        LEFT JOIN posts p ON c.post_id = p.id 
        WHERE c.status = 'approved'
        ORDER BY c.created_at DESC 
        LIMIT 5
    ");
    $recent_comments = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $stats = ['users' => 0, 'posts' => 0, 'pages' => 0, 'comments' => 0];
    $recent_posts = [];
    $recent_comments = [];
}
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="mb-4">خوش آمدید، <?php echo htmlspecialchars($_SESSION['username']) ?>!</h2>
    </div>
</div>

<!-- آمار کلی -->
<div class="row mb-4">
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card text-center">
            <div class="stats-icon bg-primary">
                <i class="bi bi-people"></i>
            </div>
            <h3 class="mt-3"><?php echo number_format($stats['users']) ?></h3>
            <p class="text-muted">کاربران</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card text-center">
            <div class="stats-icon bg-success">
                <i class="bi bi-file-text"></i>
            </div>
            <h3 class="mt-3"><?php echo number_format($stats['posts']) ?></h3>
            <p class="text-muted">مطالب</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card text-center">
            <div class="stats-icon bg-warning">
                <i class="bi bi-file-earmark"></i>
            </div>
            <h3 class="mt-3"><?php echo number_format($stats['pages']) ?></h3>
            <p class="text-muted">صفحات</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card text-center">
            <div class="stats-icon bg-info">
                <i class="bi bi-chat-dots"></i>
            </div>
            <h3 class="mt-3"><?php echo number_format($stats['comments']) ?></h3>
            <p class="text-muted">نظرات</p>
        </div>
    </div>
</div>

<!-- محتوای اصلی -->
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">آخرین مطالب</h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_posts)): ?>
                    <p class="text-muted">هنوز مطلبی منتشر نشده است.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>عنوان</th>
                                    <th>نویسنده</th>
                                    <th>تاریخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_posts as $post): ?>
                                <tr>
                                    <td>
                                        <a href="../post.php?slug=<?php echo htmlspecialchars($post['slug']) ?>" target="_blank">
                                            <?php echo htmlspecialchars($post['title']) ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($post['username'] ?? 'نامشخص') ?></td>
                                    <td><?php echo date('Y/m/d H:i', strtotime($post['created_at'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">آخرین نظرات</h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_comments)): ?>
                    <p class="text-muted">هنوز نظری ثبت نشده است.</p>
                <?php else: ?>
                    <?php foreach ($recent_comments as $comment): ?>
                    <div class="border-bottom pb-2 mb-2">
                        <small class="text-muted">
                            <?php echo htmlspecialchars($comment['author_name']) ?> در 
                            <?php echo htmlspecialchars($comment['post_title']) ?>
                        </small>
                        <p class="mb-1 small"><?php echo htmlspecialchars(mb_substr($comment['content'], 0, 100, 'UTF-8')) ?>...</p>
                        <small class="text-muted"><?php echo formatPersianDate($comment['created_at']) ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5 class="mb-0">اقدامات سریع</h5>
            </div>
            <div class="card-body">
                <div class="d-flex gap-2">
                    <a href="?page=posts&action=add" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>مطلب جدید
                    </a>
                    <a href="?page=pages&action=add" class="btn btn-success">
                        <i class="bi bi-file-plus me-2"></i>صفحه جدید
                    </a>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                    <a href="?page=users&action=add" class="btn btn-info">
                        <i class="bi bi-person-plus me-2"></i>کاربر جدید
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.stats-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s;
    border: none;
}

.stats-card:hover {
    transform: translateY(-5px);
}

.stats-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    font-size: 1.5rem;
    color: white;
}
</style>
