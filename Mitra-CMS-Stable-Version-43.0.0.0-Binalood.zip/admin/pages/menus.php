<?php
// مدیریت صفحات
$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

// پردازش فرم‌ها
if ($_POST) {
    if ($action === 'add' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $link = trim($_POST['link'] ?? '');
        $ordering = trim($_POST['ordering'] ?? '');
        $excerpt = trim($_POST['excerpt'] ?? '');
        $status = $_POST['status'] ?? 'inactive';
        $meta_title = trim($_POST['meta_title'] ?? '');
        $meta_description = trim($_POST['meta_description'] ?? '');
        $meta_keywords = trim($_POST['meta_keywords'] ?? '');
        $parent = trim($_POST['parent'] ?? '');
        
        if (empty($title) || empty($slug)) {
            $error = 'عنوان و نامک الزامی هستند';
        } else {
            try {
                if ($action === 'add') {
                    // بررسی تکراری نبودن slug
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM menus WHERE slug = ?");
                    $stmt->execute([$slug]);
                    
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'این نامک قبلاً استفاده شده است';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO menus (title, slug,location , link,ordering , excerpt, status, meta_title, meta_description, meta_keywords, parent, author_id) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        if ($stmt->execute([$title, $slug,$location , $link ,$ordering , $excerpt, $status, $meta_title, $meta_description, $meta_keywords, $parent, $_SESSION['user_id']])) {
                            $message = 'منو با موفقیت ایجاد شد';
                            $action = 'list';
                        } else {
                            $error = 'خطا در ایجاد منو';
                        }
                    }
                } elseif ($action === 'edit') {
                    $id = $_POST['id'] ?? 0;
                    $stmt = $pdo->prepare("
                        UPDATE menus 
                        SET title = ?, slug = ?, location = ?, link = ?, ordering= ?, excerpt = ?, status = ?, meta_title = ?, meta_description = ?, meta_keywords = ? , parent = ?
                        WHERE id = ?
                    ");
                    if ($stmt->execute([$title, $slug, $location, $link, $ordering, $excerpt, $status, $meta_title, $meta_description, $meta_keywords, $parent, $id])) {
                        $message = 'منو با موفقیت به‌روزرسانی شد';
                        $action = 'list';
                    } else {
                        $error = 'خطا در به‌روزرسانی منو';
                    }
                }
            } catch (PDOException $e) {
                $error = 'خطا: ' . $e->getMessage();
            }
        }
    }
}

// حذف منو
if ($action === 'delete' && isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM menus WHERE id = ?");
        if ($stmt->execute([$_GET['id']])) {
            $message = 'منو با موفقیت حذف شد';
        } else {
            $error = 'خطا در حذف منو';
        }
        $action = 'list';
    } catch (PDOException $e) {
        $error = 'خطا: ' . $e->getMessage();
    }
}

// دریافت صفحات
$menus = [];
if ($action === 'list') {
    try {
        $stmt = $pdo->query("
            SELECT p.*, u.username 
            FROM menus p 
            LEFT JOIN users u ON p.author_id = u.id 
            ORDER BY p.created_at DESC
        ");
        $menus = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = 'خطا در دریافت صفحات: ' . $e->getMessage();
    }
}

// دریافت منو برای ویرایش
$editPage = null;
if ($action === 'edit' && isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM menus WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $editPage = $stmt->fetch();
        
        if (!$editPage) {
            $error = 'منو یافت نشد';
            $action = 'list';
        }
    } catch (PDOException $e) {
        $error = 'خطا: ' . $e->getMessage();
        $action = 'list';
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>مدیریت صفحات</h2>
    <?php if ($action === 'list'): ?>
        <a href="?page=menus&action=add" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> افزودن منو جدید
        </a>
    <?php else: ?>
        <a href="?page=menus" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> بازگشت به لیست
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'list'): ?>
    <!-- لیست صفحات -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($menus)): ?>
                <div class="alert alert-info text-center">
                    <i class="bi bi-info-circle display-6 d-block mb-3"></i>
                    <h5>هنوز منو‌ای ایجاد نشده است</h5>
                    <p>برای شروع، اولین منو خود را ایجاد کنید.</p>
                    <a href="?page=menus&action=add" class="btn btn-primary">ایجاد منو جدید</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>عنوان</th>
                                <th>نامک</th>
                                <th>جایگاه</th>
                                <th>وضعیت</th>
                                <th>نویسنده</th>
                                <th>تاریخ ایجاد</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($menus as $page): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($page['title']) ?></strong>
                                        <?php if ($page['excerpt']): ?>
                                            <br><small class="text-muted"><?php echo htmlspecialchars(substr($page['excerpt'], 0, 100)) ?>...</small>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?php echo htmlspecialchars($page['slug']) ?></code></td>
                                    <td><code><?php echo htmlspecialchars($page['location']) ?></code></td>
                                    <td>
                                        <span class="badge bg-<?php echo $page['status'] === 'active' ? 'success' : ($page['status'] === 'inactive' ? 'warning' : 'secondary') ?>">
                                            <?php echo $page['status'] === 'active' ? 'منتشر شده' : ($page['status'] === 'inactive' ? 'پیش‌نویس' : 'خصوصی') ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($page['username'] ?? 'نامشخص') ?></td>
                                    <td><?php echo date('Y/m/d H:i', strtotime($page['created_at'])) ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="../page.php?slug=<?php echo urlencode($page['slug']) ?>" class="btn btn-outline-info" target="_blank" title="مشاهده">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="?page=menus&action=edit&id=<?php echo $page['id'] ?>" class="btn btn-outline-primary" title="ویرایش">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="?page=menus&action=delete&id=<?php echo $page['id'] ?>" class="btn btn-outline-danger" title="حذف"
                                               onclick="return confirm('آیا از حذف این منو مطمئن هستید؟')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php elseif ($action === 'add' || $action === 'edit'): ?>
    <!-- فرم افزودن/ویرایش منو -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-<?php echo $action === 'add' ? 'plus-circle' : 'pencil' ?>"></i>
                <?php echo $action === 'add' ? 'افزودن منو جدید' : 'ویرایش منو' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="post">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?php echo $editPage['id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label">عنوان منو <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="title" 
                                   value="<?php echo htmlspecialchars($editPage['title'] ?? '') ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نامک (URL) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="slug" 
                                   value="<?php echo htmlspecialchars($editPage['slug'] ?? '') ?>" required>
                            <div class="form-text">فقط حروف انگلیسی، اعداد و خط تیره استفاده کنید</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">جایگاه (پیش فرض header)<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="location" 
                                   value="<?php echo htmlspecialchars($editPage['location'] ?? '') ?>" required>
                            <div class="form-text">فقط حروف انگلیسی، اعداد و خط تیره استفاده کنید</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">توضیحات</label>
                            <textarea class="form-control" name="excerpt" rows="3"><?php echo htmlspecialchars($editPage['excerpt'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">لینک</label>
                            <input type="text" class="form-control" name="link" 
                                   value="<?php echo htmlspecialchars($editPage['link'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ترتیب</label>
                            <input type="text" class="form-control" name="ordering" 
                                   value="<?php echo htmlspecialchars($editPage['ordering'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">والد(پیش فرض 0)</label>
                            <input type="text" class="form-control" name="parent" 
                                   value="<?php echo htmlspecialchars($editPage['parent'] ?? '') ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">وضعیت</label>
                            <select class="form-select" name="status">
                                <option value="inactive" <?php echo ($editPage['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                                    پیش‌نویس
                                </option>
                                <option value="active" <?php echo ($editPage['status'] ?? '') === 'active' ? 'selected' : '' ?>>
                                    منتشر شده
                                </option>
                            </select>
                        </div>
                                                
                        <hr>
                        <h6>تنظیمات SEO</h6>
                        
                        <div class="mb-3">
                            <label class="form-label">عنوان متا</label>
                            <input type="text" class="form-control" name="meta_title" 
                                   value="<?php echo htmlspecialchars($editPage['meta_title'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">توضیحات متا</label>
                            <textarea class="form-control" name="meta_description" rows="3"><?php echo htmlspecialchars($editPage['meta_description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">کلمات کلیدی</label>
                            <input type="text" class="form-control" name="meta_keywords" 
                                   value="<?php echo htmlspecialchars($editPage['meta_keywords'] ?? '') ?>">
                            <div class="form-text">کلمات را با کاما جدا کنید</div>
                        </div>
                    </div>
                </div>
                
                <hr>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i>
                        <?php echo $action === 'add' ? 'ایجاد منو' : 'به‌روزرسانی منو' ?>
                    </button>
                    <a href="?page=menus" class="btn btn-secondary">
                        <i class="bi bi-x-circle"></i> انصراف
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
