<?php
/**
 * SecurityMiddleware - میدلور امنیتی پیشرفته
 */
class SecurityMiddleware {
    private $pdo;
    private $config;
    
    public function __construct($pdo, $config = []) {
        $this->pdo = $pdo;
        $this->config = $config;
    }
    
    /**
     * اجرای تمام بررسی‌های امنیتی
     */
    public function run() {
        $this->checkIP();
        $this->checkUserAgent();
        $this->checkRequestMethod();
        $this->checkRateLimit();
        $this->checkSession();
        $this->setSecurityHeaders();
        $this->logRequest();
    }
    
    /**
     * بررسی IP
     */
    private function checkIP() {
        $clientIP = $_SERVER['REMOTE_ADDR'];
        $allowedIPs = $this->config['allowed_ips'] ?? [];
        $blockedIPs = $this->config['blocked_ips'] ?? [];
        
        // بررسی IP های مسدود شده
        if (in_array($clientIP, $blockedIPs)) {
            $this->blockAccess('IP مسدود شده');
        }
        
        // بررسی IP های مجاز (اگر تنظیم شده باشد)
        if (!empty($allowedIPs) && !in_array($clientIP, $allowedIPs)) {
            $this->blockAccess('IP غیرمجاز');
        }
        
        // بررسی IP در دیتابیس
        $this->checkIPInDatabase($clientIP);
    }
    
    /**
     * بررسی User Agent
     */
    private function checkUserAgent() {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // بررسی User Agent های مشکوک
        $suspiciousPatterns = [
            'bot', 'crawler', 'spider', 'scraper',
            'curl', 'wget', 'python', 'perl',
            'nikto', 'sqlmap', 'nmap',
            'libwww', 'lwp', 'lynx'
        ];
        
        foreach ($suspiciousPatterns as $pattern) {
            if (stripos($userAgent, $pattern) !== false) {
                $this->logSecurityEvent('suspicious_user_agent', ['user_agent' => $userAgent]);
                // فقط لاگ کنید، مسدود نکنید
            }
        }
    }
    
    /**
     * بررسی متد درخواست
     */
    private function checkRequestMethod() {
        $method = $_SERVER['REQUEST_METHOD'];
        $allowedMethods = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'];
        
        if (!in_array($method, $allowedMethods)) {
            $this->blockAccess('متد درخواست غیرمجاز');
        }
        
        // بررسی درخواست‌های مشکوک
        if ($method === 'POST' && empty($_POST)) {
            $this->logSecurityEvent('empty_post_request');
        }
    }
    
    /**
     * بررسی Rate Limiting
     */
    private function checkRateLimit() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $uri = $_SERVER['REQUEST_URI'];
        $key = "rate_limit_{$ip}_{$uri}";
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['count' => 0, 'reset_time' => time() + 60];
        }
        
        if (time() > $_SESSION[$key]['reset_time']) {
            $_SESSION[$key] = ['count' => 0, 'reset_time' => time() + 60];
        }
        
        $_SESSION[$key]['count']++;
        
        $limit = $this->config['rate_limit'] ?? 100;
        if ($_SESSION[$key]['count'] > $limit) {
            $this->blockAccess('تعداد درخواست‌ها بیش از حد مجاز');
        }
    }
    
    /**
     * بررسی جلسه
     */
    private function checkSession() {
        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
            // بررسی انقضای جلسه
            if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_LIFETIME) {
                session_destroy();
                header('Location: auth.php?message=session_expired');
                exit;
            }
            
            // بررسی تغییر IP
            if (isset($_SESSION['login_ip']) && $_SESSION['login_ip'] !== $_SERVER['REMOTE_ADDR']) {
                $this->logSecurityEvent('ip_change_detected', [
                    'old_ip' => $_SESSION['login_ip'],
                    'new_ip' => $_SERVER['REMOTE_ADDR']
                ]);
                // فقط لاگ کنید، جلسه را قطع نکنید
            }
        }
    }
    
    /**
     * تنظیم هدرهای امنیتی
     */
    private function setSecurityHeaders() {
        // فقط در production
        if (!isset($_SERVER['HTTP_HOST']) || strpos($_SERVER['HTTP_HOST'], 'localhost') === false) {
            header('X-Content-Type-Options: nosniff');
            header('X-Frame-Options: DENY');
            header('X-XSS-Protection: 1; mode=block');
            header('Referrer-Policy: strict-origin-when-cross-origin');
            header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: https:; font-src \'self\' data:;');
            header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
    }
    
    /**
     * لاگ درخواست
     */
    private function logRequest() {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR'],
            'method' => $_SERVER['REQUEST_METHOD'],
            'uri' => $_SERVER['REQUEST_URI'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
            'user_id' => $_SESSION['user_id'] ?? null
        ];
        
        $logFile = 'logs/requests.log';
        if (!is_dir('logs')) {
            mkdir('logs', 0755, true);
        }
        
        file_put_contents($logFile, json_encode($logData) . "\n", FILE_APPEND | LOCK_EX);
    }
    
    /**
     * بررسی IP در دیتابیس
     */
    private function checkIPInDatabase($ip) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) FROM blocked_ips WHERE ip_address = ? AND expires_at > NOW()
            ");
            $stmt->execute([$ip]);
            
            if ($stmt->fetchColumn() > 0) {
                $this->blockAccess('IP مسدود شده در دیتابیس');
            }
        } catch (Exception $e) {
            // در صورت خطا، ادامه دهید
        }
    }
    
    /**
     * مسدود کردن دسترسی
     */
    private function blockAccess($reason) {
        $this->logSecurityEvent('access_blocked', ['reason' => $reason]);
        http_response_code(403);
        die('دسترسی غیرمجاز');
    }
    
    /**
     * لاگ رویداد امنیتی
     */
    private function logSecurityEvent($event, $details = []) {
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'event' => $event,
            'details' => $details
        ];
        
        $logFile = 'logs/security.log';
        if (!is_dir('logs')) {
            mkdir('logs', 0755, true);
        }
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
    
    /**
     * بررسی فایل آپلود شده
     */
    public function validateFile($file) {
        // بررسی خطاهای آپلود
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'خطا در آپلود فایل'];
        }
        
        // بررسی اندازه فایل
        $maxSize = $this->config['max_file_size'] ?? 5 * 1024 * 1024;
        if ($file['size'] > $maxSize) {
            return ['success' => false, 'message' => 'حجم فایل بیش از حد مجاز است'];
        }
        
        // بررسی نوع فایل
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        $allowedMimeTypes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'text/plain' => 'txt',
            'application/zip' => 'zip'
        ];
        
        if (!array_key_exists($mimeType, $allowedMimeTypes)) {
            return ['success' => false, 'message' => 'نوع فایل مجاز نیست'];
        }
        
        // بررسی پسوند فایل
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $expectedExtension = $allowedMimeTypes[$mimeType];
        
        if ($extension !== $expectedExtension) {
            return ['success' => false, 'message' => 'پسوند فایل با نوع آن مطابقت ندارد'];
        }
        
        // بررسی محتوای فایل برای تصاویر
        if (strpos($mimeType, 'image/') === 0) {
            $imageInfo = getimagesize($file['tmp_name']);
            if ($imageInfo === false) {
                return ['success' => false, 'message' => 'فایل تصویر نامعتبر است'];
            }
            
            // محدودیت ابعاد تصویر
            $maxWidth = $this->config['max_image_width'] ?? 4000;
            $maxHeight = $this->config['max_image_height'] ?? 4000;
            
            if ($imageInfo[0] > $maxWidth || $imageInfo[1] > $maxHeight) {
                return ['success' => false, 'message' => 'ابعاد تصویر بیش از حد مجاز است'];
            }
        }
        
        return ['success' => true, 'message' => 'فایل معتبر است'];
    }
    
    /**
     * تولید نام فایل امن
     */
    public function generateSecureFilename($originalName, $extension) {
        $timestamp = time();
        $randomString = bin2hex(random_bytes(8));
        return $timestamp . '_' . $randomString . '.' . $extension;
    }
    
    /**
     * بررسی مسیر فایل
     */
    public function validateFilePath($path) {
        $realPath = realpath($path);
        $uploadDir = realpath('uploads');
        
        if ($realPath === false || strpos($realPath, $uploadDir) !== 0) {
            return false;
        }
        
        return true;
    }
    
    /**
     * پاکسازی ورودی
     */
    public function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        
        // حذف کاراکترهای خطرناک
        $input = preg_replace('/[^\p{L}\p{N}\s\-_\.@]/u', '', $input);
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * بررسی CSRF Token
     */
    public function verifyCSRFToken($token) {
        return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
    }
    
    /**
     * تولید CSRF Token
     */
    public function generateCSRFToken() {
        if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }
}
?> 