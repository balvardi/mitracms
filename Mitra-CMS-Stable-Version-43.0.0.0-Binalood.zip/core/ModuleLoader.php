<?php

class ModuleLoader {
    private $modules = [];
    private $activeModules = [];
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->loadModules();
    }
    
    /**
     * بارگذاری تمام ماژول‌های موجود
     */
    private function loadModules() {
        $modulesDir = __DIR__ . '/../modules';
        
        if (is_dir($modulesDir)) {
            $dirs = scandir($modulesDir);
            foreach ($dirs as $dir) {
                if ($dir !== '.' && $dir !== '..' && is_dir($modulesDir . '/' . $dir)) {
                    $configFile = $modulesDir . '/' . $dir . '/config.php';
                    if (file_exists($configFile)) {
                        $config = include $configFile;
                        $this->modules[$dir] = $config;
                    }
                }
            }
        }
        
        // دریافت ماژول‌های فعال
        $this->loadActiveModules();
    }
    
    /**
     * بارگذاری ماژول‌های فعال از پایگاه داده
     */
    private function loadActiveModules() {
        try {
            $stmt = $this->pdo->query("SELECT name FROM modules WHERE status = 'active'");
            while ($row = $stmt->fetch()) {
                $this->activeModules[] = $row['name'];
            }
        } catch (PDOException $e) {
            error_log('Error loading active modules: ' . $e->getMessage());
        }
    }
    
    /**
     * دریافت تمام ماژول‌های موجود
     */
    public function getAvailableModules() {
        return $this->modules;
    }
    
    /**
     * دریافت ماژول‌های فعال
     */
    public function getActiveModules() {
        return $this->activeModules;
    }
    
    /**
     * بررسی فعال بودن ماژول
     */
    public function isModuleActive($moduleName) {
        return in_array($moduleName, $this->activeModules);
    }
    
    /**
     * دریافت تنظیمات ماژول
     */
    public function getModuleSettings($moduleName) {
        try {
            $stmt = $this->pdo->prepare("SELECT setting_key, setting_value FROM module_settings WHERE module_name = ?");
            $stmt->execute([$moduleName]);
            $settings = [];
            while ($row = $stmt->fetch()) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
            return $settings;
        } catch (PDOException $e) {
            error_log('Error loading module settings: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * بارگذاری کنترلر ماژول
     */
    public function loadModuleController($moduleName, $controllerName) {
        $controllerFile = __DIR__ . "/../modules/$moduleName/Controllers/$controllerName.php";
        
        if (file_exists($controllerFile)) {
            require_once $controllerFile;
            $className = $controllerName . 'Controller';
            if (class_exists($className)) {
                return new $className($this->pdo);
            }
        }
        
        return null;
    }
    
    /**
     * اجرای هوک ماژول
     */
    public function executeHook($hookName, $data = []) {
        $results = [];
        
        foreach ($this->activeModules as $moduleName) {
            $hookFile = __DIR__ . "/../modules/$moduleName/hooks/$hookName.php";
            if (file_exists($hookFile)) {
                $hookResult = include $hookFile;
                if ($hookResult !== null) {
                    $results[$moduleName] = $hookResult;
                }
            }
        }
        
        return $results;
    }
    
    /**
     * دریافت منوهای ماژول‌ها
     */
    public function getModuleMenus() {
        $menus = [];
        
        foreach ($this->activeModules as $moduleName) {
            $menuFile = __DIR__ . "/../modules/$moduleName/menu.php";
            if (file_exists($menuFile)) {
                $moduleMenu = include $menuFile;
                if (is_array($moduleMenu)) {
                    $menus[$moduleName] = $moduleMenu;
                }
            }
        }
        
        return $menus;
    }
    
    /**
     * فعال‌سازی ماژول
     */
    public function activateModule($moduleName) {
        if (!isset($this->modules[$moduleName])) {
            throw new Exception('ماژول مورد نظر یافت نشد');
        }
        
        try {
            $stmt = $this->pdo->prepare("INSERT INTO modules (name, status, activated_at) VALUES (?, 'active', NOW()) ON DUPLICATE KEY UPDATE status = 'active', activated_at = NOW()");
            $stmt->execute([$moduleName]);
            
            // اجرای اسکریپت نصب ماژول
            $this->runModuleInstall($moduleName);
            
            $this->activeModules[] = $moduleName;
            return true;
        } catch (PDOException $e) {
            throw new Exception('خطا در فعال‌سازی ماژول: ' . $e->getMessage());
        }
    }
    
    /**
     * غیرفعال‌سازی ماژول
     */
    public function deactivateModule($moduleName) {
        try {
            $stmt = $this->pdo->prepare("UPDATE modules SET status = 'inactive' WHERE name = ?");
            $stmt->execute([$moduleName]);
            
            $key = array_search($moduleName, $this->activeModules);
            if ($key !== false) {
                unset($this->activeModules[$key]);
            }
            
            return true;
        } catch (PDOException $e) {
            throw new Exception('خطا در غیرفعال‌سازی ماژول: ' . $e->getMessage());
        }
    }
    
    /**
     * اجرای اسکریپت نصب ماژول
     */
    private function runModuleInstall($moduleName) {
        $installFile = __DIR__ . "/../modules/$moduleName/install.php";
        if (file_exists($installFile)) {
            include $installFile;
        }
    }
    
    /**
     * دریافت اطلاعات ماژول
     */
    public function getModuleInfo($moduleName) {
        return $this->modules[$moduleName] ?? null;
    }
    
    /**
     * بررسی وابستگی‌های ماژول
     */
    public function checkDependencies($moduleName) {
        $moduleInfo = $this->getModuleInfo($moduleName);
        if (!$moduleInfo) {
            return false;
        }
        
        $dependencies = $moduleInfo['dependencies'] ?? [];
        foreach ($dependencies as $dependency) {
            if (!$this->isModuleActive($dependency)) {
                return false;
            }
        }
        
        return true;
    }
} 