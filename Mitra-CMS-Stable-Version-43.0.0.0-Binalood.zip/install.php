<?php
/**
 * Dima CMS - نصاب ساده
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// بررسی نصب قبلی
if (file_exists('.installed')) {
    die('سیستم قبلاً نصب شده است. برای نصب مجدد، فایل .installed را حذف کنید.');
}

$step = $_GET['step'] ?? 'welcome';
$error = '';
$success = '';

// پردازش فرم‌ها
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        case 'requirements':
            // بررسی نیازمندی‌ها
            $requirements = checkRequirements();
            if (array_search(false, $requirements) === false) {
                header('Location: install.php?step=database');
                exit;
            } else {
                $error = 'برخی نیازمندی‌ها برآورده نشده‌اند.';
            }
            break;
            
        case 'database':
            // تست اتصال پایگاه داده
            $dbResult = testDatabase($_POST);
            if ($dbResult['success']) {
                $_SESSION['db_config'] = $_POST;
                header('Location: install.php?step=config');
                exit;
            } else {
                $error = $dbResult['message'];
            }
            break;
            
        case 'config':
            // ایجاد فایل‌های پیکربندی
            $configResult = createConfig($_POST);
            if ($configResult['success']) {
                $_SESSION['site_config'] = $_POST;
                header('Location: install.php?step=admin');
                exit;
            } else {
                $error = $configResult['message'];
            }
            break;
            
        case 'admin':
            // ایجاد کاربر ادمین
            $adminResult = createAdmin($_POST);
            if ($adminResult['success']) {
                header('Location: install.php?step=complete');
                exit;
            } else {
                $error = $adminResult['message'];
            }
            break;
    }
}

// توابع کمکی
function checkRequirements() {
    return [
        'PHP Version >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'PDO MySQL Extension' => extension_loaded('pdo_mysql'),
        'mbstring Extension' => extension_loaded('mbstring'),
        'Config Directory Writable' => is_writable('config') || is_writable('.'),
        'Uploads Directory Writable' => is_writable('uploads') || is_writable('.')
    ];
}

function testDatabase($data) {
    try {
        $dsn = "mysql:host={$data['db_host']};port={$data['db_port']};charset=utf8mb4";
        $pdo = new PDO($dsn, $data['db_username'], $data['db_password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // ایجاد پایگاه داده
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$data['db_name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        return ['success' => true, 'message' => 'اتصال موفقیت‌آمیز'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
    }
}

function createConfig($data) {
    try {
        // فایل database.php
        $dbConfig = "<?php\nreturn [\n";
        $dbConfig .= "    'host' => '{$data['db_host']}',\n";
        $dbConfig .= "    'port' => '{$data['db_port']}',\n";
        $dbConfig .= "    'database' => '{$data['db_name']}',\n";
        $dbConfig .= "    'username' => '{$data['db_username']}',\n";
        $dbConfig .= "    'password' => '{$data['db_password']}',\n";
        $dbConfig .= "    'charset' => 'utf8mb4',\n";
        $dbConfig .= "    'options' => [\n";
        $dbConfig .= "        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,\n";
        $dbConfig .= "        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,\n";
        $dbConfig .= "        PDO::ATTR_EMULATE_PREPARES => false,\n";
        $dbConfig .= "    ]\n";
        $dbConfig .= "];\n";
        
        file_put_contents('config/database.php', $dbConfig);
        
        return ['success' => true, 'message' => 'فایل‌های پیکربندی ایجاد شدند'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
    }
}

function createAdmin($data) {
    try {
        $dbConfig = $_SESSION['db_config'];
        $dsn = "mysql:host={$dbConfig['db_host']};dbname={$dbConfig['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbConfig['db_username'], $dbConfig['db_password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // ایجاد جداول
        $sql = file_get_contents('database/schema.sql');
        $pdo->exec($sql);
        
        // ایجاد جداول ماژول‌ها
        if (file_exists('database/modules.sql')) {
            $sql = file_get_contents('database/modules.sql');
            $pdo->exec($sql);
        }
        
        // ایجاد جداول امنیتی
        if (file_exists('database/login_attempts.sql')) {
            $sql = file_get_contents('database/login_attempts.sql');
            $pdo->exec($sql);
        }
        
        // ایجاد کاربر ادمین
        $hashedPassword = password_hash($data['admin_password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password, role, first_name, last_name, status, created_at) 
            VALUES (?, ?, ?, 'admin', ?, ?, 'active', NOW())
        ");
        $stmt->execute([
            $data['admin_username'],
            $data['admin_email'],
            $hashedPassword,
            $data['admin_first_name'],
            $data['admin_last_name']
        ]);
        
        // ایجاد تنظیمات سایت
        $siteConfig = $_SESSION['site_config'];
        $settings = [
            'site_name' => $siteConfig['site_name'],
            'site_description' => $siteConfig['site_description'],
            'theme' => 'default',
            'language' => 'fa',
            'timezone' => 'Asia/Tehran'
        ];
        
        foreach ($settings as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)");
            $stmt->execute([$key, $value]);
        }
        
        // ایجاد فایل .installed
        file_put_contents('.installed', date('Y-m-d H:i:s'));
        
        return ['success' => true, 'message' => 'نصب با موفقیت انجام شد'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نصب Dima CMS</title>
    <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="styles/bootstrap-icons.css" rel="stylesheet">
    <style>
        .install-container {
            max-width: 800px;
            margin: 50px auto;
        }
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        .step {
            flex: 1;
            text-align: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            margin: 0 5px;
        }
        .step.active {
            background: #007bff;
            color: white;
        }
        .step.completed {
            background: #28a745;
            color: white;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container install-container">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h2 class="mb-0">
                    <i class="bi bi-gear"></i> نصب Dima CMS
                </h2>
            </div>
            <div class="card-body">
                <!-- Step Indicator -->
                <div class="step-indicator">
                    <div class="step <?php echo $step === 'welcome' ? 'active' : ''; ?>">
                        <i class="bi bi-house"></i> خوش‌آمدگویی
                    </div>
                    <div class="step <?php echo $step === 'requirements' ? 'active' : ($step === 'database' || $step === 'config' || $step === 'admin' || $step === 'complete' ? 'completed' : ''); ?>">
                        <i class="bi bi-check-circle"></i> نیازمندی‌ها
                    </div>
                    <div class="step <?php echo $step === 'database' ? 'active' : ($step === 'config' || $step === 'admin' || $step === 'complete' ? 'completed' : ''); ?>">
                        <i class="bi bi-database"></i> پایگاه داده
                    </div>
                    <div class="step <?php echo $step === 'config' ? 'active' : ($step === 'admin' || $step === 'complete' ? 'completed' : ''); ?>">
                        <i class="bi bi-gear"></i> تنظیمات
                    </div>
                    <div class="step <?php echo $step === 'admin' ? 'active' : ($step === 'complete' ? 'completed' : ''); ?>">
                        <i class="bi bi-person"></i> ادمین
                    </div>
                    <div class="step <?php echo $step === 'complete' ? 'active' : ''; ?>">
                        <i class="bi bi-check"></i> تکمیل
                    </div>
                </div>

                <!-- Error/Success Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>

                <!-- Step Content -->
                <?php if ($step === 'welcome'): ?>
                    <div class="text-center">
                        <h3>خوش آمدید به Dima CMS</h3>
                        <p class="lead">این نصاب شما را در نصب Dima CMS راهنمایی می‌کند.</p>
                        <div class="row mt-4">
                            <div class="col-md-4">
                                <i class="bi bi-shield-check text-primary" style="font-size: 2rem;"></i>
                                <h5>امنیت بالا</h5>
                                <p class="text-muted">سیستم امنیتی پیشرفته</p>
                            </div>
                            <div class="col-md-4">
                                <i class="bi bi-phone text-success" style="font-size: 2rem;"></i>
                                <h5>ریسپانسیو</h5>
                                <p class="text-muted">طراحی مدرن و کاربرپسند</p>
                            </div>
                            <div class="col-md-4">
                                <i class="bi bi-puzzle text-info" style="font-size: 2rem;"></i>
                                <h5>ماژولار</h5>
                                <p class="text-muted">قابلیت گسترش آسان</p>
                            </div>
                        </div>
                        <a href="install.php?step=requirements" class="btn btn-primary btn-lg mt-4">
                            <i class="bi bi-arrow-left"></i> شروع نصب
                        </a>
                    </div>

                <?php elseif ($step === 'requirements'): ?>
                    <h3>بررسی نیازمندی‌ها</h3>
                    <p>سیستم نیازمندی‌های سرور را بررسی می‌کند:</p>
                    
                    <?php $requirements = checkRequirements(); ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>نیازمندی</th>
                                    <th>وضعیت</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requirements as $requirement => $status): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($requirement); ?></td>
                                        <td>
                                            <?php if ($status): ?>
                                                <span class="badge bg-success">
                                                    <i class="bi bi-check"></i> OK
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">
                                                    <i class="bi bi-x"></i> خطا
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if (array_search(false, $requirements) === false): ?>
                        <div class="alert alert-success">
                            <i class="bi bi-check-circle"></i> تمام نیازمندی‌ها برآورده شده‌اند.
                        </div>
                        <form method="post">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-arrow-left"></i> ادامه
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle"></i> برخی نیازمندی‌ها برآورده نشده‌اند. لطفاً آنها را برطرف کنید.
                        </div>
                    <?php endif; ?>

                <?php elseif ($step === 'database'): ?>
                    <h3>تنظیمات پایگاه داده</h3>
                    <p>اطلاعات اتصال به پایگاه داده را وارد کنید:</p>
                    
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="db_host" class="form-label">میزبان پایگاه داده</label>
                                    <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="db_port" class="form-label">پورت</label>
                                    <input type="text" class="form-control" id="db_port" name="db_port" value="3306" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="db_name" class="form-label">نام پایگاه داده</label>
                                    <input type="text" class="form-control" id="db_name" name="db_name" value="dima_cms" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="db_username" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="db_username" name="db_username" value="root" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="db_password" class="form-label">رمز عبور</label>
                            <input type="password" class="form-control" id="db_password" name="db_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-arrow-left"></i> تست اتصال و ادامه
                        </button>
                    </form>

                <?php elseif ($step === 'config'): ?>
                    <h3>تنظیمات سایت</h3>
                    <p>اطلاعات اصلی سایت را وارد کنید:</p>
                    
                    <form method="post">
                        <div class="mb-3">
                            <label for="site_name" class="form-label">نام سایت</label>
                            <input type="text" class="form-control" id="site_name" name="site_name" value="Dima CMS" required>
                        </div>
                        <div class="mb-3">
                            <label for="site_description" class="form-label">توضیحات سایت</label>
                            <textarea class="form-control" id="site_description" name="site_description" rows="3">سیستم مدیریت محتوای مدرن و امن</textarea>
                        </div>
                        <div class="mb-3">
                            <label for="site_url" class="form-label">آدرس سایت</label>
                            <input type="url" class="form-control" id="site_url" name="site_url" value="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-arrow-left"></i> ادامه
                        </button>
                    </form>

                <?php elseif ($step === 'admin'): ?>
                    <h3>ایجاد کاربر ادمین</h3>
                    <p>اطلاعات کاربر اصلی سیستم را وارد کنید:</p>
                    
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="admin_username" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="admin_username" name="admin_username" value="admin" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="admin_email" class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" id="admin_email" name="admin_email" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="admin_first_name" class="form-label">نام</label>
                                    <input type="text" class="form-control" id="admin_first_name" name="admin_first_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="admin_last_name" class="form-label">نام خانوادگی</label>
                                    <input type="text" class="form-control" id="admin_last_name" name="admin_last_name" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="admin_password" class="form-label">رمز عبور</label>
                            <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                            <div class="form-text">حداقل 8 کاراکتر شامل حروف و اعداد</div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-arrow-left"></i> تکمیل نصب
                        </button>
                    </form>

                <?php elseif ($step === 'complete'): ?>
                    <div class="text-center">
                        <i class="bi bi-check-circle text-success" style="font-size: 4rem;"></i>
                        <h3 class="mt-3">نصب با موفقیت انجام شد!</h3>
                        <p class="lead">Dima CMS با موفقیت نصب و پیکربندی شد.</p>
                        
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5><i class="bi bi-globe"></i> سایت اصلی</h5>
                                        <p>برای مشاهده سایت اصلی کلیک کنید</p>
                                        <a href="index.php" class="btn btn-primary">مشاهده سایت</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5><i class="bi bi-gear"></i> پنل مدیریت</h5>
                                        <p>برای مدیریت سایت وارد شوید</p>
                                        <a href="admin/" class="btn btn-success">ورود به پنل</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning mt-4">
                            <i class="bi bi-exclamation-triangle"></i>
                            <strong>نکته امنیتی:</strong> فایل install.php را حذف کنید.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="scripts/bootstrap.bundle.min.js"></script>
</body>
</html> 