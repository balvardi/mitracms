-- جدول ثبت تلاش‌های ورود
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` datetime NOT NULL,
  `user_agent` text,
  PRIMARY KEY (`id`),
  KEY `idx_username_time` (`username`, `attempt_time`),
  KEY `idx_ip_time` (`ip_address`, `attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- اضافه کردن فیلدهای امنیتی به جدول users
ALTER TABLE `users` 
ADD COLUMN `login_ip` varchar(45) NULL AFTER `last_login`,
ADD COLUMN `failed_attempts` int(11) NOT NULL DEFAULT 0 AFTER `login_ip`,
ADD COLUMN `locked_until` datetime NULL AFTER `failed_attempts`,
ADD COLUMN `password_changed_at` datetime NULL AFTER `locked_until`;

-- ایجاد ایندکس برای بهبود عملکرد
CREATE INDEX `idx_users_status` ON `users` (`status`);
CREATE INDEX `idx_users_role` ON `users` (`role`);
CREATE INDEX `idx_users_email` ON `users` (`email`); 