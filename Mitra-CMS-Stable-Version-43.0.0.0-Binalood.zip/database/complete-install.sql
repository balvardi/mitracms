-- Mitra CMS - Complete Database Installation
-- نصب کامل پایگاه داده میترا سی‌ام‌اس

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- حذف پایگاه داده در صورت وجود
DROP DATABASE IF EXISTS mitra_cms;

-- ایجاد پایگاه داده جدید
CREATE DATABASE mitra_cms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mitra_cms;

-- جدول کاربران
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    role ENUM('admin', 'editor', 'author', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    avatar VARCHAR(255),
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

-- جدول دسته‌بندی‌ها
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_id INT NULL,
    sort_order INT DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- جدول صفحات
CREATE TABLE pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content LONGTEXT,
    excerpt TEXT,
    status ENUM('published', 'draft', 'private') DEFAULT 'draft',
    author_id INT,
    template VARCHAR(100) DEFAULT 'default',
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords TEXT,
    featured_image VARCHAR(255),
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول مطالب (برای بلاگ)
CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content LONGTEXT,
    excerpt TEXT,
    status ENUM('published', 'draft', 'private') DEFAULT 'draft',
    author_id INT,
    category_id INT,
    featured_image VARCHAR(255),
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords TEXT,
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    published_at TIMESTAMP NULL,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- جدول نظرات
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    author_email VARCHAR(100) NOT NULL,
    author_website VARCHAR(255),
    content TEXT NOT NULL,
    status ENUM('approved', 'pending', 'spam', 'trash') DEFAULT 'pending',
    parent_id INT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- جدول رسانه
CREATE TABLE media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_size INT NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    alt_text VARCHAR(255),
    caption TEXT,
    description TEXT,
    uploaded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول منوها
CREATE TABLE menus (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(50) NOT NULL,
    items LONGTEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول ماژول‌ها/پلاگین‌ها
CREATE TABLE modules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    version VARCHAR(20) DEFAULT '1.0.0',
    status ENUM('active', 'inactive') DEFAULT 'inactive',
    config LONGTEXT,
    author VARCHAR(100),
    website VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY name (name)
);

-- جدول تگ‌ها
CREATE TABLE tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY slug (slug)
);

-- جدول رابطه مطالب و تگ‌ها
CREATE TABLE post_tags (
    post_id INT NOT NULL,
    tag_id INT NOT NULL,
    PRIMARY KEY (post_id, tag_id),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

-- جدول تنظیمات
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value LONGTEXT,
    setting_type ENUM('text', 'textarea', 'number', 'boolean', 'json') DEFAULT 'text',
    description TEXT,
    group_name VARCHAR(50) DEFAULT 'general',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول فرم‌ها (برای پلاگین فرم ساز)
CREATE TABLE forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    fields LONGTEXT NOT NULL,
    settings LONGTEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول ارسال‌های فرم
CREATE TABLE form_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    data LONGTEXT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    status ENUM('new', 'read', 'replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
);

-- جدول محصولات (برای پلاگین فروشگاه)
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description LONGTEXT,
    short_description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    sale_price DECIMAL(10,2) NULL,
    sku VARCHAR(100),
    stock_quantity INT DEFAULT 0,
    manage_stock BOOLEAN DEFAULT FALSE,
    in_stock BOOLEAN DEFAULT TRUE,
    weight DECIMAL(8,2),
    dimensions VARCHAR(100),
    category_id INT,
    featured_image VARCHAR(255),
    gallery LONGTEXT,
    status ENUM('published', 'draft', 'private') DEFAULT 'draft',
    featured BOOLEAN DEFAULT FALSE,
    meta_title VARCHAR(255),
    meta_description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- جدول سفارشات
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    user_id INT,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(3) DEFAULT 'IRR',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    billing_info LONGTEXT,
    shipping_info LONGTEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- جدول آیتم‌های سفارش
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10,2) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- جدول گالری (برای پلاگین گالری)
CREATE TABLE galleries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    images LONGTEXT,
    settings LONGTEXT,
    status ENUM('published', 'draft', 'private') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول اسلایدر
CREATE TABLE sliders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slides LONGTEXT NOT NULL,
    settings LONGTEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول خبرنامه
CREATE TABLE newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(100),
    status ENUM('active', 'inactive', 'unsubscribed') DEFAULT 'active',
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    unsubscribed_at TIMESTAMP NULL
);

-- جدول لاگ‌ها
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- درج داده‌های اولیه

-- کاربر مدیر (رمز عبور: secret)
INSERT INTO users (username, email, password, first_name, last_name, role, status) VALUES
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدیر', 'سیستم', 'admin', 'active');

-- تنظیمات پایه
INSERT INTO settings (setting_key, setting_value, setting_type, description, group_name) VALUES
('site_name', 'Mitra CMS', 'text', 'نام سایت', 'general'),
('site_description', 'سیستم مدیریت محتوای میترا', 'textarea', 'توضیحات سایت', 'general'),
('site_url', 'http://localhost', 'text', 'آدرس سایت', 'general'),
('admin_email', 'admin@example.com', 'text', 'ایمیل مدیر', 'general'),
('timezone', 'Asia/Tehran', 'text', 'منطقه زمانی', 'general'),
('date_format', 'Y-m-d', 'text', 'فرمت تاریخ', 'general'),
('time_format', 'H:i:s', 'text', 'فرمت زمان', 'general'),
('posts_per_page', '10', 'number', 'تعداد پست در هر صفحه', 'reading'),
('comments_enabled', '1', 'boolean', 'فعال بودن نظرات', 'discussion'),
('comment_moderation', '1', 'boolean', 'تأیید نظرات', 'discussion'),
('theme', 'default', 'text', 'قالب فعال', 'appearance'),
('language', 'fa', 'text', 'زبان پیش‌فرض', 'general'),
('maintenance_mode', '0', 'boolean', 'حالت تعمیر', 'general'),
('user_registration', '1', 'boolean', 'امکان ثبت نام', 'general');

-- دسته‌بندی‌های پیش‌فرض
INSERT INTO categories (name, slug, description, status) VALUES
('عمومی', 'general', 'دسته‌بندی عمومی', 'active'),
('اخبار', 'news', 'اخبار و رویدادها', 'active'),
('آموزش', 'tutorial', 'مطالب آموزشی', 'active'),
('محصولات', 'products', 'دسته‌بندی محصولات', 'active');

-- صفحات پیش‌فرض
INSERT INTO pages (title, slug, content, status, author_id, template) VALUES
('صفحه اصلی', 'home', '<h1>به سیستم مدیریت محتوای میترا خوش آمدید</h1><p>این صفحه اصلی سایت شماست.</p>', 'published', 1, 'home'),
('درباره ما', 'about', '<h1>درباره ما</h1><p>اطلاعات درباره سازمان یا شرکت شما.</p>', 'published', 1, 'default'),
('تماس با ما', 'contact', '<h1>تماس با ما</h1><p>راه‌های ارتباط با ما.</p>', 'published', 1, 'contact'),
('حریم خصوصی', 'privacy', '<h1>سیاست حریم خصوصی</h1><p>سیاست حریم خصوصی سایت.</p>', 'published', 1, 'default');

-- مطالب نمونه
INSERT INTO posts (title, slug, content, excerpt, status, author_id, category_id, published_at) VALUES
('خوش آمدید به میترا CMS', 'welcome-to-mitra-cms', '<p>این اولین پست شما در سیستم مدیریت محتوای میترا است. می‌توانید آن را ویرایش یا حذف کنید.</p>', 'اولین پست در سیستم مدیریت محتوای میترا', 'published', 1, 1, NOW()),
('راهنمای شروع کار', 'getting-started-guide', '<p>در این راهنما نحوه استفاده از امکانات مختلف سیستم را یاد خواهید گرفت.</p>', 'راهنمای کامل برای شروع کار با سیستم', 'published', 1, 3, NOW());

-- منوی اصلی
INSERT INTO menus (name, location, items, status) VALUES
('منوی اصلی', 'header', '[{"title":"صفحه اصلی","url":"/","type":"page"},{"title":"درباره ما","url":"/page/about","type":"page"},{"title":"تماس با ما","url":"/page/contact","type":"page"}]', 'active');

-- تگ‌های نمونه
INSERT INTO tags (name, slug) VALUES
('میترا', 'mitra'),
('سی‌ام‌اس', 'cms'),
('راهنما', 'guide'),
('شروع', 'start');

-- رابطه مطالب و تگ‌ها
INSERT INTO post_tags (post_id, tag_id) VALUES
(1, 1), (1, 2),
(2, 1), (2, 3), (2, 4);

-- ماژول‌های پیش‌فرض
INSERT INTO modules (name, display_name, description, version, status, config, author) VALUES
('blog', 'سیستم وبلاگ', 'ماژول مدیریت مطالب و وبلاگ', '1.0.0', 'active', '{"posts_per_page":10,"allow_comments":true}', 'Mitra CMS Team'),
('contact_form', 'فرم تماس', 'ماژول ایجاد و مدیریت فرم‌های تماس', '1.0.0', 'active', '{"email_notifications":true,"save_submissions":true}', 'Mitra CMS Team'),
('gallery', 'گالری تصاویر', 'ماژول نمایش گالری تصاویر', '1.0.0', 'inactive', '{"thumbnail_size":"medium","lightbox":true}', 'Mitra CMS Team'),
('ecommerce', 'فروشگاه آنلاین', 'ماژول فروشگاه و تجارت الکترونیک', '1.0.0', 'inactive', '{"currency":"IRR","payment_gateway":"zarinpal"}', 'Mitra CMS Team'),
('slider', 'اسلایدر', 'ماژول نمایش اسلایدر تصاویر', '1.0.0', 'inactive', '{"autoplay":true,"duration":5000}', 'Mitra CMS Team'),
('newsletter', 'خبرنامه', 'ماژول مدیریت خبرنامه و مشترکین', '1.0.0', 'inactive', '{"double_opt_in":true,"welcome_email":true}', 'Mitra CMS Team');

-- فرم تماس نمونه
INSERT INTO forms (name, title, description, fields, settings, status) VALUES
('contact', 'فرم تماس با ما', 'فرم اصلی تماس با ما', 
'[{"name":"name","label":"نام و نام خانوادگی","type":"text","required":true},{"name":"email","label":"ایمیل","type":"email","required":true},{"name":"subject","label":"موضوع","type":"text","required":true},{"name":"message","label":"پیام","type":"textarea","required":true}]',
'{"email_to":"admin@example.com","success_message":"پیام شما با موفقیت ارسال شد","redirect_url":""}',
'active');

-- محصولات نمونه
INSERT INTO products (name, slug, description, short_description, price, sku, stock_quantity, category_id, status) VALUES
('محصول نمونه 1', 'sample-product-1', '<p>توضیحات کامل محصول نمونه اول</p>', 'محصول نمونه برای تست سیستم', 100000.00, 'SP001', 10, 4, 'published'),
('محصول نمونه 2', 'sample-product-2', '<p>توضیحات کامل محصول نمونه دوم</p>', 'محصول نمونه دیگر برای تست', 150000.00, 'SP002', 5, 4, 'published');

-- گالری نمونه
INSERT INTO galleries (title, slug, description, images, status) VALUES
('گالری نمونه', 'sample-gallery', 'گالری تصاویر نمونه', '[]', 'published');

-- اسلایدر نمونه
INSERT INTO sliders (title, slides, settings, status) VALUES
('اسلایدر اصلی', '[{"title":"اسلاید اول","description":"توضیحات اسلاید اول","image":"","link":""}]', '{"autoplay":true,"duration":5000}', 'active');

-- ایجاد ایندکس‌ها برای بهبود عملکرد
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);

CREATE INDEX idx_pages_slug ON pages(slug);
CREATE INDEX idx_pages_status ON pages(status);
CREATE INDEX idx_pages_author ON pages(author_id);

CREATE INDEX idx_posts_slug ON posts(slug);
CREATE INDEX idx_posts_status ON posts(status);
CREATE INDEX idx_posts_author ON posts(author_id);
CREATE INDEX idx_posts_category ON posts(category_id);
CREATE INDEX idx_posts_published ON posts(published_at);

CREATE INDEX idx_comments_post ON comments(post_id);
CREATE INDEX idx_comments_status ON comments(status);
CREATE INDEX idx_comments_parent ON comments(parent_id);

CREATE INDEX idx_categories_slug ON categories(slug);
CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_status ON categories(status);

CREATE INDEX idx_media_type ON media(mime_type);
CREATE INDEX idx_media_uploader ON media(uploaded_by);

CREATE INDEX idx_settings_key ON settings(setting_key);
CREATE INDEX idx_settings_group ON settings(group_name);

CREATE INDEX idx_products_slug ON products(slug);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_products_category ON products(category_id);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_number ON orders(order_number);

COMMIT;

-- پیام موفقیت
SELECT 'نصب با موفقیت انجام شد!' as message;
SELECT 'اطلاعات ورود:' as info;
SELECT 'نام کاربری: admin' as username;
SELECT 'رمز عبور: secret' as password;
