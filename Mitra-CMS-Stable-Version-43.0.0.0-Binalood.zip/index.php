<?php
// فایل اصلی سایت
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

try {
    require_once 'config/connection.php';
    
    // بررسی وجود فایل‌های قالب
    $theme = $settings['theme'] ?? 'default';
    $headerFile = "templates/$theme/header.php";
    $homeFile = "templates/$theme/home.php";
    $footerFile = "templates/$theme/footer.php";
    
    // بارگذاری هدر
    if (file_exists($headerFile)) {
        require_once $headerFile;
    } else {
        // هدر ساده در صورت عدم وجود فایل
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dima CMS</title>
            <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
            <link href="styles/bootstrap-icons.css" rel="stylesheet">
        </head>
        <body>
        <?php
    }
    
    // بارگذاری صفحه اصلی
    if (file_exists($homeFile)) {
        require_once $homeFile;
    } else {
        // صفحه اصلی ساده
        ?>
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 mx-auto text-center">
                    <h1>خوش آمدید به Dima CMS</h1>
                    <p class="lead">سیستم مدیریت محتوای مدرن و امن</p>
                    <div class="mt-4">
                        <a href="auth.php" class="btn btn-primary me-2">ورود</a>
                        <a href="admin/" class="btn btn-outline-primary">پنل مدیریت</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    // بارگذاری فوتر
    if (file_exists($footerFile)) {
        require_once $footerFile;
    } else {
        // فوتر ساده
        ?>
        <script src="scripts/bootstrap.bundle.min.js"></script>
        </body>
        </html>
        <?php
    }
    
} catch (Exception $e) {
    // نمایش خطا در صورت وجود مشکل
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>خطا - Dima CMS</title>
        <link href="styles/bootstrap.rtl.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container mt-5">
            <div class="alert alert-danger">
                <h4>خطا در بارگذاری سایت</h4>
                <p><?php echo htmlspecialchars($e->getMessage()); ?></p>
                <hr>
                <p><strong>برای رفع مشکل:</strong></p>
                <ul>
                    <li>فایل <code>config/database.php</code> را بررسی کنید</li>
                    <li>اتصال به پایگاه داده را بررسی کنید</li>
                    <li>فایل <a href="test-connection.php">test-connection.php</a> را اجرا کنید</li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    <?php
}
?>

