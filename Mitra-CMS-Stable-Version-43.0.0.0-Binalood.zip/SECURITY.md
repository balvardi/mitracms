# راهنمای امنیتی Dima CMS

## 🔒 اقدامات امنیتی پیاده‌سازی شده

### 1. **محافظت از اطلاعات حساس**
- استفاده از متغیرهای محیطی برای تنظیمات پایگاه داده
- فایل `.env` برای ذخیره اطلاعات حساس
- محافظت از فایل‌های پیکربندی با `.htaccess`
- فایل‌های حساس خارج از web root

### 2. **امنیت جلسه (Session Security)**
- تنظیم `HttpOnly` برای کوکی‌های جلسه
- تنظیم `Secure` برای کوکی‌ها در HTTPS
- تنظیم `SameSite=Strict` برای جلوگیری از CSRF
- انقضای خودکار جلسه پس از 1 ساعت
- بازسازی ID جلسه پس از ورود موفق
- بررسی تغییر IP در طول جلسه

### 3. **محافظت از حملات**
- **CSRF Protection**: استفاده از توکن‌های CSRF در تمام فرم‌ها
- **XSS Protection**: پاکسازی ورودی‌ها با `htmlspecialchars`
- **SQL Injection Protection**: استفاده از Prepared Statements
- **Path Traversal Protection**: بررسی مسیرهای فایل
- **File Upload Security**: بررسی نوع و محتوای فایل‌ها
- **Open Redirect Protection**: بررسی URL های redirect

### 4. **محدودیت تلاش ورود**
- حداکثر 5 تلاش ورود در 15 دقیقه
- قفل حساب کاربری پس از تلاش‌های ناموفق
- ثبت تمام تلاش‌های ورود در پایگاه داده
- پاکسازی خودکار تلاش‌های قدیمی

### 5. **HTTP Security Headers**
```apache
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: default-src 'self'
Permissions-Policy: geolocation=(), microphone=(), camera=()
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

### 6. **امنیت آپلود فایل**
- بررسی نوع MIME فایل
- محدودیت اندازه فایل (5MB)
- محدودیت ابعاد تصویر (4000x4000)
- تولید نام فایل امن
- بررسی محتوای فایل
- تنظیم مجوزهای امن فایل

### 7. **Rate Limiting**
- محدودیت تعداد درخواست‌ها
- محدودیت آپلود فایل (10 در دقیقه)
- محدودیت ورود (5 در 5 دقیقه)

### 8. **لاگ امنیتی**
- ثبت تمام رویدادهای امنیتی
- لاگ تلاش‌های ورود
- لاگ آپلود فایل‌ها
- لاگ خطاهای امنیتی

## 🛡️ راهنمای نصب امن

### 1. **تنظیمات سرور**
```bash
# تنظیم مجوزهای فایل
chmod 755 uploads/
chmod 644 config/database.php
chmod 644 .env

# ایجاد پوشه لاگ
mkdir logs
chmod 755 logs
```

### 2. **تنظیمات پایگاه داده**
```sql
-- ایجاد جداول امنیتی
CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    attempt_time DATETIME NOT NULL,
    user_agent TEXT
);

-- اضافه کردن فیلدهای امنیتی به جدول users
ALTER TABLE users 
ADD COLUMN login_ip VARCHAR(45) NULL,
ADD COLUMN failed_attempts INT(11) NOT NULL DEFAULT 0,
ADD COLUMN locked_until DATETIME NULL,
ADD COLUMN password_changed_at DATETIME NULL;
```

### 3. **تنظیمات فایل .env**
```ini
# تنظیمات پایگاه داده
DB_HOST=localhost
DB_PORT=3306
DB_NAME=dima_cms
DB_USER=dima_user
DB_PASS=your_secure_password

# تنظیمات امنیتی
APP_SECRET=your_random_secret_key_here
SESSION_SECRET=your_session_secret_here

# تنظیمات آپلود
MAX_FILE_SIZE=5242880
UPLOAD_PATH=uploads

# تنظیمات امنیتی اضافی
ENABLE_HTTPS=true
DEBUG_MODE=false
RESTRICT_LOGIN_IPS=false
ALLOWED_IPS=
```

## 🔍 بررسی‌های امنیتی منظم

### 1. **بررسی لاگ‌ها**
```bash
# بررسی لاگ امنیتی
tail -f logs/security.log

# بررسی لاگ درخواست‌ها
tail -f logs/requests.log

# بررسی لاگ خطاهای PHP
tail -f /var/log/php_errors.log
```

### 2. **بررسی فایل‌های سیستم**
```bash
# بررسی مجوزهای فایل
find . -type f -exec ls -la {} \;

# بررسی فایل‌های قابل اجرا
find . -type f -executable

# بررسی فایل‌های حساس
find . -name "*.env" -o -name "*.sql" -o -name "*.log"
```

### 3. **بررسی پایگاه داده**
```sql
-- بررسی تلاش‌های ورود ناموفق
SELECT * FROM login_attempts WHERE success = 0 ORDER BY attempt_time DESC LIMIT 10;

-- بررسی کاربران غیرفعال
SELECT * FROM users WHERE status != 'active';

-- بررسی فایل‌های آپلود شده
SELECT * FROM uploads ORDER BY uploaded_at DESC LIMIT 10;
```

## 🚨 پاسخ به حوادث امنیتی

### 1. **حمله Brute Force**
```sql
-- مسدود کردن IP
INSERT INTO blocked_ips (ip_address, reason, expires_at) 
VALUES ('192.168.1.100', 'Brute force attack', DATE_ADD(NOW(), INTERVAL 24 HOUR);

-- بررسی تلاش‌های مشکوک
SELECT ip_address, COUNT(*) as attempts 
FROM login_attempts 
WHERE success = 0 AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)
GROUP BY ip_address 
HAVING attempts > 10;
```

### 2. **فایل مشکوک**
```bash
# بررسی فایل‌های آپلود شده
find uploads/ -type f -exec file {} \;

# حذف فایل‌های مشکوک
find uploads/ -name "*.php" -delete
find uploads/ -name "*.exe" -delete
```

### 3. **حساب کاربری هک شده**
```sql
-- غیرفعال کردن حساب
UPDATE users SET status = 'inactive' WHERE id = ?;

-- تغییر رمز عبور
UPDATE users SET password = ? WHERE id = ?;

-- بررسی فعالیت‌های مشکوک
SELECT * FROM login_attempts WHERE user_id = ? ORDER BY attempt_time DESC;
```

## 📋 چک‌لیست امنیتی

### ✅ قبل از انتشار
- [ ] فایل `.env` تنظیم شده
- [ ] مجوزهای فایل صحیح
- [ ] HTTPS فعال
- [ ] فایل‌های حساس محافظت شده
- [ ] لاگ‌ها فعال
- [ ] نسخه‌پشتیبان تهیه شده

### ✅ بررسی‌های منظم
- [ ] بررسی لاگ‌های امنیتی
- [ ] بررسی تلاش‌های ورود
- [ ] بررسی فایل‌های آپلود شده
- [ ] بروزرسانی نرم‌افزارها
- [ ] بررسی مجوزهای فایل
- [ ] پاکسازی فایل‌های موقت

### ✅ پس از حادثه
- [ ] مسدود کردن IP های مشکوک
- [ ] تغییر رمزهای عبور
- [ ] بررسی فایل‌های سیستم
- [ ] بررسی لاگ‌ها
- [ ] گزارش به تیم امنیتی
- [ ] مستندسازی حادثه

## 🔧 ابزارهای امنیتی

### 1. **اسکریپت بررسی امنیت**
```bash
#!/bin/bash
# security_check.sh

echo "=== بررسی امنیت Dima CMS ==="

# بررسی فایل‌های حساس
echo "بررسی فایل‌های حساس..."
find . -name ".env" -o -name "database.php" | while read file; do
    if [[ $(stat -c %a "$file") != "644" ]]; then
        echo "⚠️  مجوز نامناسب: $file"
    fi
done

# بررسی پوشه uploads
echo "بررسی پوشه uploads..."
find uploads/ -name "*.php" -o -name "*.exe" | while read file; do
    echo "🚨 فایل مشکوک: $file"
done

# بررسی لاگ‌ها
echo "بررسی لاگ‌های امنیتی..."
if [ -f "logs/security.log" ]; then
    echo "آخرین رویدادهای امنیتی:"
    tail -5 logs/security.log
fi

echo "=== پایان بررسی ==="
```

### 2. **اسکریپت پاکسازی**
```bash
#!/bin/bash
# cleanup.sh

echo "=== پاکسازی سیستم ==="

# پاکسازی فایل‌های موقت
find /tmp -name "dima_*" -delete

# پاکسازی لاگ‌های قدیمی
find logs/ -name "*.log" -mtime +30 -delete

# پاکسازی تلاش‌های ورود قدیمی
mysql -u root -p dima_cms -e "
DELETE FROM login_attempts 
WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 30 DAY);
"

echo "=== پاکسازی کامل شد ==="
```

## 📞 پشتیبانی امنیتی

برای گزارش مشکلات امنیتی:
- ایمیل: security@dima-cms.com
- GitHub Issues: https://github.com/your-username/dima-cms/issues
- فرم گزارش: https://dima-cms.com/security-report

## 📚 منابع بیشتر

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [PHP Security Guide](https://www.php.net/manual/en/security.php)
- [MySQL Security](https://dev.mysql.com/doc/refman/8.0/en/security.html)
- [Apache Security](https://httpd.apache.org/docs/2.4/security/)

---

**نکته مهم:** این راهنما به‌طور منظم بروزرسانی می‌شود. لطفاً آخرین نسخه را بررسی کنید. 