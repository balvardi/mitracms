<?php
/**
 * Mitra CMS - نصاب ساده تک فایل (بدون JavaScript)
 */
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تنظیمات
define('ROOT_DIR', dirname(__DIR__));
define('CONFIG_DIR', ROOT_DIR . '/config');

// ایجاد پوشه‌ها در صورت عدم وجود
if (!is_dir(CONFIG_DIR)) {
    mkdir(CONFIG_DIR, 0755, true);
}
if (!is_dir(ROOT_DIR . '/uploads')) {
    mkdir(ROOT_DIR . '/uploads', 0755, true);
}

// کلاس نصاب
class SimpleInstaller {
    public function checkRequirements() {
        $requirements = [
            'PHP Version >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
            'PDO MySQL Extension' => extension_loaded('pdo_mysql'),
            'mbstring Extension' => extension_loaded('mbstring'),
            'Config Directory Writable' => is_writable(CONFIG_DIR),
            'Storage Directory Writable' => is_writable(ROOT_DIR . '/uploads')
        ];
        
        return $requirements;
    }
    
    public function testDatabase($host, $port, $database, $username, $password) {
        try {
            $dsn = "mysql:host={$host};port={$port};charset=utf8mb4";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // تست ایجاد پایگاه داده
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            return ['success' => true, 'message' => 'اتصال موفقیت‌آمیز'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
        }
    }
    
    public function createConfig($data) {
        try {
            // فایل پیکربندی پایگاه داده
            $dbConfig = "<?php\nreturn [\n";
            $dbConfig .= "    'host' => '{$data['db_host']}',\n";
            $dbConfig .= "    'port' => '{$data['db_port']}',\n";
            $dbConfig .= "    'database' => '{$data['db_name']}',\n";
            $dbConfig .= "    'username' => '{$data['db_username']}',\n";
            $dbConfig .= "    'password' => '{$data['db_password']}',\n";
            $dbConfig .= "    'charset' => 'utf8mb4'\n";
            $dbConfig .= "];\n";
            
            file_put_contents(CONFIG_DIR . '/database.php', $dbConfig);
            
            // فایل پیکربندی اپلیکیشن
            $appConfig = "<?php\nreturn [\n";
            $appConfig .= "    'name' => '{$data['site_title']}',\n";
            $appConfig .= "    'url' => '{$data['site_url']}',\n";
            $appConfig .= "    'timezone' => 'Asia/Tehran',\n";
            $appConfig .= "    'key' => '" . bin2hex(random_bytes(32)) . "'\n";
            $appConfig .= "];\n";
            
            file_put_contents(CONFIG_DIR . '/app.php', $appConfig);
            
            return ['success' => true, 'message' => 'فایل‌های پیکربندی ایجاد شدند'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
        }
    }
    
    public function installDatabase($data) {
        try {
            $dsn = "mysql:host={$data['db_host']};dbname={$data['db_name']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['db_username'], $data['db_password']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // ایجاد جداول
            $sql = "
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'editor', 'user') DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            
            CREATE TABLE IF NOT EXISTS pages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                slug VARCHAR(255) UNIQUE NOT NULL,
                content TEXT,
                status ENUM('draft', 'published') DEFAULT 'draft',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            
            CREATE TABLE IF NOT EXISTS settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                `key` VARCHAR(100) UNIQUE NOT NULL,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ";
            
            $pdo->exec($sql);
            
            // ایجاد کاربر مدیر
            $hashedPassword = password_hash($data['admin_password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
            $stmt->execute([$data['admin_username'], $data['admin_email'], $hashedPassword]);
            
            // تنظیمات پایه
            $settings = [
                ['site_title', $data['site_title']],
                ['site_url', $data['site_url']],
                ['admin_email', $data['admin_email']]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)");
            foreach ($settings as $setting) {
                $stmt->execute($setting);
            }
            
            return ['success' => true, 'message' => 'پایگاه داده نصب شد'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
        }
    }
}

$installer = new SimpleInstaller();
$step = $_GET['step'] ?? 'welcome';
$message = '';
$error = '';

// پردازش فرم‌ها
if ($_POST) {
    switch ($step) {
        case 'requirements':
            $step = 'database';
            break;
            
        case 'database':
            if (isset($_POST['test_db'])) {
                $result = $installer->testDatabase($_POST['db_host'], $_POST['db_port'], $_POST['db_name'], $_POST['db_username'], $_POST['db_password']);
                if ($result['success']) {
                    $message = $result['message'];
                    $_SESSION['db_data'] = $_POST;
                } else {
                    $error = $result['message'];
                }
            } elseif (isset($_POST['next_step'])) {
                $_SESSION['db_data'] = $_POST;
                $step = 'config';
            }
            break;
            
        case 'config':
            $_SESSION['config_data'] = $_POST;
            $step = 'admin';
            break;
            
        case 'admin':
            $_SESSION['admin_data'] = $_POST;
            $step = 'install';
            break;
            
        case 'install':
            $allData = array_merge(
                $_SESSION['db_data'] ?? [],
                $_SESSION['config_data'] ?? [],
                $_SESSION['admin_data'] ?? []
            );
            
            // ایجاد فایل‌های پیکربندی
            $configResult = $installer->createConfig($allData);
            if (!$configResult['success']) {
                $error = $configResult['message'];
                break;
            }
            
            // نصب پایگاه داده
            $dbResult = $installer->installDatabase($allData);
            if (!$dbResult['success']) {
                $error = $dbResult['message'];
                break;
            }
            
            // ایجاد فایل نصب شده
            file_put_contents(ROOT_DIR . '/.installed', date('Y-m-d H:i:s'));
            
            $step = 'complete';
            break;
    }
}

$requirements = $installer->checkRequirements();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نصاب Mitra CMS</title>
    <style>
        * { 
            font-family: "Tahoma", "Arial", sans-serif; 
            box-sizing: border-box;
        }
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            min-height: 100vh; 
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .installer-card { 
            background: white; 
            border-radius: 15px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
        }
        .text-center { text-align: center; }
        .mb-4 { margin-bottom: 30px; }
        .mb-3 { margin-bottom: 20px; }
        .icon {
            font-size: 48px;
            color: #007bff;
            margin-bottom: 20px;
        }
        h2 { color: #333; margin: 0 0 10px 0; }
        h4 { color: #333; margin: 0 0 20px 0; }
        .text-muted { color: #6c757d; }
        
        .step-indicator { 
            background: #f8f9fa; 
            border-radius: 10px; 
            padding: 20px; 
            margin-bottom: 30px; 
        }
        .step-item { 
            display: flex; 
            align-items: center; 
            margin-bottom: 10px; 
        }
        .step-number { 
            width: 30px; 
            height: 30px; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-left: 15px;
            font-weight: bold;
        }
        .step-active { background: #007bff; color: white; }
        .step-completed { background: #28a745; color: white; }
        .step-pending { background: #e9ecef; color: #6c757d; }
        
        .requirement-item { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 15px; 
            border: 1px solid #dee2e6; 
            border-radius: 5px; 
            margin-bottom: 10px; 
        }
        .requirement-pass { 
            border-color: #28a745; 
            background-color: #d4edda; 
        }
        .requirement-fail { 
            border-color: #dc3545; 
            background-color: #f8d7da; 
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .alert-warning {
            background-color: #fff3cd;
            border-color: #ffeaa7;
            color: #856404;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-control:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
        }
        
        .row {
            display: flex;
            margin: 0 -10px;
        }
        .col-md-6 {
            flex: 0 0 50%;
            padding: 0 10px;
        }
        .col-md-4 {
            flex: 0 0 33.333%;
            padding: 0 10px;
        }
        .col-md-8 {
            flex: 0 0 66.666%;
            padding: 0 10px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s;
            margin-left: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        .btn-success:hover {
            background-color: #1e7e34;
        }
        .btn-outline-primary {
            background-color: transparent;
            color: #007bff;
            border: 1px solid #007bff;
        }
        .btn-outline-primary:hover {
            background-color: #007bff;
            color: white;
        }
        .btn-lg {
            padding: 16px 32px;
            font-size: 16px;
        }
        
        .d-flex {
            display: flex;
        }
        .gap-2 {
            gap: 10px;
        }
        .justify-content-center {
            justify-content: center;
        }
        
        .success-icon {
            font-size: 64px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .row {
                flex-direction: column;
            }
            .col-md-4, .col-md-6, .col-md-8 {
                flex: none;
                width: 100%;
                padding: 0;
                margin-bottom: 15px;
            }
            .installer-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="installer-card">
            <div class="text-center mb-4">
                <div class="icon">🏛️</div>
                <h2>نصاب Mitra CMS</h2>
                <p class="text-muted">سیستم مدیریت محتوای قدرتمند</p>
            </div>

            <!-- نمایش پیام‌ها -->
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message) ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <!-- نمایش مراحل -->
            <div class="step-indicator">
                <?php
                $steps = [
                    'welcome' => 'خوش‌آمدید',
                    'requirements' => 'پیش‌نیازها',
                    'database' => 'پایگاه داده',
                    'config' => 'پیکربندی',
                    'admin' => 'کاربر مدیر',
                    'install' => 'نصب',
                    'complete' => 'تکمیل'
                ];
                
                $stepKeys = array_keys($steps);
                $currentIndex = array_search($step, $stepKeys);
                
                foreach ($steps as $key => $title):
                    $index = array_search($key, $stepKeys);
                    $class = $index < $currentIndex ? 'step-completed' : ($index == $currentIndex ? 'step-active' : 'step-pending');
                ?>
                    <div class="step-item">
                        <div class="step-number <?php echo $class ?>">
                            <?php if ($index < $currentIndex): ?>
                                ✓
                            <?php else: ?>
                                <?php echo $index + 1 ?>
                            <?php endif; ?>
                        </div>
                        <span><?php echo $title ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- محتوای مراحل -->
            <?php if ($step == 'welcome'): ?>
                <div class="text-center">
                    <h4>به نصاب Mitra CMS خوش آمدید</h4>
                    <p>این ابزار شما را در نصب سیستم مدیریت محتوا راهنمایی می‌کند.</p>
                    <a href="?step=requirements" class="btn btn-primary btn-lg">شروع نصب</a>
                </div>

            <?php elseif ($step == 'requirements'): ?>
                <h4>بررسی پیش‌نیازها</h4>
                <?php foreach ($requirements as $req => $status): ?>
                    <div class="requirement-item <?php echo $status ? 'requirement-pass' : 'requirement-fail' ?>">
                        <span><?php echo $req ?></span>
                        <span><?php echo $status ? '✓' : '✗' ?></span>
                    </div>
                <?php endforeach; ?>
                
                <?php if (array_product($requirements)): ?>
                    <form method="post">
                        <button type="submit" class="btn btn-primary">ادامه</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-warning">لطفاً ابتدا پیش‌نیازها را برطرف کنید.</div>
                <?php endif; ?>

            <?php elseif ($step == 'database'): ?>
                <h4>تنظیمات پایگاه داده</h4>
                <form method="post">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label class="form-label">آدرس سرور</label>
                                <input type="text" class="form-control" name="db_host" value="<?php echo htmlspecialchars($_SESSION['db_data']['db_host'] ?? 'localhost') ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">پورت</label>
                                <input type="number" class="form-control" name="db_port" value="<?php echo htmlspecialchars($_SESSION['db_data']['db_port'] ?? '3306') ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">نام پایگاه داده</label>
                        <input type="text" class="form-control" name="db_name" value="<?php echo htmlspecialchars($_SESSION['db_data']['db_name'] ?? 'mitracms') ?>" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">نام کاربری</label>
                                <input type="text" class="form-control" name="db_username" value="<?php echo htmlspecialchars($_SESSION['db_data']['db_username'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">رمز عبور</label>
                                <input type="password" class="form-control" name="db_password" value="<?php echo htmlspecialchars($_SESSION['db_data']['db_password'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="test_db" class="btn btn-outline-primary">تست اتصال</button>
                        <button type="submit" name="next_step" class="btn btn-primary">ادامه</button>
                    </div>
                </form>

            <?php elseif ($step == 'config'): ?>
                <h4>پیکربندی سایت</h4>
                <form method="post">
                    <div class="form-group">
                        <label class="form-label">عنوان سایت</label>
                        <input type="text" class="form-control" name="site_title" value="<?php echo htmlspecialchars($_SESSION['config_data']['site_title'] ?? 'Mitra CMS') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">آدرس سایت</label>
                        <input type="url" class="form-control" name="site_url" value="<?php echo htmlspecialchars($_SESSION['config_data']['site_url'] ?? 'http://localhost') ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">ادامه</button>
                </form>

            <?php elseif ($step == 'admin'): ?>
                <h4>ایجاد کاربر مدیر</h4>
                <form method="post">
                    <div class="form-group">
                        <label class="form-label">نام کاربری</label>
                        <input type="text" class="form-control" name="admin_username" value="<?php echo htmlspecialchars($_SESSION['admin_data']['admin_username'] ?? 'admin') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">ایمیل</label>
                        <input type="email" class="form-control" name="admin_email" value="<?php echo htmlspecialchars($_SESSION['admin_data']['admin_email'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">رمز عبور</label>
                        <input type="password" class="form-control" name="admin_password" required minlength="6">
                    </div>
                    <button type="submit" class="btn btn-primary">ادامه</button>
                </form>

            <?php elseif ($step == 'install'): ?>
                <h4>آماده نصب</h4>
                <p>همه چیز آماده است. برای شروع نصب کلیک کنید.</p>
                <form method="post">
                    <button type="submit" class="btn btn-success btn-lg">شروع نصب</button>
                </form>

            <?php elseif ($step == 'complete'): ?>
                <div class="text-center">
                    <div class="success-icon">✅</div>
                    <h4>نصب تکمیل شد!</h4>
                    <p>Mitra CMS با موفقیت نصب شد.</p>
                    <div class="d-flex gap-2 justify-content-center">
                        <a href="../index.php" class="btn btn-primary">مشاهده سایت</a>
                        <a href="../admin" class="btn btn-outline-primary">پنل مدیریت</a>
                    </div>
                    <div class="alert alert-warning">
                        <strong>مهم:</strong> پوشه install را از سرور حذف کنید.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
