<?php
/**
 * کلاس نصاب Mitra CMS
 */

// بررسی session فقط در صورت عدم وجود
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

class Installer {
    private $config;
    private $steps = [
        'welcome' => 'خوش‌آمدید',
        'requirements' => 'بررسی پیش‌نیازها',
        'database' => 'پایگاه داده',
        'config' => 'پیکربندی',
        'admin' => 'کاربر مدیر',
        'install' => 'نصب',
        'complete' => 'تکمیل'
    ];
    
    public function __construct() {
        $this->config = [
            'root_dir' => dirname(dirname(__DIR__)),
            'config_dir' => dirname(dirname(__DIR__)) . '/config',
            'uploads_dir' => dirname(dirname(__DIR__)) . '/uploads'
        ];
        
        // ایجاد پوشه‌های مورد نیاز
        $this->createDirectories();
    }
    
    private function createDirectories() {
        $dirs = [
            $this->config['config_dir'],
            $this->config['uploads_dir'],
            $this->config['uploads_dir'] . '/uploads',
            $this->config['uploads_dir'] . '/cache',
            $this->config['uploads_dir'] . '/logs'
        ];
        
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }
    
    public function getSteps() {
        return $this->steps;
    }
    
    public function getCurrentStep() {
        return $_GET['step'] ?? 'welcome';
    }
    
    public function checkRequirements() {
        return [
            'PHP Version >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
            'PDO Extension' => extension_loaded('pdo'),
            'PDO MySQL Extension' => extension_loaded('pdo_mysql'),
            'mbstring Extension' => extension_loaded('mbstring'),
            'JSON Extension' => extension_loaded('json'),
            'cURL Extension' => extension_loaded('curl'),
            'GD Extension' => extension_loaded('gd'),
            'Config Directory Writable' => is_writable($this->config['config_dir']),
            'Storage Directory Writable' => is_writable($this->config['uploads_dir']),
            'Root Directory Writable' => is_writable($this->config['root_dir'])
        ];
    }
    
    public function testDatabaseConnection($host, $port, $database, $username, $password) {
        try {
            $dsn = "mysql:host={$host};port={$port};charset=utf8mb4";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // تست ایجاد پایگاه داده
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            // تست اتصال به پایگاه داده
            $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4";
            $testPdo = new PDO($dsn, $username, $password);
            $testPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            return ['success' => true, 'message' => 'اتصال به پایگاه داده موفقیت‌آمیز بود'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'خطا در اتصال: ' . $e->getMessage()];
        }
    }
    
    public function createConfigFiles($data) {
        try {
            // فایل پیکربندی پایگاه داده
            $dbConfig = "<?php\n";
            $dbConfig .= "return [\n";
            $dbConfig .= "    'host' => '" . addslashes($data['db_host']) . "',\n";
            $dbConfig .= "    'port' => '" . addslashes($data['db_port']) . "',\n";
            $dbConfig .= "    'database' => '" . addslashes($data['db_name']) . "',\n";
            $dbConfig .= "    'username' => '" . addslashes($data['db_username']) . "',\n";
            $dbConfig .= "    'password' => '" . addslashes($data['db_password']) . "',\n";
            $dbConfig .= "    'charset' => 'utf8mb4',\n";
            $dbConfig .= "    'collation' => 'utf8mb4_unicode_ci',\n";
            $dbConfig .= "    'prefix' => ''\n";
            $dbConfig .= "];\n";
            
            file_put_contents($this->config['config_dir'] . '/database.php', $dbConfig);
            
            // فایل پیکربندی اپلیکیشن
            $appConfig = "<?php\n";
            $appConfig .= "return [\n";
            $appConfig .= "    'name' => '" . addslashes($data['site_title']) . "',\n";
            $appConfig .= "    'url' => '" . addslashes($data['site_url']) . "',\n";
            $appConfig .= "    'timezone' => 'Asia/Tehran',\n";
            $appConfig .= "    'locale' => 'fa',\n";
            $appConfig .= "    'key' => '" . bin2hex(random_bytes(32)) . "',\n";
            $appConfig .= "    'debug' => false,\n";
            $appConfig .= "    'maintenance' => false\n";
            $appConfig .= "];\n";
            
            file_put_contents($this->config['config_dir'] . '/app.php', $appConfig);
            
            return ['success' => true, 'message' => 'فایل‌های پیکربندی ایجاد شدند'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'خطا در ایجاد فایل‌های پیکربندی: ' . $e->getMessage()];
        }
    }
    
    public function installDatabase($data) {
        try {
            $dsn = "mysql:host={$data['db_host']};port={$data['db_port']};dbname={$data['db_name']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['db_username'], $data['db_password']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // ایجاد جداول اصلی
            $this->createTables($pdo);
            
            // ایجاد کاربر مدیر
            $this->createAdminUser($pdo, $data);
            
            // ایجاد تنظیمات پایه
            $this->createSettings($pdo, $data);
            
            // ایجاد محتوای نمونه
            $this->createSampleContent($pdo);
            
            return ['success' => true, 'message' => 'پایگاه داده با موفقیت نصب شد'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'خطا در نصب پایگاه داده: ' . $e->getMessage()];
        }
    }
    
    private function createTables($pdo) {
        $sql = "
        -- جدول کاربران
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            first_name VARCHAR(50),
            last_name VARCHAR(50),
            role ENUM('admin', 'editor', 'author', 'user') DEFAULT 'user',
            status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
            avatar VARCHAR(255),
            bio TEXT,
            last_login TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول صفحات
        CREATE TABLE IF NOT EXISTS pages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) UNIQUE NOT NULL,
            content LONGTEXT,
            excerpt TEXT,
            featured_image VARCHAR(255),
            status ENUM('draft', 'published', 'private') DEFAULT 'draft',
            author_id INT,
            parent_id INT DEFAULT NULL,
            menu_order INT DEFAULT 0,
            template VARCHAR(100) DEFAULT 'default',
            meta_title VARCHAR(255),
            meta_description TEXT,
            meta_keywords TEXT,
            views INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY (parent_id) REFERENCES pages(id) ON DELETE SET NULL,
            INDEX idx_slug (slug),
            INDEX idx_status (status),
            INDEX idx_author (author_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول پست‌ها (برای بلاگ)
        CREATE TABLE IF NOT EXISTS posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) UNIQUE NOT NULL,
            content LONGTEXT,
            excerpt TEXT,
            featured_image VARCHAR(255),
            status ENUM('draft', 'published', 'private') DEFAULT 'draft',
            author_id INT,
            category_id INT,
            tags TEXT,
            meta_title VARCHAR(255),
            meta_description TEXT,
            meta_keywords TEXT,
            views INT DEFAULT 0,
            likes INT DEFAULT 0,
            comments_count INT DEFAULT 0,
            published_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_slug (slug),
            INDEX idx_status (status),
            INDEX idx_author (author_id),
            INDEX idx_category (category_id),
            INDEX idx_published (published_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول دسته‌بندی‌ها
        CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            slug VARCHAR(100) UNIQUE NOT NULL,
            description TEXT,
            parent_id INT DEFAULT NULL,
            image VARCHAR(255),
            color VARCHAR(7) DEFAULT '#007bff',
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
            INDEX idx_slug (slug),
            INDEX idx_parent (parent_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول تنظیمات
        CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            `key` VARCHAR(100) UNIQUE NOT NULL,
            value LONGTEXT,
            type ENUM('string', 'number', 'boolean', 'json', 'text') DEFAULT 'string',
            group_name VARCHAR(50) DEFAULT 'general',
            description TEXT,
            is_public BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_key (`key`),
            INDEX idx_group (group_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول فایل‌ها
        CREATE TABLE IF NOT EXISTS media (
            id INT AUTO_INCREMENT PRIMARY KEY,
            filename VARCHAR(255) NOT NULL,
            original_name VARCHAR(255) NOT NULL,
            mime_type VARCHAR(100) NOT NULL,
            size INT NOT NULL,
            path VARCHAR(500) NOT NULL,
            url VARCHAR(500) NOT NULL,
            alt_text VARCHAR(255),
            caption TEXT,
            description TEXT,
            uploaded_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_mime (mime_type),
            INDEX idx_uploaded_by (uploaded_by)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول منوها
        CREATE TABLE IF NOT EXISTS menus (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            location VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_location (location)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول آیتم‌های منو
        CREATE TABLE IF NOT EXISTS menu_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            menu_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            url VARCHAR(500),
            target VARCHAR(20) DEFAULT '_self',
            icon VARCHAR(50),
            parent_id INT DEFAULT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (menu_id) REFERENCES menus(id) ON DELETE CASCADE,
            FOREIGN KEY (parent_id) REFERENCES menu_items(id) ON DELETE CASCADE,
            INDEX idx_menu (menu_id),
            INDEX idx_parent (parent_id),
            INDEX idx_order (sort_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول کامنت‌ها
        CREATE TABLE IF NOT EXISTS comments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT,
            parent_id INT DEFAULT NULL,
            author_name VARCHAR(100) NOT NULL,
            author_email VARCHAR(100) NOT NULL,
            author_url VARCHAR(255),
            content TEXT NOT NULL,
            status ENUM('pending', 'approved', 'spam', 'trash') DEFAULT 'pending',
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
            FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE,
            INDEX idx_post (post_id),
            INDEX idx_status (status),
            INDEX idx_parent (parent_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول فرم‌ها
        CREATE TABLE IF NOT EXISTS forms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            fields JSON NOT NULL,
            settings JSON,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- جدول ارسال‌های فرم
        CREATE TABLE IF NOT EXISTS form_submissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            form_id INT NOT NULL,
            data JSON NOT NULL,
            ip_address VARCHAR(45),
            user_agent TEXT,
            status ENUM('new', 'read', 'replied') DEFAULT 'new',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE,
            INDEX idx_form (form_id),
            INDEX idx_status (status),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";
        
        $pdo->exec($sql);
    }
    
    private function createAdminUser($pdo, $data) {
        $hashedPassword = password_hash($data['admin_password'], PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password, first_name, last_name, role, status) 
            VALUES (?, ?, ?, ?, ?, 'admin', 'active')
        ");
        
        $firstName = $data['admin_first_name'] ?? 'مدیر';
        $lastName = $data['admin_last_name'] ?? 'سیستم';
        
        $stmt->execute([
            $data['admin_username'],
            $data['admin_email'],
            $hashedPassword,
            $firstName,
            $lastName
        ]);
    }
    
    private function createSettings($pdo, $data) {
        $settings = [
            // تنظیمات عمومی
            ['site_title', $data['site_title'], 'string', 'general', 'عنوان سایت', true],
            ['site_description', 'سیستم مدیریت محتوای قدرتمند', 'string', 'general', 'توضیحات سایت', true],
            ['site_url', $data['site_url'], 'string', 'general', 'آدرس سایت', true],
            ['admin_email', $data['admin_email'], 'string', 'general', 'ایمیل مدیر', false],
            ['timezone', 'Asia/Tehran', 'string', 'general', 'منطقه زمانی', false],
            ['date_format', 'Y/m/d', 'string', 'general', 'فرمت تاریخ', false],
            ['time_format', 'H:i', 'string', 'general', 'فرمت زمان', false],
            ['language', 'fa', 'string', 'general', 'زبان پیش‌فرض', false],
            
            // تنظیمات نمایش
            ['posts_per_page', '10', 'number', 'display', 'تعداد پست در هر صفحه', false],
            ['theme', 'default', 'string', 'display', 'قالب فعال', false],
            ['show_excerpts', '1', 'boolean', 'display', 'نمایش خلاصه پست‌ها', false],
            
            // تنظیمات کامنت
            ['comments_enabled', '1', 'boolean', 'comments', 'فعال‌سازی کامنت‌ها', false],
            ['comments_moderation', '1', 'boolean', 'comments', 'تأیید دستی کامنت‌ها', false],
            ['comments_registration', '0', 'boolean', 'comments', 'ثبت‌نام اجباری برای کامنت', false],
            
            // تنظیمات SEO
            ['seo_enabled', '1', 'boolean', 'seo', 'فعال‌سازی SEO', false],
            ['sitemap_enabled', '1', 'boolean', 'seo', 'فعال‌سازی نقشه سایت', false],
            ['robots_txt', "User-agent: *\nDisallow: /admin/\nDisallow: /install/", 'text', 'seo', 'محتوای robots.txt', true],
            
            // تنظیمات امنیتی
            ['login_attempts', '5', 'number', 'security', 'حداکثر تلاش ورود', false],
            ['session_timeout', '3600', 'number', 'security', 'مدت انقضای نشست (ثانیه)', false],
            ['force_ssl', '0', 'boolean', 'security', 'اجبار استفاده از SSL', false],
            
            // تنظیمات ایمیل
            ['mail_method', 'mail', 'string', 'email', 'روش ارسال ایمیل', false],
            ['smtp_host', '', 'string', 'email', 'آدرس سرور SMTP', false],
            ['smtp_port', '587', 'number', 'email', 'پورت SMTP', false],
            ['smtp_username', '', 'string', 'email', 'نام کاربری SMTP', false],
            ['smtp_password', '', 'string', 'email', 'رمز عبور SMTP', false],
            ['smtp_encryption', 'tls', 'string', 'email', 'نوع رمزنگاری SMTP', false],
            
            // تنظیمات فایل
            ['max_upload_size', '10485760', 'number', 'media', 'حداکثر اندازه آپلود (بایت)', false],
            ['allowed_file_types', 'jpg,jpeg,png,gif,pdf,doc,docx,zip', 'string', 'media', 'فرمت‌های مجاز فایل', false],
            ['image_quality', '85', 'number', 'media', 'کیفیت تصاویر', false]
        ];
        
        $stmt = $pdo->prepare("
            INSERT INTO settings (`key`, value, type, group_name, description, is_public) 
            VALUES (?, ?, ?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
                value = VALUES(value),
                type = VALUES(type),
                group_name = VALUES(group_name),
                description = VALUES(description),
                is_public = VALUES(is_public)
        ");
        
        foreach ($settings as $setting) {
            $stmt->execute($setting);
        }
    }
    
    private function createSampleContent($pdo) {
        // ایجاد دسته‌بندی نمونه
        $stmt = $pdo->prepare("
            INSERT INTO categories (name, slug, description, color) 
            VALUES (?, ?, ?, ?)
        ");
        
        $categories = [
            ['عمومی', 'general', 'دسته‌بندی عمومی برای مطالب', '#007bff'],
            ['اخبار', 'news', 'آخرین اخبار و رویدادها', '#28a745'],
            ['آموزش', 'tutorial', 'مطالب آموزشی و راهنما', '#ffc107']
        ];
        
        foreach ($categories as $category) {
            $stmt->execute($category);
        }
        
        // ایجاد صفحه خانه
        $stmt = $pdo->prepare("
            INSERT INTO pages (title, slug, content, status, author_id, meta_title, meta_description) 
            VALUES (?, ?, ?, 'published', 1, ?, ?)
        ");
        
        $homeContent = '
        <div class="hero-section">
            <h1>به Mitra CMS خوش آمدید</h1>
            <p>سیستم مدیریت محتوای قدرتمند و کاربرپسند</p>
        </div>
        
        <div class="features">
            <h2>ویژگی‌های کلیدی</h2>
            <ul>
                <li>رابط کاربری ساده و زیبا</li>
                <li>پشتیبانی کامل از زبان فارسی</li>
                <li>سیستم مدیریت کاربران</li>
                <li>ابزارهای SEO پیشرفته</li>
                <li>سیستم کامنت‌گذاری</li>
                <li>مدیریت فایل و رسانه</li>
            </ul>
        </div>
        ';
        
        $stmt->execute([
            'خانه',
            'home',
            $homeContent,
            'صفحه اصلی Mitra CMS',
            'سیستم مدیریت محتوای قدرتمند با پشتیبانی کامل از زبان فارسی'
        ]);
        
        // ایجاد صفحه درباره ما
        $stmt->execute([
            'درباره ما',
            'about',
            '<h1>درباره ما</h1><p>این صفحه حاوی اطلاعات درباره شرکت یا سازمان شما است.</p>',
            'درباره ما - Mitra CMS',
            'اطلاعات کامل درباره ما و خدمات ما'
        ]);
        
        // ایجاد صفحه تماس با ما
        $contactContent = '
        <h1>تماس با ما</h1>
        <p>برای ارتباط با ما از راه‌های زیر استفاده کنید:</p>
        
        <div class="contact-info">
            <h3>اطلاعات تماس</h3>
            <p><strong>آدرس:</strong> تهران، ایران</p>
            <p><strong>تلفن:</strong> 021-12345678</p>
            <p><strong>ایمیل:</strong> info@example.com</p>
        </div>
        
        <div class="contact-form">
            <h3>فرم تماس</h3>
            <p>فرم تماس در اینجا قرار خواهد گرفت.</p>
        </div>
        ';
        
        $stmt->execute([
            'تماس با ما',
            'contact',
            $contactContent,
            'تماس با ما - Mitra CMS',
            'راه‌های ارتباط با ما و فرم تماس'
        ]);
        
        // ایجاد پست نمونه
        $stmt = $pdo->prepare("
            INSERT INTO posts (title, slug, content, excerpt, status, author_id, category_id, published_at, meta_title, meta_description) 
            VALUES (?, ?, ?, ?, 'published', 1, 1, NOW(), ?, ?)
        ");
        
        $postContent = '
        <p>به اولین پست وبلاگ خود خوش آمدید! این پست نمونه‌ای است که برای نمایش قابلیت‌های سیستم ایجاد شده است.</p>
        
        <h2>ویژگی‌های سیستم</h2>
        <p>Mitra CMS دارای ویژگی‌های متنوعی است که مدیریت محتوا را آسان می‌کند:</p>
        
        <ul>
            <li>ویرایشگر متن پیشرفته</li>
            <li>مدیریت تصاویر و فایل‌ها</li>
            <li>سیستم دسته‌بندی</li>
            <li>مدیریت کامنت‌ها</li>
            <li>ابزارهای SEO</li>
        </ul>
        
        <p>شما می‌توانید این پست را ویرایش یا حذف کنید و پست‌های جدید خود را ایجاد کنید.</p>
        ';
        
        $stmt->execute([
            'خوش آمدید به Mitra CMS',
            'welcome-to-mitra-cms',
            $postContent,
            'اولین پست وبلاگ شما در سیستم مدیریت محتوای Mitra CMS',
            'خوش آمدید به Mitra CMS',
            'اولین پست وبلاگ در سیستم مدیریت محتوای قدرتمند Mitra CMS'
        ]);
        
        // ایجاد منوی اصلی
        $stmt = $pdo->prepare("INSERT INTO menus (name, location) VALUES (?, ?)");
        $stmt->execute(['منوی اصلی', 'main']);
        $menuId = $pdo->lastInsertId();
        
        // ایجاد آیتم‌های منو
        $stmt = $pdo->prepare("
            INSERT INTO menu_items (menu_id, title, url, sort_order) 
            VALUES (?, ?, ?, ?)
        ");
        
        $menuItems = [
            [$menuId, 'خانه', '/', 1],
            [$menuId, 'درباره ما', '/about', 2],
            [$menuId, 'وبلاگ', '/blog', 3],
            [$menuId, 'تماس با ما', '/contact', 4]
        ];
        
        foreach ($menuItems as $item) {
            $stmt->execute($item);
        }
    }
    
    public function completeInstallation() {
        try {
            // ایجاد فایل نصب شده
            $installFile = $this->config['root_dir'] . '/.installed';
            $installData = [
                'installed_at' => date('Y-m-d H:i:s'),
                'version' => '1.0.0',
                'installer_version' => '1.0.0'
            ];
            
            file_put_contents($installFile, json_encode($installData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            // پاک کردن session نصب
            unset($_SESSION['install_data']);
            
            return ['success' => true, 'message' => 'نصب با موفقیت تکمیل شد'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'خطا در تکمیل نصب: ' . $e->getMessage()];
        }
    }
    
    public function isInstalled() {
        return file_exists($this->config['root_dir'] . '/.installed');
    }
    
    public function getInstallationInfo() {
        $installFile = $this->config['root_dir'] . '/.installed';
        if (file_exists($installFile)) {
            $content = file_get_contents($installFile);
            return json_decode($content, true);
        }
        return null;
    }
}
