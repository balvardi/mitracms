<?php

class Language
{
    private $currentLanguage = 'fa';
    private $translations = [];
    private $availableLanguages = [
        'fa' => [
            'name' => 'فارسی',
            'native' => 'فارسی',
            'direction' => 'rtl',
            'flag' => '🇮🇷'
        ],
        'en' => [
            'name' => 'English',
            'native' => 'English',
            'direction' => 'ltr',
            'flag' => '🇺🇸'
        ],
        'ar' => [
            'name' => 'العربية',
            'native' => 'العربية',
            'direction' => 'rtl',
            'flag' => '🇸🇦'
        ],
        'tr' => [
            'name' => 'Türkçe',
            'native' => 'Türkçe',
            'direction' => 'ltr',
            'flag' => '🇹🇷'
        ],
        'de' => [
            'name' => 'Deutsch',
            'native' => 'Deutsch',
            'direction' => 'ltr',
            'flag' => '🇩🇪'
        ],
        'fr' => [
            'name' => 'Français',
            'native' => 'Français',
            'direction' => 'ltr',
            'flag' => '🇫🇷'
        ]
    ];

    public function __construct($language = 'fa')
    {
        $this->setLanguage($language);
    }

    public function setLanguage($language)
    {
        if (isset($this->availableLanguages[$language])) {
            $this->currentLanguage = $language;
            $this->loadTranslations();
            $_SESSION['installer_language'] = $language;
        }
    }

    public function getCurrentLanguage()
    {
        return $this->currentLanguage;
    }

    public function getAvailableLanguages()
    {
        return $this->availableLanguages;
    }

    public function getLanguageInfo($language = null)
    {
        $lang = $language ?? $this->currentLanguage;
        return $this->availableLanguages[$lang] ?? $this->availableLanguages['fa'];
    }

    public function isRTL($language = null)
    {
        $info = $this->getLanguageInfo($language);
        return $info['direction'] === 'rtl';
    }

    private function loadTranslations()
    {
        $langFile = INSTALL_DIR . "/languages/{$this->currentLanguage}.php";
        
        if (file_exists($langFile)) {
            $this->translations = include $langFile;
        } else {
            // Fallback to English if language file doesn't exist
            $fallbackFile = INSTALL_DIR . "/languages/en.php";
            if (file_exists($fallbackFile)) {
                $this->translations = include $fallbackFile;
            }
        }
    }

    public function get($key, $params = [])
    {
        $keys = explode('.', $key);
        $value = $this->translations;

        foreach ($keys as $k) {
            if (isset($value[$k])) {
                $value = $value[$k];
            } else {
                return $key; // Return key if translation not found
            }
        }

        // Replace parameters
        if (!empty($params) && is_string($value)) {
            foreach ($params as $param => $replacement) {
                $value = str_replace(':' . $param, $replacement, $value);
            }
        }

        return $value;
    }

    public function __($key, $params = [])
    {
        return $this->get($key, $params);
    }

    public function choice($key, $count, $params = [])
    {
        $translation = $this->get($key, $params);
        
        if (is_array($translation)) {
            if ($count == 0 && isset($translation['zero'])) {
                return $translation['zero'];
            } elseif ($count == 1 && isset($translation['one'])) {
                return $translation['one'];
            } elseif (isset($translation['other'])) {
                return str_replace(':count', $count, $translation['other']);
            }
        }
        
        return $translation;
    }

    public function getDateFormat()
    {
        $formats = [
            'fa' => 'Y/m/d H:i',
            'ar' => 'Y/m/d H:i',
            'en' => 'Y-m-d H:i',
            'tr' => 'd.m.Y H:i',
            'de' => 'd.m.Y H:i',
            'fr' => 'd/m/Y H:i'
        ];

        return $formats[$this->currentLanguage] ?? $formats['en'];
    }

    public function getNumberFormat()
    {
        $formats = [
            'fa' => ['decimal' => '/', 'thousands' => '،'],
            'ar' => ['decimal' => '/', 'thousands' => '،'],
            'en' => ['decimal' => '.', 'thousands' => ','],
            'tr' => ['decimal' => ',', 'thousands' => '.'],
            'de' => ['decimal' => ',', 'thousands' => '.'],
            'fr' => ['decimal' => ',', 'thousands' => ' ']
        ];

        return $formats[$this->currentLanguage] ?? $formats['en'];
    }

    public function formatNumber($number, $decimals = 0)
    {
        $format = $this->getNumberFormat();
        return number_format($number, $decimals, $format['decimal'], $format['thousands']);
    }

    public function getTextDirection()
    {
        return $this->isRTL() ? 'rtl' : 'ltr';
    }

    public function getHtmlLang()
    {
        return $this->currentLanguage;
    }

    public function getBootstrapDirection()
    {
        return $this->isRTL() ? 'rtl' : 'ltr';
    }
}

// Global helper function
function __($key, $params = [])
{
    global $language;
    return $language ? $language->get($key, $params) : $key;
}

function _choice($key, $count, $params = [])
{
    global $language;
    return $language ? $language->choice($key, $count, $params) : $key;
}
