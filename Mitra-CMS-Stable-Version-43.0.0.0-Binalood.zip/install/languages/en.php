<?php
/**
 * English Language File
 */

return [
    'app' => [
        'name' => 'Mitra Global CMS',
        'installer' => 'Automatic Installer',
        'version' => 'Version :version'
    ],

    'navigation' => [
        'next' => 'Next Step',
        'previous' => 'Previous Step',
        'start' => 'Start Installation',
        'continue' => 'Continue',
        'finish' => 'Finish',
        'retry' => 'Retry',
        'skip' => 'Skip'
    ],

    'steps' => [
        'welcome' => 'Welcome',
        'requirements' => 'Requirements Check',
        'database' => 'Database Settings',
        'config' => 'Site Configuration',
        'admin' => 'Create Admin User',
        'install' => 'Installation',
        'complete' => 'Complete'
    ],

    'welcome' => [
        'title' => 'Welcome!',
        'subtitle' => 'Welcome to Mitra Global CMS Installer',
        'description' => 'This installer will guide you through setting up your powerful content management system',
        'features' => [
            'modular' => [
                'title' => 'Modular Architecture',
                'description' => 'Flexible modular system for extending capabilities'
            ],
            'themes' => [
                'title' => 'Beautiful Themes',
                'description' => 'Ready-made themes and custom design capabilities'
            ],
            'seo' => [
                'title' => 'SEO Optimization',
                'description' => 'Complete SEO tools for better ranking'
            ],
            'security' => [
                'title' => 'High Security',
                'description' => 'Advanced protection against security threats'
            ]
        ],
        'info' => [
            'title' => 'Important Information',
            'items' => [
                'Make sure your server meets the system requirements',
                'Backup your files before installation',
                'Have your database information ready',
                'Installation process takes about 5-10 minutes'
            ]
        ]
    ],

    'requirements' => [
        'title' => 'Requirements Check',
        'description' => 'Please wait while system requirements are being checked...',
        'checking' => 'Checking system...',
        'check_again' => 'Check Again',
        'all_passed' => 'All requirements met',
        'some_failed' => 'Some requirements not met',
        'fix_required' => 'Fix Required Issues',
        'items' => [
            'php_version' => 'PHP Version',
            'mysql_extension' => 'MySQL Extension',
            'mbstring_extension' => 'mbstring Extension',
            'openssl_extension' => 'OpenSSL Extension',
            'gd_extension' => 'GD Extension',
            'curl_extension' => 'cURL Extension',
            'zip_extension' => 'ZIP Extension',
            'config_writable' => 'Config Write Access',
            'uploads_writable' => 'Storage Write Access'
        ],
        'descriptions' => [
            'php_version' => 'PHP 7.4 or higher is required',
            'mysql_extension' => 'PDO MySQL extension must be installed',
            'mbstring_extension' => 'mbstring extension for text processing',
            'openssl_extension' => 'OpenSSL extension for security',
            'gd_extension' => 'GD extension for image processing',
            'curl_extension' => 'cURL extension for HTTP communications',
            'zip_extension' => 'ZIP extension for compression',
            'config_writable' => 'Config folder must be writable',
            'uploads_writable' => 'Storage folder must be writable'
        ],
        'help' => [
            'title' => 'Help',
            'subtitle' => 'If you encounter errors:',
            'php_version' => 'Change PHP version to 7.4+ from hosting control panel',
            'extensions' => 'Enable through control panel or contact hosting support',
            'permissions' => 'Set folder write permissions to 755'
        ]
    ],

    'database' => [
        'title' => 'Database Settings',
        'description' => 'Enter your MySQL database information',
        'host' => 'Server Address',
        'host_help' => 'Usually localhost',
        'port' => 'Port',
        'name' => 'Database Name',
        'name_help' => 'Database must be created beforehand',
        'username' => 'Username',
        'password' => 'Password',
        'test_connection' => 'Test Connection',
        'connection_success' => 'Database connection successful',
        'connection_failed' => 'Database connection failed',
        'info' => [
            'title' => 'Important Notes',
            'items' => [
                'Database must be created beforehand in cPanel or phpMyAdmin',
                'Database user must have full access to the database',
                'Make sure to test connection before proceeding'
            ]
        ]
    ],

    'config' => [
        'title' => 'Site Configuration',
        'description' => 'Enter your site\'s basic information',
        'site_title' => 'Site Title',
        'site_title_help' => 'This title will be displayed in browser tabs and search engines',
        'site_description' => 'Site Description',
        'site_description_help' => 'Brief description of your site for search engines',
        'site_url' => 'Site URL',
        'site_url_help' => 'Complete URL of your site (without trailing slash)',
        'admin_email' => 'Admin Email',
        'admin_email_help' => 'Primary email for receiving notifications',
        'timezone' => 'Timezone',
        'language' => 'Default Language',
        'languages' => [
            'fa' => 'Persian',
            'en' => 'English',
            'ar' => 'Arabic'
        ],
        'timezones' => [
            'Asia/Tehran' => 'Tehran (Iran)',
            'Asia/Dubai' => 'Dubai (UAE)',
            'Asia/Kuwait' => 'Kuwait',
            'Asia/Riyadh' => 'Riyadh (Saudi Arabia)',
            'Europe/Istanbul' => 'Istanbul (Turkey)'
        ],
        'recommendations' => [
            'title' => 'Recommendations',
            'items' => [
                'Choose a short and attractive site title',
                'Site description is very important for SEO',
                'Site URL must exactly match your domain',
                'Admin email is used for password recovery'
            ]
        ]
    ],

    'admin' => [
        'title' => 'Create Admin User',
        'description' => 'Create the system administrator account',
        'username' => 'Username',
        'username_help' => 'Username for admin panel login',
        'email' => 'Email',
        'email_help' => 'Email for login and password recovery',
        'password' => 'Password',
        'password_help' => 'Minimum 8 characters',
        'password_confirm' => 'Confirm Password',
        'password_confirm_help' => 'Enter password again',
        'warning' => 'Write down your login information in a safe place. This information is essential for accessing the admin panel.',
        'security_tips' => [
            'title' => 'Security Tips',
            'items' => [
                'Use a strong password (combination of letters, numbers and symbols)',
                'Change the default username "admin"',
                'Enter a valid email so you can recover your password',
                'Store this information in a safe place'
            ]
        ]
    ],

    'install' => [
        'title' => 'Installing...',
        'description' => 'Please wait while the installation process completes',
        'preparing' => 'Preparing installation...',
        'database_install' => 'Installing database...',
        'database_success' => 'Database installed ✓',
        'final_config' => 'Final configuration...',
        'completed' => 'Installation completed successfully! ✓',
        'please_wait' => 'This process may take a few minutes',
        'tasks' => [
            'title' => 'In Progress',
            'items' => [
                'Creating database tables',
                'Inserting initial data',
                'Setting file permissions',
                'Final system configuration'
            ]
        ]
    ],

    'complete' => [
        'title' => 'Installation Complete!',
        'subtitle' => 'Mitra Global CMS has been successfully installed',
        'site_info' => 'Site Information',
        'admin_info' => 'Admin Login Information',
        'site_url' => 'Site URL',
        'admin_panel' => 'Admin Panel',
        'username' => 'Username',
        'email' => 'Email',
        'next_steps' => [
            'title' => 'Next Steps',
            'items' => [
                'Go to admin panel and login',
                'Complete initial site settings',
                'Choose your preferred theme',
                'Create initial site content'
            ]
        ],
        'security_notes' => [
            'title' => 'Important Security Notes',
            'items' => [
                'Delete the install folder from server',
                'Change admin password',
                'Take regular backups of your site',
                'Keep the system updated'
            ]
        ],
        'login_admin' => 'Login to Admin Panel',
        'view_site' => 'View Site',
        'thanks' => [
            'title' => 'Thank you for choosing Mitra Global CMS!',
            'subtitle' => 'For latest news and updates:',
            'links' => [
                'website' => 'Website',
                'docs' => 'Documentation',
                'support' => 'Support',
                'github' => 'GitHub'
            ]
        ]
    ],

    'common' => [
        'loading' => 'Loading...',
        'processing' => 'Processing...',
        'please_wait' => 'Please wait',
        'error' => 'Error',
        'success' => 'Success',
        'warning' => 'Warning',
        'info' => 'Information',
        'required' => 'Required',
        'optional' => 'Optional',
        'yes' => 'Yes',
        'no' => 'No',
        'ok' => 'OK',
        'cancel' => 'Cancel',
        'close' => 'Close',
        'save' => 'Save',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'view' => 'View',
        'download' => 'Download',
        'upload' => 'Upload',
        'search' => 'Search',
        'filter' => 'Filter',
        'sort' => 'Sort',
        'refresh' => 'Refresh'
    ],

    'errors' => [
        'connection_failed' => 'Server connection failed',
        'database_error' => 'Database error: :message',
        'file_not_writable' => 'File is not writable: :file',
        'invalid_input' => 'Invalid input',
        'passwords_not_match' => 'Passwords do not match',
        'email_invalid' => 'Email is invalid',
        'required_field' => 'This field is required',
        'installation_failed' => 'Installation failed',
        'unknown_error' => 'An unknown error occurred'
    ]
];
