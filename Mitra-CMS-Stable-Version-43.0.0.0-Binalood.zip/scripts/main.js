document.addEventListener('DOMContentLoaded', function() {
    // Latest Posts Animation
    const latestSection = document.querySelector('.latest-posts-section');
    const animation = latestSection.dataset.animation;
    
    if (animation) {
        latestSection.classList.add(animation);
    }
    
    // Post card interactions
    const postCards = document.querySelectorAll('.post-card');
    postCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
        
        // Click tracking
        card.addEventListener('click', function(e) {
            if (!e.target.closest('a')) {
                const link = this.querySelector('.post-title a');
                if (link) {
                    window.location.href = link.href;
                }
            }
        });
    });
    
    // Lazy loading for images
    const images = document.querySelectorAll('img[loading="lazy"]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => {
        imageObserver.observe(img);
    });
    
    // Parallax effect for post cards
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.3;
        
        postCards.forEach((card, index) => {
            const delay = index * 0.1;
            card.style.transform = `translateY(${rate * delay}px)`;
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
    // Features Animation
    const featuresSection = document.querySelector('.features-section');
    const animation = featuresSection.dataset.animation;
    
    if (animation) {
        featuresSection.classList.add(animation);
    }
    
    // Feature card interactions
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
        
        // Click tracking
        card.addEventListener('click', function() {
            const title = this.querySelector('.feature-title').textContent;
            console.log('Feature clicked:', title);
        });
    });
    
    // Stats counter animation
    const statNumbers = document.querySelectorAll('.stat-number');
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalValue = parseInt(target.textContent);
                animateCounter(target, 0, finalValue, 2000);
                observer.unobserve(target);
            }
        });
    }, observerOptions);
    
    statNumbers.forEach(stat => {
        observer.observe(stat);
    });
    
    function animateCounter(element, start, end, duration) {
        const startTime = performance.now();
        const startValue = start;
        const change = end - start;
        
        function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const currentValue = Math.floor(startValue + (change * progress));
            element.textContent = currentValue;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        }
        
        requestAnimationFrame(updateCounter);
    }
    
    // Parallax effect for feature cards
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        
        featureCards.forEach((card, index) => {
            const delay = index * 0.1;
            card.style.transform = `translateY(${rate * delay}px)`;
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
    // Character counter for comment form
    const textarea = document.querySelector('.comment-form-preview textarea');
    const charCount = document.querySelector('.char-count');
    
    if (textarea && charCount) {
        textarea.addEventListener('input', function() {
            const length = this.value.length;
            charCount.textContent = length;
            
            if (length > 450) {
                charCount.style.color = '#dc3545';
            } else if (length > 400) {
                charCount.style.color = '#ffc107';
            } else {
                charCount.style.color = '#667eea';
            }
        });
    }
    
    // Comment form submission
    const submitBtn = document.querySelector('.comment-form-preview button');
    if (submitBtn) {
        submitBtn.addEventListener('click', function() {
            const textarea = document.querySelector('.comment-form-preview textarea');
            if (textarea && textarea.value.trim()) {
                // Here you would typically submit the comment via AJAX
                alert('نظر شما با موفقیت ارسال شد و پس از تایید نمایش داده خواهد شد.');
                textarea.value = '';
                charCount.textContent = '0';
            } else {
                alert('لطفاً نظر خود را وارد کنید.');
            }
        });
    }
    
    // Smooth scroll to comment
    const commentLinks = document.querySelectorAll('.comment-actions a');
    commentLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.includes('#')) {
                e.preventDefault();
                const targetId = href.split('#')[1];
                const target = document.querySelector('#' + targetId);
                if (target) {
                    target.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'center'
                    });
                }
            }
        });
    });
});
// Hero Animation
document.addEventListener('DOMContentLoaded', function() {
    const heroSection = document.querySelector('.hero-section');
    const animation = heroSection.dataset.animation;
    
    if (animation) {
        heroSection.classList.add(animation);
    }
    
    // Smooth scroll for scroll indicator
    const scrollDown = document.querySelector('.scroll-down');
    if (scrollDown) {
        scrollDown.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector('#content');
            if (target) {
                target.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    }
    
    // Parallax effect for hero background
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const heroBackground = document.querySelector('.hero-background');
        if (heroBackground) {
            heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });
});
