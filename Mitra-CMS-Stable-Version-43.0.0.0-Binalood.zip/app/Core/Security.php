<?php

namespace App\Core;

class Security
{
    private static $instance = null;
    private $csrfTokens = [];
    private $rateLimits = [];

    private function __construct() {}

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Generate CSRF Token
     */
    public function generateCSRFToken(string $action = 'default'): string
    {
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_tokens'][$action] = $token;
        return $token;
    }

    /**
     * Verify CSRF Token
     */
    public function verifyCSRFToken(string $token, string $action = 'default'): bool
    {
        if (!isset($_SESSION['csrf_tokens'][$action])) {
            return false;
        }

        $isValid = hash_equals($_SESSION['csrf_tokens'][$action], $token);
        
        // Remove token after verification (one-time use)
        unset($_SESSION['csrf_tokens'][$action]);
        
        return $isValid;
    }

    /**
     * Sanitize input data
     */
    public function sanitizeInput($data, string $type = 'string')
    {
        if (is_array($data)) {
            return array_map(function($item) use ($type) {
                return $this->sanitizeInput($item, $type);
            }, $data);
        }

        switch ($type) {
            case 'email':
                return filter_var($data, FILTER_SANITIZE_EMAIL);
            
            case 'url':
                return filter_var($data, FILTER_SANITIZE_URL);
            
            case 'int':
                return filter_var($data, FILTER_SANITIZE_NUMBER_INT);
            
            case 'float':
                return filter_var($data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            
            case 'html':
                return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            
            case 'sql':
                return addslashes($data);
            
            default:
                return htmlspecialchars(trim($data), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    }

    /**
     * Validate input data
     */
    public function validateInput($data, array $rules): array
    {
        $errors = [];

        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            $fieldRules = explode('|', $rule);

            foreach ($fieldRules as $fieldRule) {
                $ruleParts = explode(':', $fieldRule);
                $ruleName = $ruleParts[0];
                $ruleValue = $ruleParts[1] ?? null;

                switch ($ruleName) {
                    case 'required':
                        if (empty($value)) {
                            $errors[$field][] = "Field {$field} is required";
                        }
                        break;

                    case 'email':
                        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[$field][] = "Field {$field} must be a valid email";
                        }
                        break;

                    case 'min':
                        if (!empty($value) && strlen($value) < $ruleValue) {
                            $errors[$field][] = "Field {$field} must be at least {$ruleValue} characters";
                        }
                        break;

                    case 'max':
                        if (!empty($value) && strlen($value) > $ruleValue) {
                            $errors[$field][] = "Field {$field} must not exceed {$ruleValue} characters";
                        }
                        break;

                    case 'numeric':
                        if (!empty($value) && !is_numeric($value)) {
                            $errors[$field][] = "Field {$field} must be numeric";
                        }
                        break;

                    case 'url':
                        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
                            $errors[$field][] = "Field {$field} must be a valid URL";
                        }
                        break;

                    case 'regex':
                        if (!empty($value) && !preg_match($ruleValue, $value)) {
                            $errors[$field][] = "Field {$field} format is invalid";
                        }
                        break;
                }
            }
        }

        return $errors;
    }

    /**
     * Rate limiting
     */
    public function checkRateLimit(string $key, int $maxAttempts = 5, int $timeWindow = 300): bool
    {
        $now = time();
        $windowStart = $now - $timeWindow;

        // Clean old entries
        if (isset($this->rateLimits[$key])) {
            $this->rateLimits[$key] = array_filter(
                $this->rateLimits[$key],
                function($timestamp) use ($windowStart) {
                    return $timestamp > $windowStart;
                }
            );
        }

        // Check current attempts
        $currentAttempts = count($this->rateLimits[$key] ?? []);
        
        if ($currentAttempts >= $maxAttempts) {
            return false;
        }

        // Record this attempt
        $this->rateLimits[$key][] = $now;
        
        return true;
    }

    /**
     * Secure password hashing
     */
    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ]);
    }

    /**
     * Verify password
     */
    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Generate secure random string
     */
    public function generateRandomString(int $length = 32): string
    {
        return bin2hex(random_bytes($length / 2));
    }

    /**
     * Encrypt data
     */
    public function encrypt(string $data, string $key): string
    {
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }

    /**
     * Decrypt data
     */
    public function decrypt(string $encryptedData, string $key): string
    {
        $data = base64_decode($encryptedData);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }

    /**
     * Secure file upload validation
     */
    public function validateFileUpload(array $file, array $allowedTypes = [], int $maxSize = 5242880): array
    {
        $errors = [];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'File upload failed';
            return $errors;
        }

        // Check file size
        if ($file['size'] > $maxSize) {
            $errors[] = 'File size exceeds maximum allowed size';
        }

        // Check file type
        if (!empty($allowedTypes)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            if (!in_array($mimeType, $allowedTypes)) {
                $errors[] = 'File type not allowed';
            }
        }

        // Check for malicious content
        $content = file_get_contents($file['tmp_name']);
        if (strpos($content, '<?php') !== false || strpos($content, '<script') !== false) {
            $errors[] = 'File contains malicious content';
        }

        return $errors;
    }

    /**
     * Log security events
     */
    public function logSecurityEvent(string $event, array $data = []): void
    {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'event' => $event,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'data' => $data
        ];

        $logFile = STORAGE_DIR . '/logs/security.log';
        file_put_contents($logFile, json_encode($logData) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
