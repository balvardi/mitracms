<?php

namespace App\Core;

class Router
{
    private $routes = [];

    public function get(string $path, callable $handler): void
    {
        $this->routes['GET'][$path] = $handler;
    }

    public function post(string $path, callable $handler): void
    {
        $this->routes['POST'][$path] = $handler;
    }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // حذف اسلش اضافی
        $uri = rtrim($uri, '/');
        if (empty($uri)) {
            $uri = '/';
        }

        $handler = $this->routes[$method][$uri] ?? null;
        
        if (!$handler) {
            http_response_code(404);
            echo $this->render404();
            return;
        }

        try {
            call_user_func($handler);
        } catch (Exception $e) {
            http_response_code(500);
            echo $this->render500($e);
        }
    }

    private function render404(): string
    {
        return '
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>صفحه یافت نشد - Mitra CMS</title>
            <style>
                body { font-family: Tahoma, Arial; text-align: center; padding: 50px; }
                h1 { color: #e74c3c; }
            </style>
        </head>
        <body>
            <h1>404 - صفحه یافت نشد</h1>
            <p>صفحه مورد نظر شما یافت نشد.</p>
            <a href="index.php">بازگشت به صفحه اصلی</a>
        </body>
        </html>';
    }

    private function render500(Exception $e): string
    {
        return '
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>خطای سرور - Mitra CMS</title>
            <style>
                body { font-family: Tahoma, Arial; text-align: center; padding: 50px; }
                h1 { color: #e74c3c; }
                .error { background: #f8f9fa; padding: 20px; margin: 20px; border-radius: 5px; }
            </style>
        </head>
        <body>
            <h1>500 - خطای سرور</h1>
            <p>متأسفانه مشکلی در سرور رخ داده است.</p>
            <div class="error">
                <strong>خطا:</strong> ' . htmlspecialchars($e->getMessage()) . '
            </div>
            <a href="index.php">بازگشت به صفحه اصلی</a>
        </body>
        </html>';
    }
}
