<?php

namespace App\Controllers;

use App\Core\Controller;

class HomeController extends Controller
{
    public function index(): void
    {
        $data = [
            'title' => 'خوش آمدید به Mitra Global CMS',
            'description' => 'سیستم مدیریت محتوای قدرتمند و ماژولار'
        ];

        $this->render('home', $data);
    }
}
