<?php
/**
 * تنظیمات ویجت‌های قالب Dima CMS
 * این فایل شامل تمام تنظیمات قابل شخصی‌سازی ویجت‌ها است
 */

return [
    // تنظیمات ویجت Hero
    'hero_widget' => [
        'enabled' => true,
        'title' => 'Dima CMS - سیستم مدیریت محتوای پیشرفته',
        'subtitle' => 'یک CMS مدرن و امن برای مدیریت محتوای وب‌سایت شما',
        'image' => 'uploads/hero-image.jpg',
        'background' => 'gradient', // gradient, solid, image
        'animation' => 'fade-in', // fade-in, slide-up, zoom-in
        'buttons' => [
            [
                'text' => 'شروع کنید',
                'url' => 'auth.php',
                'type' => 'primary',
                'icon' => 'rocket'
            ],
            [
                'text' => 'درباره ما',
                'url' => 'page.php?slug=about',
                'type' => 'outline-light',
                'icon' => 'info-circle'
            ]
        ],
        'stats' => [
            [
                'value' => '1000+',
                'label' => 'کاربر فعال'
            ],
            [
                'value' => '500+',
                'label' => 'مقاله منتشر شده'
            ],
            [
                'value' => '99.9%',
                'label' => 'آپتایم'
            ]
        ]
    ],

    // تنظیمات ویجت Comments
    'comments_widget' => [
        'enabled' => true,
        'limit' => 5,
        'show_avatar' => true,
        'show_date' => true,
        'show_author' => true,
        'moderation' => true,
        'max_length' => 500,
        'auto_approve' => false
    ],

    // تنظیمات ویجت CTA
    'cta_widget' => [
        'enabled' => true,
        'title' => 'آماده شروع هستید؟',
        'subtitle' => 'همین حالا با ما در ارتباط باشید و از خدمات ما بهره‌مند شوید',
        'background' => 'gradient', // gradient, solid, image
        'animation' => 'fade-in', // fade-in, slide-up, zoom-in
        'buttons' => [
            [
                'text' => 'تماس با ما',
                'url' => 'page.php?slug=contact',
                'type' => 'light',
                'icon' => 'telephone'
            ],
            [
                'text' => 'درباره ما',
                'url' => 'page.php?slug=about',
                'type' => 'outline-light',
                'icon' => 'info-circle'
            ]
        ],
        'show_stats' => true,
        'stats' => [
            [
                'value' => '24/7',
                'label' => 'پشتیبانی'
            ],
            [
                'value' => '100%',
                'label' => 'امنیت'
            ],
            [
                'value' => '99.9%',
                'label' => 'آپتایم'
            ]
        ]
    ],

    // تنظیمات ویجت Featured
    'featured_widget' => [
        'enabled' => true,
        'title' => 'ویژگی‌های کلیدی',
        'subtitle' => 'چرا Dima CMS را انتخاب کنید؟',
        'layout' => 'grid', // grid, list
        'animation' => 'fade-in', // fade-in, slide-up
        'items' => [
            [
                'icon' => 'speedometer2',
                'title' => 'سرعت بالا',
                'description' => 'سیستم بهینه‌سازی شده برای سرعت و عملکرد بالا',
                'color' => 'primary',
                'animation' => 'fade-up'
            ],
            [
                'icon' => 'shield-check',
                'title' => 'امنیت بالا',
                'description' => 'امنیت پیشرفته و محافظت در برابر تهدیدات',
                'color' => 'success',
                'animation' => 'fade-up'
            ],
            [
                'icon' => 'phone',
                'title' => 'ریسپانسیو',
                'description' => 'سازگار با تمام دستگاه‌ها و اندازه‌های صفحه',
                'color' => 'info',
                'animation' => 'fade-up'
            ],
            [
                'icon' => 'gear',
                'title' => 'قابلیت تنظیم',
                'description' => 'امکان شخصی‌سازی و تنظیم آسان',
                'color' => 'warning',
                'animation' => 'fade-up'
            ],
            [
                'icon' => 'cloud',
                'title' => 'پشتیبانی ابری',
                'description' => 'پشتیبانی کامل از خدمات ابری',
                'color' => 'secondary',
                'animation' => 'fade-up'
            ],
            [
                'icon' => 'people',
                'title' => 'مدیریت کاربران',
                'description' => 'سیستم مدیریت کاربران پیشرفته',
                'color' => 'danger',
                'animation' => 'fade-up'
            ]
        ],
        'show_stats' => true,
        'stats' => [
            [
                'icon' => 'users',
                'value' => '1000+',
                'label' => 'کاربر فعال'
            ],
            [
                'icon' => 'file-text',
                'value' => '500+',
                'label' => 'مقاله منتشر شده'
            ],
            [
                'icon' => 'shield-check',
                'value' => '100%',
                'label' => 'امنیت تضمین شده'
            ],
            [
                'icon' => 'clock',
                'value' => '99.9%',
                'label' => 'آپتایم'
            ]
        ]
    ],

    // تنظیمات ویجت Latest
    'latest_widget' => [
        'enabled' => true,
        'title' => 'آخرین مطالب',
        'subtitle' => 'جدیدترین مقالات و مطالب ما',
        'limit' => 6,
        'show_featured' => true,
        'show_author' => true,
        'show_date' => true,
        'show_category' => true,
        'show_excerpt' => true,
        'layout' => 'grid', // grid, list
        'animation' => 'fade-in', // fade-in, slide-up
        'excerpt_length' => 120,
        'show_stats' => true
    ],

    // تنظیمات عمومی ویجت‌ها
    'widget_general' => [
        'enable_animations' => true,
        'enable_lazy_loading' => true,
        'enable_parallax' => true,
        'enable_analytics' => true,
        'cache_duration' => 3600, // 1 ساعت
        'max_items_per_widget' => 10,
        'responsive_breakpoints' => [
            'mobile' => 576,
            'tablet' => 768,
            'desktop' => 992,
            'large' => 1200
        ]
    ],

    // تنظیمات امنیتی ویجت‌ها
    'widget_security' => [
        'sanitize_output' => true,
        'escape_html' => true,
        'validate_urls' => true,
        'prevent_xss' => true,
        'limit_file_size' => 5242880, // 5MB
        'allowed_file_types' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'max_image_dimensions' => [
            'width' => 4000,
            'height' => 4000
        ]
    ],

    // تنظیمات عملکرد ویجت‌ها
    'widget_performance' => [
        'enable_caching' => true,
        'cache_prefix' => 'widget_',
        'minify_css' => true,
        'minify_js' => true,
        'compress_images' => true,
        'lazy_load_images' => true,
        'preload_critical_resources' => true
    ],

    // تنظیمات شخصی‌سازی ویجت‌ها
    'widget_customization' => [
        'enable_admin_controls' => true,
        'enable_drag_drop' => true,
        'enable_widget_ordering' => true,
        'enable_widget_visibility' => true,
        'enable_conditional_display' => true,
        'enable_user_permissions' => true
    ],

    // تنظیمات رنگ‌بندی ویجت‌ها
    'widget_colors' => [
        'primary_color' => '#667eea',
        'secondary_color' => '#764ba2',
        'success_color' => '#28a745',
        'warning_color' => '#ffc107',
        'danger_color' => '#dc3545',
        'info_color' => '#17a2b8',
        'light_color' => '#f8f9fa',
        'dark_color' => '#343a40'
    ],

    // تنظیمات فونت‌ها
    'widget_fonts' => [
        'primary_font' => 'Vazir',
        'secondary_font' => 'Tahoma',
        'heading_font' => 'Vazir',
        'body_font' => 'Vazir',
        'font_sizes' => [
            'xs' => '0.75rem',
            'sm' => '0.875rem',
            'base' => '1rem',
            'lg' => '1.125rem',
            'xl' => '1.25rem',
            '2xl' => '1.5rem',
            '3xl' => '1.875rem',
            '4xl' => '2.25rem'
        ]
    ],

    // تنظیمات انیمیشن‌ها
    'widget_animations' => [
        'enable_animations' => true,
        'animation_duration' => 1000,
        'animation_easing' => 'ease-out',
        'animation_delay' => 100,
        'enable_intersection_observer' => true,
        'enable_parallax_effects' => true,
        'enable_hover_effects' => true
    ],

    // تنظیمات SEO ویجت‌ها
    'widget_seo' => [
        'enable_structured_data' => true,
        'enable_meta_tags' => true,
        'enable_schema_markup' => true,
        'enable_open_graph' => true,
        'enable_twitter_cards' => true,
        'enable_breadcrumbs' => true,
        'enable_sitemap' => true
    ],

    // تنظیمات دسترسی‌پذیری
    'widget_accessibility' => [
        'enable_aria_labels' => true,
        'enable_keyboard_navigation' => true,
        'enable_screen_reader_support' => true,
        'enable_high_contrast_mode' => true,
        'enable_focus_indicators' => true,
        'enable_skip_links' => true
    ]
];
?> 