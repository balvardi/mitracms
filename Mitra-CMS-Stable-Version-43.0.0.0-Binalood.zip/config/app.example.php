<?php
/**
 * تنظیمات اصلی اپلیکیشن
 * این فایل را کپی کرده و نام آن را به app.php تغییر دهید
 */

return [
    // اطلاعات اصلی
    'name' => 'Mitra Global CMS',
    'version' => '1.0.0',
    'url' => 'http://localhost',
    
    // تنظیمات محیط
    'debug' => true,
    'timezone' => 'Asia/Tehran',
    'locale' => 'fa',
    
    // تنظیمات پایگاه داده
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'name' => 'mitracms',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4'
    ],
    
    // تنظیمات امنیتی
    'security' => [
        'key' => 'your-secret-key-here',
        'session_lifetime' => 7200
    ]
];
