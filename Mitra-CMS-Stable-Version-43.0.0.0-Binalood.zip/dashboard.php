<?php
require_once 'config/connection.php';
require_once 'templates/'.$settings['theme'].'/header.php';
try {
    $pdo = getDatabase();
        // دریافت اطلاعات کاربر
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    // آمار کاربر (اگر نویسنده یا ادیتور باشد)
    $userStats = [];
    if (in_array($_SESSION['role'], ['admin', 'editor', 'author'])) {
        // تعداد مطالب کاربر
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM posts WHERE author_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['posts'] = $stmt->fetchColumn();
        
        // تعداد صفحات کاربر
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM pages WHERE author_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['pages'] = $stmt->fetchColumn();
        
        // آخرین مطالب کاربر
        $stmt = $pdo->prepare("
            SELECT title, slug, status, created_at 
            FROM posts 
            WHERE author_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $userStats['recent_posts'] = $stmt->fetchAll();
    }
    
    $siteName = $settings['site_name'] ?? 'Mitra CMS';
    
} catch (PDOException $e) {
    die('خطا در بارگذاری داشبورد: ' . $e->getMessage());
}
require_once 'templates/'.$settings['theme'].'/dashboard.php';
require_once 'templates/'.$settings['theme'].'/footer.php';
?>
