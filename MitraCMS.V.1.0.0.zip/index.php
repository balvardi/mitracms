<?php
/**
 * Mitra CMS - فایل اصلی
 */

// بررسی نصب
if (!file_exists('.installed')) {
    header('Location: install/simple-installer.php');
    exit;
}

// بارگذاری تنظیمات
$config = [];
if (file_exists('config/app.php')) {
    $config = require 'config/app.php';
}

$dbConfig = [];
if (file_exists('config/database.php')) {
    $dbConfig = require 'config/database.php';
}

// اتصال به پایگاه داده
try {
    $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset=utf8mb4";
    $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('خطا در اتصال به پایگاه داده: ' . $e->getMessage());
}

// دریافت تنظیمات از پایگاه داده
$stmt = $pdo->query("SELECT `settingkey`, settingvalue FROM settings");
$settings = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['settingkey']] = $row['settingvalue'];
}

// دریافت صفحات
$stmt = $pdo->query("SELECT * FROM pages WHERE status = 'published' ORDER BY created_at DESC");
$pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $settings['site_title'] ?? 'Mitra CMS' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: "Vazirmatn", sans-serif; }
        .hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 100px 0; }
    </style>
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#"><?= $settings['site_title'] ?? 'Mitra CMS' ?></a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="admin/">پنل مدیریت</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container text-center">
            <h1 class="display-4 mb-4"><?= $settings['site_title'] ?? 'Mitra CMS' ?></h1>
            <p class="lead">سیستم مدیریت محتوای قدرتمند و ماژولار</p>
            <a href="admin/" class="btn btn-light btn-lg">ورود به پنل مدیریت</a>
        </div>
    </section>

    <!-- Content -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2>صفحات</h2>
                    <?php if (empty($pages)): ?>
                        <div class="alert alert-info">
                            هنوز صفحه‌ای ایجاد نشده است. از پنل مدیریت صفحه جدید ایجاد کنید.
                        </div>
                    <?php else: ?>
                        <?php foreach ($pages as $page): ?>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($page['title']) ?></h5>
                                    <p class="card-text"><?= nl2br(htmlspecialchars(substr($page['content'], 0, 200))) ?>...</p>
                                    <small class="text-muted">ایجاد شده در: <?= $page['created_at'] ?></small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>اطلاعات سایت</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>عنوان:</strong> <?= $settings['site_title'] ?? 'نامشخص' ?></p>
                            <p><strong>آدرس:</strong> <?= $settings['site_url'] ?? 'نامشخص' ?></p>
                            <p><strong>ایمیل مدیر:</strong> <?= $settings['admin_email'] ?? 'نامشخص' ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4">
        <div class="container text-center">
            <p>&copy; 2024 <?= $settings['site_title'] ?? 'Mitra CMS' ?>. تمامی حقوق محفوظ است.</p>
        </div>
    </footer>
</body>
</html>
