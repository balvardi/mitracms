-- Seed data for ModularCMS

-- Insert default admin user (password should be hashed in real implementation)
INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@modularcms.com', '$2b$10$example_hash_here', 'admin'),
('editor', 'editor@modularcms.com', '$2b$10$example_hash_here', 'editor');

-- Insert default system settings
INSERT INTO settings (settingkey, settingvalue, type) VALUES
('site_title', 'ModularCMS', 'string'),
('site_description', 'A modern, modular content management system', 'string'),
('site_keywords', 'cms, content management, modular, open source', 'string'),
('google_analytics_id', '', 'string'),
('theme_active', 'default', 'string'),
('seo_enabled', 'true', 'boolean'),
('cache_enabled', 'true', 'boolean');

-- Insert default modules
INSERT INTO modules (name, version, status, config) VALUES
('Blog Module', '1.2.0', 'active', '{"posts_per_page": 10, "allow_comments": true}'),
('Gallery Module', '2.1.0', 'active', '{"thumbnail_size": "medium", "lightbox": true}'),
('Contact Form', '1.0.5', 'inactive', '{"email_to": "contact@site.com", "captcha": true}'),
('SEO Tools', '3.0.0', 'active', '{"auto_sitemap": true, "meta_optimization": true}');

-- Insert default template
INSERT INTO templates (name, version, is_active, config) VALUES
('Default Theme', '1.0.0', true, '{"primary_color": "#3b82f6", "layout": "wide"}'),
('Business Pro', '2.1.0', false, '{"primary_color": "#1f2937", "layout": "boxed"}');

-- Insert sample pages
INSERT INTO pages (title, slug, content, meta_title, meta_description, status, author_id) VALUES
('Home', 'home', 'Welcome to our ModularCMS website. This is a demonstration of our powerful content management system.', 'Home - ModularCMS', 'Welcome to ModularCMS - A modern content management system', 'published', 1),
('About Us', 'about', 'Learn more about our company and mission. We are dedicated to providing the best CMS solution.', 'About Us - ModularCMS', 'Learn about our company and our mission', 'published', 1),
('Contact', 'contact', 'Get in touch with us. We would love to hear from you.', 'Contact Us - ModularCMS', 'Contact us for support and inquiries', 'published', 1);

-- Insert sample page modules
INSERT INTO page_modules (page_id, module_type, module_data, sort_order) VALUES
(1, 'hero', '{"title": "Welcome to ModularCMS", "subtitle": "Build amazing websites", "background": "gradient"}', 1),
(1, 'content', '{"title": "Features", "content": "Our CMS offers modular architecture, beautiful templates, and SEO optimization."}', 2),
(2, 'content', '{"title": "Our Story", "content": "We started this project to create a better CMS experience for developers and content creators."}', 1);

-- Insert SEO data for pages
INSERT INTO seo_data (page_id, canonical_url, og_title, og_description, twitter_card) VALUES
(1, 'https://yoursite.com/', 'ModularCMS - Modern Content Management', 'A powerful, modular CMS built for the modern web', 'summary_large_image'),
(2, 'https://yoursite.com/about', 'About ModularCMS', 'Learn about our mission and team', 'summary'),
(3, 'https://yoursite.com/contact', 'Contact ModularCMS', 'Get in touch with our team', 'summary');
