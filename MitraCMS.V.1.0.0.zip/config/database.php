<?php
/**
 * Simple DB config
 * Rename this file to database.php and put your real credentials.
 */
return [
    'host'     => 'localhost',
    'port'     => 3306,
    'database' => 'mitra_cms',
    'username' => 'admin',
    'password' => 'admin',
    'charset'  => 'utf8mb4'
];
