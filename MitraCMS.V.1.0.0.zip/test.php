<?php
/**
 * فایل تست برای بررسی عملکرد سرور
 */

echo "<h1>تست سرور PHP</h1>";

// بررسی نسخه PHP
echo "<p><strong>نسخه PHP:</strong> " . phpversion() . "</p>";

// بررسی تنظیمات مهم
echo "<h2>تنظیمات PHP:</h2>";
echo "<ul>";
echo "<li>display_errors: " . (ini_get('display_errors') ? 'ON' : 'OFF') . "</li>";
echo "<li>error_reporting: " . error_reporting() . "</li>";
echo "<li>memory_limit: " . ini_get('memory_limit') . "</li>";
echo "<li>max_execution_time: " . ini_get('max_execution_time') . "</li>";
echo "</ul>";

// بررسی ماژول‌های مورد نیاز
echo "<h2>ماژول‌های PHP:</h2>";
echo "<ul>";
echo "<li>PDO: " . (extension_loaded('pdo') ? '✅' : '❌') . "</li>";
echo "<li>PDO MySQL: " . (extension_loaded('pdo_mysql') ? '✅' : '❌') . "</li>";
echo "<li>JSON: " . (extension_loaded('json') ? '✅' : '❌') . "</li>";
echo "<li>Session: " . (extension_loaded('session') ? '✅' : '❌') . "</li>";
echo "</ul>";

// بررسی مجوزهای فایل
echo "<h2>مجوزهای فایل:</h2>";
echo "<ul>";
echo "<li>فایل فعلی قابل خواندن: " . (is_readable(__FILE__) ? '✅' : '❌') . "</li>";
echo "<li>دایرکتوری فعلی قابل نوشتن: " . (is_writable(__DIR__) ? '✅' : '❌') . "</li>";
echo "</ul>";

// تست session
session_start();
$_SESSION['test'] = 'working';
echo "<h2>تست Session:</h2>";
echo "<p>Session: " . (isset($_SESSION['test']) ? '✅ کار می‌کند' : '❌ کار نمی‌کند') . "</p>";

// اطلاعات سرور
echo "<h2>اطلاعات سرور:</h2>";
echo "<ul>";
echo "<li>سرور: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'نامشخص') . "</li>";
echo "<li>Document Root: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'نامشخص') . "</li>";
echo "<li>Script Name: " . ($_SERVER['SCRIPT_NAME'] ?? 'نامشخص') . "</li>";
echo "</ul>";

echo "<hr>";
echo "<p><a href='index.php'>بازگشت به صفحه اصلی</a></p>";
?>
