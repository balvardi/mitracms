<?php

class Installer
{
    private $requirements = [
        'php_version' => [
            'name' => 'نسخه PHP',
            'description' => 'PHP 7.4 یا بالاتر مورد نیاز است',
            'required' => '7.4.0',
            'check' => 'checkPhpVersion'
        ],
        'mysql_extension' => [
            'name' => 'افزونه MySQL',
            'description' => 'افزونه PDO MySQL باید نصب باشد',
            'check' => 'checkMysqlExtension'
        ],
        'mbstring_extension' => [
            'name' => 'افزونه mbstring',
            'description' => 'افزونه mbstring برای پردازش متن فارسی',
            'check' => 'checkMbstringExtension'
        ],
        'openssl_extension' => [
            'name' => 'افزونه OpenSSL',
            'description' => 'افزونه OpenSSL برای امنیت',
            'check' => 'checkOpensslExtension'
        ],
        'gd_extension' => [
            'name' => 'افزونه GD',
            'description' => 'افزونه GD برای پردازش تصاویر',
            'check' => 'checkGdExtension'
        ],
        'curl_extension' => [
            'name' => 'افزونه cURL',
            'description' => 'افزونه cURL برای ارتباطات HTTP',
            'check' => 'checkCurlExtension'
        ],
        'zip_extension' => [
            'name' => 'افزونه ZIP',
            'description' => 'افزونه ZIP برای فشرده‌سازی',
            'check' => 'checkZipExtension'
        ],
        'config_writable' => [
            'name' => 'دسترسی نوشتن config',
            'description' => 'پوشه config باید قابل نوشتن باشد',
            'check' => 'checkConfigWritable'
        ],
        'storage_writable' => [
            'name' => 'دسترسی نوشتن storage',
            'description' => 'پوشه storage باید قابل نوشتن باشد',
            'check' => 'checkStorageWritable'
        ]
    ];

    public function checkRequirements()
    {
        $results = [];
        
        foreach ($this->requirements as $key => $requirement) {
            $checkMethod = $requirement['check'];
            $result = $this->$checkMethod();
            
            $results[] = [
                'key' => $key,
                'name' => $requirement['name'],
                'description' => $requirement['description'],
                'status' => $result['status'],
                'current' => $result['current'] ?? null,
                'required' => $requirement['required'] ?? null
            ];
        }
        
        return [
            'success' => true,
            'requirements' => $results
        ];
    }

    private function checkPhpVersion()
    {
        $current = PHP_VERSION;
        $required = $this->requirements['php_version']['required'];
        
        return [
            'status' => version_compare($current, $required, '>=') ? 'success' : 'error',
            'current' => $current
        ];
    }

    private function checkMysqlExtension()
    {
        return [
            'status' => extension_loaded('pdo_mysql') ? 'success' : 'error'
        ];
    }

    private function checkMbstringExtension()
    {
        return [
            'status' => extension_loaded('mbstring') ? 'success' : 'error'
        ];
    }

    private function checkOpensslExtension()
    {
        return [
            'status' => extension_loaded('openssl') ? 'success' : 'error'
        ];
    }

    private function checkGdExtension()
    {
        return [
            'status' => extension_loaded('gd') ? 'success' : 'error'
        ];
    }

    private function checkCurlExtension()
    {
        return [
            'status' => extension_loaded('curl') ? 'success' : 'error'
        ];
    }

    private function checkZipExtension()
    {
        return [
            'status' => extension_loaded('zip') ? 'success' : 'error'
        ];
    }

    private function checkConfigWritable()
    {
        return [
            'status' => is_writable(CONFIG_DIR) ? 'success' : 'error'
        ];
    }

    private function checkStorageWritable()
    {
        return [
            'status' => is_writable(STORAGE_DIR) ? 'success' : 'error'
        ];
    }

    public function testDatabaseConnection($data)
    {
        try {
            $dsn = "mysql:host={$data['db_host']};port={$data['db_port']};charset=utf8mb4";
            $pdo = new PDO($dsn, $data['db_username'], $data['db_password']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // تست ایجاد پایگاه داده
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$data['db_name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            return [
                'success' => true,
                'message' => 'اتصال موفقیت‌آمیز'
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'message' => 'خطا در اتصال: ' . $e->getMessage()
            ];
        }
    }

    public function installDatabase($data = null)
    {
        try {
            if (!$data) {
                $data = $_SESSION['install_data'] ?? [];
            }
            
            $dsn = "mysql:host=" . ($data['db_host'] ?? 'localhost') . ";dbname=" . ($data['db_name'] ?? 'mitracms') . ";charset=utf8mb4";
            $pdo = new PDO($dsn, $data['db_username'] ?? '', $data['db_password'] ?? '');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // خواندن فایل SQL
            $sqlFile = ROOT_DIR . '/database/schema.sql';
            if (!file_exists($sqlFile)) {
                // ایجاد جداول پایه
                $this->createBaseTables($pdo);
            } else {
                $sql = file_get_contents($sqlFile);
                $pdo->exec($sql);
            }
            
            // داده‌های اولیه
            $this->insertSeedData($pdo, $data);
            
            return [
                'success' => true,
                'message' => 'پایگاه داده نصب شد'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطا در نصب پایگاه داده: ' . $e->getMessage()
            ];
        }
    }

    private function createBaseTables($pdo)
    {
        $tables = [
            'users' => "
                CREATE TABLE users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('admin', 'editor', 'user') DEFAULT 'user',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            'pages' => "
                CREATE TABLE pages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    slug VARCHAR(255) UNIQUE NOT NULL,
                    content TEXT,
                    meta_title VARCHAR(255),
                    meta_description TEXT,
                    status ENUM('draft', 'published') DEFAULT 'draft',
                    author_id INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (author_id) REFERENCES users(id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ",
            'settings' => "
                CREATE TABLE settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    `key` VARCHAR(100) UNIQUE NOT NULL,
                    value TEXT,
                    type VARCHAR(20) DEFAULT 'string',
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            "
        ];
        
        foreach ($tables as $table => $sql) {
            $pdo->exec($sql);
        }
    }

    private function insertSeedData($pdo, $data)
    {
        // تنظیمات پایه
        $settings = [
            ['site_title', $data['site_title'] ?? 'Mitra Global CMS'],
            ['site_description', $data['site_description'] ?? 'سیستم مدیریت محتوای قدرتمند'],
            ['site_url', $data['site_url'] ?? 'http://localhost'],
            ['admin_email', $data['admin_email'] ?? 'admin@example.com'],
            ['timezone', 'Asia/Tehran'],
            ['language', 'fa']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)");
        foreach ($settings as $setting) {
            $stmt->execute($setting);
        }
    }

    public function createConfigFiles($data)
    {
        try {
            // ذخیره داده‌ها در session
            $_SESSION['install_data'] = $data;
            
            // ایجاد فایل پیکربندی پایگاه داده
            $dbConfig = "<?php\nreturn [\n";
            $dbConfig .= "    'host' => '" . ($data['db_host'] ?? 'localhost') . "',\n";
            $dbConfig .= "    'port' => '" . ($data['db_port'] ?? '3306') . "',\n";
            $dbConfig .= "    'database' => '" . ($data['db_name'] ?? 'mitracms') . "',\n";
            $dbConfig .= "    'username' => '" . ($data['db_username'] ?? '') . "',\n";
            $dbConfig .= "    'password' => '" . ($data['db_password'] ?? '') . "',\n";
            $dbConfig .= "    'charset' => 'utf8mb4',\n";
            $dbConfig .= "    'collation' => 'utf8mb4_unicode_ci'\n";
            $dbConfig .= "];\n";
            
            file_put_contents(CONFIG_DIR . '/database.php', $dbConfig);
            
            // ایجاد فایل پیکربندی اپلیکیشن
            $appConfig = "<?php\nreturn [\n";
            $appConfig .= "    'name' => '{$data['site_title']}',\n";
            $appConfig .= "    'description' => '{$data['site_description']}',\n";
            $appConfig .= "    'url' => '{$data['site_url']}',\n";
            $appConfig .= "    'timezone' => 'Asia/Tehran',\n";
            $appConfig .= "    'locale' => 'fa',\n";
            $appConfig .= "    'debug' => false,\n";
            $appConfig .= "    'key' => '" . bin2hex(random_bytes(32)) . "'\n";
            $appConfig .= "];\n";
            
            file_put_contents(CONFIG_DIR . '/app.php', $appConfig);
            
            return [
                'success' => true,
                'message' => 'فایل‌های پیکربندی ایجاد شدند'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطا در ایجاد فایل‌های پیکربندی: ' . $e->getMessage()
            ];
        }
    }

    public function createAdminUser($data)
    {
        try {
            $installData = $_SESSION['install_data'] ?? [];

            $dsn = "mysql:host=" . ($installData['db_host'] ?? 'localhost') . ";dbname=" . ($installData['db_name'] ?? 'mitracms') . ";charset=utf8mb4";
            $pdo = new PDO($dsn, $installData['db_username'] ?? '', $installData['db_password'] ?? '');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
            $stmt->execute([$data['username'], $data['email'], $hashedPassword]);
            
            // ذخیره اطلاعات ادمین
            $_SESSION['install_data']['admin_username'] = $data['username'];
            $_SESSION['install_data']['admin_email'] = $data['email'];
            
            return [
                'success' => true,
                'message' => 'کاربر مدیر ایجاد شد'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطا در ایجاد کاربر مدیر: ' . $e->getMessage()
            ];
        }
    }

    public function finalizeInstallation()
    {
        try {
            // ایجاد فایل نصب شده
            file_put_contents(ROOT_DIR . '/.installed', date('Y-m-d H:i:s'));
            
            // پاک کردن فایل‌های نصب (اختیاری)
            // $this->cleanupInstaller();
            
            return [
                'success' => true,
                'message' => 'نصب تکمیل شد'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'خطا در تکمیل نصب: ' . $e->getMessage()
            ];
        }
    }

    private function cleanupInstaller()
    {
        $files = [
            INSTALL_DIR . '/index.php',
            INSTALL_DIR . '/includes',
            INSTALL_DIR . '/steps',
            INSTALL_DIR . '/assets'
        ];
        
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            } elseif (is_dir($file)) {
                $this->deleteDirectory($file);
            }
        }
    }

    private function deleteDirectory($dir)
    {
        if (!is_dir($dir)) return;
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->deleteDirectory($path) : unlink($path);
        }
        rmdir($dir);
    }
}
