<div class="card">
    <div class="card-header">
        <h4 class="mb-0">
            <i class="fas fa-user-shield me-2"></i>
            ایجاد کاربر مدیر
        </h4>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            حساب کاربری مدیر کل سیستم را ایجاد کنید
        </p>
        
        <form id="admin-form">
            <div class="mb-3">
                <label for="username" class="form-label">نام کاربری</label>
                <input type="text" class="form-control" id="username" name="username" value="admin" required>
                <div class="form-text">نام کاربری برای ورود به پنل مدیریت</div>
            </div>
            
            <div class="mb-3">
                <label for="email" class="form-label">ایمیل</label>
                <input type="email" class="form-control" id="email" name="email" required>
                <div class="form-text">ایمیل برای ورود و بازیابی رمز عبور</div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="password" class="form-label">رمز عبور</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="8">
                        <div class="form-text">حداقل 8 کاراکتر</div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="password_confirm" class="form-label">تکرار رمز عبور</label>
                        <input type="password" class="form-control" id="password_confirm" name="password_confirm" required minlength="8">
                        <div class="form-text">رمز عبور را مجدداً وارد کنید</div>
                    </div>
                </div>
            </div>
            
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>مهم:</strong> اطلاعات ورود خود را در جای امنی یادداشت کنید. این اطلاعات برای دسترسی به پنل مدیریت ضروری است.
            </div>
        </form>
    </div>
</div>

<div class="d-flex justify-content-between mt-4">
    <button type="button" class="btn btn-outline-secondary" data-action="prev-step" data-prev-step="config">
        <i class="fas fa-arrow-right me-2"></i>
        مرحله قبل
    </button>
    
    <button type="button" class="btn btn-primary" data-action="create-admin">
        مرحله بعد
        <i class="fas fa-arrow-left ms-2"></i>
    </button>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-shield-alt me-2"></i>نکات امنیتی</h6>
    <ul class="mb-0">
        <li>از رمز عبور قوی استفاده کنید (ترکیب حروف، اعداد و علائم)</li>
        <li>نام کاربری پیش‌فرض "admin" را تغییر دهید</li>
        <li>ایمیل معتبر وارد کنید تا بتوانید رمز عبور را بازیابی کنید</li>
        <li>این اطلاعات را در جای امنی ذخیره کنید</li>
    </ul>
</div>
