<div class="card">
    <div class="card-header">
        <h4 class="mb-0">
            <i class="fas fa-download me-2"></i>
            در حال نصب...
        </h4>
    </div>
    <div class="card-body">
        <p class="text-muted mb-4">
            لطفاً صبر کنید تا فرآیند نصب تکمیل شود
        </p>
        
        <div class="progress mb-4" style="height: 20px;">
            <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
        </div>
        
        <div id="installation-log" class="installation-log">
            <div class="log-entry info">آماده‌سازی نصب...</div>
        </div>
        
        <div class="mt-4 text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">در حال نصب...</span>
            </div>
            <p class="mt-2 text-muted">این فرآیند ممکن است چند دقیقه طول بکشد</p>
        </div>
    </div>
</div>

<div class="info-box mt-4">
    <h6><i class="fas fa-info-circle me-2"></i>در حال انجام</h6>
    <ul class="mb-0">
        <li>ایجاد جداول پایگاه داده</li>
        <li>وارد کردن داده‌های اولیه</li>
        <li>تنظیم مجوزهای فایل‌ها</li>
        <li>پیکربندی نهایی سیستم</li>
    </ul>
</div>
