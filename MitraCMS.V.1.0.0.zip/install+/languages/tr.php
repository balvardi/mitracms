<?php
/**
 * Türkçe Dil Dosyası
 */

return [
    'app' => [
        'name' => 'Mitra Global CMS',
        'installer' => 'Otomatik Yükleyici',
        'version' => 'Sürüm :version'
    ],

    'navigation' => [
        'next' => 'Sonraki Adım',
        'previous' => 'Önceki Adım',
        'start' => 'Kurulumu Başlat',
        'continue' => 'Devam Et',
        'finish' => 'Bitir',
        'retry' => 'Tekrar Dene',
        'skip' => 'Atla'
    ],

    'steps' => [
        'welcome' => 'Hoş Geldiniz',
        'requirements' => 'Gereksinimler',
        'database' => 'Veritabanı Ayarları',
        'config' => 'Site Yapılandırması',
        'admin' => 'Yönetici Oluştur',
        'install' => 'Kurulum',
        'complete' => 'Tamamlandı'
    ],

    'welcome' => [
        'title' => 'Hoş Geldiniz!',
        'subtitle' => 'Mitra Global CMS Yükleyicisine Hoş Geldiniz',
        'description' => 'Bu yükleyici güçlü içerik yönetim sisteminizi kurmanızda size rehberlik edecek',
        'features' => [
            'modular' => [
                'title' => 'Modüler Mimari',
                'description' => 'Yetenekleri genişletmek için esnek modüler sistem'
            ],
            'themes' => [
                'title' => 'Güzel Temalar',
                'description' => 'Hazır temalar ve özel tasarım yetenekleri'
            ],
            'seo' => [
                'title' => 'SEO Optimizasyonu',
                'description' => 'Daha iyi sıralama için eksiksiz SEO araçları'
            ],
            'security' => [
                'title' => 'Yüksek Güvenlik',
                'description' => 'Güvenlik tehditlerine karşı gelişmiş koruma'
            ]
        ],
        'info' => [
            'title' => 'Önemli Bilgiler',
            'items' => [
                'Sunucunuzun sistem gereksinimlerini karşıladığından emin olun',
                'Kurulumdan önce dosyalarınızı yedekleyin',
                'Veritabanı bilgilerinizi hazır bulundurun',
                'Kurulum işlemi yaklaşık 5-10 dakika sürer'
            ]
        ]
    ],

    'requirements' => [
        'title' => 'Gereksinimler Kontrolü',
        'description' => 'Sistem gereksinimleri kontrol edilirken lütfen bekleyin...',
        'checking' => 'Sistem kontrol ediliyor...',
        'check_again' => 'Tekrar Kontrol Et',
        'all_passed' => 'Tüm gereksinimler karşılandı',
        'some_failed' => 'Bazı gereksinimler karşılanmadı',
        'fix_required' => 'Sorunları Düzeltin',
        'items' => [
            'php_version' => 'PHP Sürümü',
            'mysql_extension' => 'MySQL Uzantısı',
            'mbstring_extension' => 'mbstring Uzantısı',
            'openssl_extension' => 'OpenSSL Uzantısı',
            'gd_extension' => 'GD Uzantısı',
            'curl_extension' => 'cURL Uzantısı',
            'zip_extension' => 'ZIP Uzantısı',
            'config_writable' => 'Config Yazma Erişimi',
            'storage_writable' => 'Storage Yazma Erişimi'
        ],
        'descriptions' => [
            'php_version' => 'PHP 7.4 veya üzeri gerekli',
            'mysql_extension' => 'PDO MySQL uzantısı yüklü olmalı',
            'mbstring_extension' => 'Metin işleme için mbstring uzantısı',
            'openssl_extension' => 'Güvenlik için OpenSSL uzantısı',
            'gd_extension' => 'Görüntü işleme için GD uzantısı',
            'curl_extension' => 'HTTP iletişimi için cURL uzantısı',
            'zip_extension' => 'Sıkıştırma için ZIP uzantısı',
            'config_writable' => 'Config klasörü yazılabilir olmalı',
            'storage_writable' => 'Storage klasörü yazılabilir olmalı'
        ],
        'help' => [
            'title' => 'Yardım',
            'subtitle' => 'Hata ile karşılaşırsanız:',
            'php_version' => 'Hosting kontrol panelinden PHP sürümünü 7.4+ olarak değiştirin',
            'extensions' => 'Kontrol paneli üzerinden etkinleştirin veya hosting desteği ile iletişime geçin',
            'permissions' => 'Klasör yazma izinlerini 755 olarak ayarlayın'
        ]
    ],

    'database' => [
        'title' => 'Veritabanı Ayarları',
        'description' => 'MySQL veritabanı bilgilerinizi girin',
        'host' => 'Sunucu Adresi',
        'host_help' => 'Genellikle localhost',
        'port' => 'Port',
        'name' => 'Veritabanı Adı',
        'name_help' => 'Veritabanı önceden oluşturulmuş olmalı',
        'username' => 'Kullanıcı Adı',
        'password' => 'Şifre',
        'test_connection' => 'Bağlantıyı Test Et',
        'connection_success' => 'Veritabanı bağlantısı başarılı',
        'connection_failed' => 'Veritabanı bağlantısı başarısız',
        'info' => [
            'title' => 'Önemli Notlar',
            'items' => [
                'Veritabanı cPanel veya phpMyAdmin\'de önceden oluşturulmuş olmalı',
                'Veritabanı kullanıcısının veritabanına tam erişimi olmalı',
                'Devam etmeden önce bağlantıyı test ettiğinizden emin olun'
            ]
        ]
    ],

    'config' => [
        'title' => 'Site Yapılandırması',
        'description' => 'Sitenizin temel bilgilerini girin',
        'site_title' => 'Site Başlığı',
        'site_title_help' => 'Bu başlık tarayıcı sekmelerinde ve arama motorlarında görüntülenecek',
        'site_description' => 'Site Açıklaması',
        'site_description_help' => 'Arama motorları için sitenizin kısa açıklaması',
        'site_url' => 'Site URL\'si',
        'site_url_help' => 'Sitenizin tam URL\'si (sonunda eğik çizgi olmadan)',
        'admin_email' => 'Yönetici E-postası',
        'admin_email_help' => 'Bildirimler için birincil e-posta',
        'timezone' => 'Saat Dilimi',
        'language' => 'Varsayılan Dil',
        'languages' => [
            'fa' => 'Farsça',
            'en' => 'İngilizce',
            'ar' => 'Arapça'
        ],
        'timezones' => [
            'Asia/Tehran' => 'Tahran (İran)',
            'Asia/Dubai' => 'Dubai (BAE)',
            'Asia/Kuwait' => 'Kuveyt',
            'Asia/Riyadh' => 'Riyad (Suudi Arabistan)',
            'Europe/Istanbul' => 'İstanbul (Türkiye)'
        ],
        'recommendations' => [
            'title' => 'Öneriler',
            'items' => [
                'Kısa ve çekici bir site başlığı seçin',
                'Site açıklaması SEO için çok önemlidir',
                'Site URL\'si tam olarak domain\'inizle eşleşmeli',
                'Yönetici e-postası şifre kurtarma için kullanılır'
            ]
        ]
    ],

    'admin' => [
        'title' => 'Yönetici Kullanıcı Oluştur',
        'description' => 'Sistem yöneticisi hesabını oluşturun',
        'username' => 'Kullanıcı Adı',
        'username_help' => 'Yönetici paneli girişi için kullanıcı adı',
        'email' => 'E-posta',
        'email_help' => 'Giriş ve şifre kurtarma için e-posta',
        'password' => 'Şifre',
        'password_help' => 'Minimum 8 karakter',
        'password_confirm' => 'Şifre Onayı',
        'password_confirm_help' => 'Şifreyi tekrar girin',
        'warning' => 'Giriş bilgilerinizi güvenli bir yere yazın. Bu bilgiler yönetici paneline erişim için gereklidir.',
        'security_tips' => [
            'title' => 'Güvenlik İpuçları',
            'items' => [
                'Güçlü bir şifre kullanın (harf, rakam ve sembol karışımı)',
                'Varsayılan "admin" kullanıcı adını değiştirin',
                'Şifrenizi kurtarabilmek için geçerli bir e-posta girin',
                'Bu bilgileri güvenli bir yerde saklayın'
            ]
        ]
    ],

    'install' => [
        'title' => 'Kuruluyor...',
        'description' => 'Kurulum işlemi tamamlanırken lütfen bekleyin',
        'preparing' => 'Kurulum hazırlanıyor...',
        'database_install' => 'Veritabanı kuruluyor...',
        'database_success' => 'Veritabanı kuruldu ✓',
        'final_config' => 'Son yapılandırma...',
        'completed' => 'Kurulum başarıyla tamamlandı! ✓',
        'please_wait' => 'Bu işlem birkaç dakika sürebilir',
        'tasks' => [
            'title' => 'Devam Ediyor',
            'items' => [
                'Veritabanı tabloları oluşturuluyor',
                'İlk veriler ekleniyor',
                'Dosya izinleri ayarlanıyor',
                'Son sistem yapılandırması'
            ]
        ]
    ],

    'complete' => [
        'title' => 'Kurulum Tamamlandı!',
        'subtitle' => 'Mitra Global CMS başarıyla kuruldu',
        'site_info' => 'Site Bilgileri',
        'admin_info' => 'Yönetici Giriş Bilgileri',
        'site_url' => 'Site URL\'si',
        'admin_panel' => 'Yönetici Paneli',
        'username' => 'Kullanıcı Adı',
        'email' => 'E-posta',
        'next_steps' => [
            'title' => 'Sonraki Adımlar',
            'items' => [
                'Yönetici paneline gidin ve giriş yapın',
                'İlk site ayarlarını tamamlayın',
                'Tercih ettiğiniz temayı seçin',
                'İlk site içeriğini oluşturun'
            ]
        ],
        'security_notes' => [
            'title' => 'Önemli Güvenlik Notları',
            'items' => [
                'Install klasörünü sunucudan silin',
                'Yönetici şifresini değiştirin',
                'Sitenizin düzenli yedeklerini alın',
                'Sistemi güncel tutun'
            ]
        ],
        'login_admin' => 'Yönetici Paneline Giriş',
        'view_site' => 'Siteyi Görüntüle',
        'thanks' => [
            'title' => 'Mitra Global CMS\'i seçtiğiniz için teşekkürler!',
            'subtitle' => 'Son haberler ve güncellemeler için:',
            'links' => [
                'website' => 'Web Sitesi',
                'docs' => 'Dokümantasyon',
                'support' => 'Destek',
                'github' => 'GitHub'
            ]
        ]
    ],

    'common' => [
        'loading' => 'Yükleniyor...',
        'processing' => 'İşleniyor...',
        'please_wait' => 'Lütfen bekleyin',
        'error' => 'Hata',
        'success' => 'Başarılı',
        'warning' => 'Uyarı',
        'info' => 'Bilgi',
        'required' => 'Gerekli',
        'optional' => 'İsteğe bağlı',
        'yes' => 'Evet',
        'no' => 'Hayır',
        'ok' => 'Tamam',
        'cancel' => 'İptal',
        'close' => 'Kapat',
        'save' => 'Kaydet',
        'edit' => 'Düzenle',
        'delete' => 'Sil',
        'view' => 'Görüntüle',
        'download' => 'İndir',
        'upload' => 'Yükle',
        'search' => 'Ara',
        'filter' => 'Filtrele',
        'sort' => 'Sırala',
        'refresh' => 'Yenile'
    ],

    'errors' => [
        'connection_failed' => 'Sunucu bağlantısı başarısız',
        'database_error' => 'Veritabanı hatası: :message',
        'file_not_writable' => 'Dosya yazılabilir değil: :file',
        'invalid_input' => 'Geçersiz giriş',
        'passwords_not_match' => 'Şifreler eşleşmiyor',
        'email_invalid' => 'E-posta geçersiz',
        'required_field' => 'Bu alan gereklidir',
        'installation_failed' => 'Kurulum başarısız',
        'unknown_error' => 'Bilinmeyen bir hata oluştu'
    ]
];
