interface ContentSectionProps {
  title: string
  content: string
  className?: string
}

export function ContentSection({ title, content, className = "" }: ContentSectionProps) {
  return (
    <section className={`py-12 ${className}`}>
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">{title}</h2>
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600 leading-relaxed">{content}</p>
        </div>
      </div>
    </section>
  )
}
