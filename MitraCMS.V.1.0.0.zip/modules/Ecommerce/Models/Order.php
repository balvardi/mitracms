<?php

namespace Modules\Ecommerce\Models;

use App\Core\Model;
use App\Core\Database;

class Order extends Model
{
    protected $table = 'orders';
    protected $fillable = [
        'order_number', 'user_id', 'status', 'total_amount', 'tax_amount',
        'shipping_amount', 'discount_amount', 'payment_method', 'payment_status',
        'billing_address', 'shipping_address', 'notes', 'tracking_number'
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'shipping_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'billing_address' => 'json',
        'shipping_address' => 'json'
    ];

    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
    }

    public function create(array $data): int
    {
        $data = $this->validateOrderData($data);
        
        // Generate unique order number
        $data['order_number'] = $this->generateOrderNumber();
        
        $sql = "INSERT INTO {$this->table} (
            order_number, user_id, status, total_amount, tax_amount,
            shipping_amount, discount_amount, payment_method, payment_status,
            billing_address, shipping_address, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $data['order_number'],
            $data['user_id'],
            $data['status'] ?? 'pending',
            $data['total_amount'],
            $data['tax_amount'] ?? 0,
            $data['shipping_amount'] ?? 0,
            $data['discount_amount'] ?? 0,
            $data['payment_method'],
            $data['payment_status'] ?? 'pending',
            json_encode($data['billing_address']),
            json_encode($data['shipping_address']),
            $data['notes'] ?? null
        ]);

        return $this->db->lastInsertId();
    }

    public function addOrderItems(int $orderId, array $items): bool
    {
        $sql = "INSERT INTO order_items (order_id, product_id, quantity, price, total) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        
        foreach ($items as $item) {
            $this->validateOrderItem($item);
            
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['quantity'],
                $item['price'],
                $item['quantity'] * $item['price']
            ]);
        }
        
        return true;
    }

    public function updateStatus(int $orderId, string $status): bool
    {
        $allowedStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];
        
        if (!in_array($status, $allowedStatuses)) {
            throw new \InvalidArgumentException("Invalid order status");
        }

        $sql = "UPDATE {$this->table} SET status = ?, updated_at = NOW() WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([$status, $orderId]);
    }

    public function updatePaymentStatus(int $orderId, string $paymentStatus, ?string $transactionId = null): bool
    {
        $allowedStatuses = ['pending', 'paid', 'failed', 'refunded'];
        
        if (!in_array($paymentStatus, $allowedStatuses)) {
            throw new \InvalidArgumentException("Invalid payment status");
        }

        $sql = "UPDATE {$this->table} 
                SET payment_status = ?, transaction_id = ?, updated_at = NOW() 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([$paymentStatus, $transactionId, $orderId]);
    }

    public function getByOrderNumber(string $orderNumber): ?array
    {
        $sql = "SELECT o.*, u.email as user_email, u.first_name, u.last_name 
                FROM {$this->table} o 
                LEFT JOIN users u ON o.user_id = u.id 
                WHERE o.order_number = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$orderNumber]);
        
        $order = $stmt->fetch();
        if ($order) {
            $order['billing_address'] = json_decode($order['billing_address'], true);
            $order['shipping_address'] = json_decode($order['shipping_address'], true);
            $order['items'] = $this->getOrderItems($order['id']);
        }
        
        return $order ?: null;
    }

    public function getOrderItems(int $orderId): array
    {
        $sql = "SELECT oi.*, p.name as product_name, p.sku 
                FROM order_items oi 
                LEFT JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$orderId]);
        
        return $stmt->fetchAll();
    }

    private function generateOrderNumber(): string
    {
        $prefix = 'ORD';
        $timestamp = date('Ymd');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        return $prefix . $timestamp . $random;
    }

    private function validateOrderData(array $data): array
    {
        $required = ['user_id', 'total_amount', 'payment_method', 'billing_address'];
        
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new \InvalidArgumentException("Field {$field} is required");
            }
        }

        // Validate amounts
        if (!is_numeric($data['total_amount']) || $data['total_amount'] <= 0) {
            throw new \InvalidArgumentException("Invalid total amount");
        }

        // Validate user exists
        if (!$this->userExists($data['user_id'])) {
            throw new \InvalidArgumentException("Invalid user ID");
        }

        return $data;
    }

    private function validateOrderItem(array $item): void
    {
        $required = ['product_id', 'quantity', 'price'];
        
        foreach ($required as $field) {
            if (empty($item[$field])) {
                throw new \InvalidArgumentException("Order item field {$field} is required");
            }
        }

        if (!is_numeric($item['quantity']) || $item['quantity'] <= 0) {
            throw new \InvalidArgumentException("Invalid quantity");
        }

        if (!is_numeric($item['price']) || $item['price'] <= 0) {
            throw new \InvalidArgumentException("Invalid price");
        }
    }

    private function userExists(int $userId): bool
    {
        $sql = "SELECT COUNT(*) FROM users WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        
        return $stmt->fetchColumn() > 0;
    }
}
