<?php

namespace Modules\FormBuilder\Controllers;

use App\Core\Controller;
use App\Core\Security;
use Modules\FormBuilder\Models\Form;
use Modules\UserManagement\Models\Role;

class FormController extends Controller
{
    private $formModel;
    private $security;
    private $roleModel;

    public function __construct()
    {
        parent::__construct();
        $this->formModel = new Form();
        $this->security = Security::getInstance();
        $this->roleModel = new Role();
    }

    public function show(string $slug)
    {
        try {
            // Rate limiting
            $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            if (!$this->security->checkRateLimit("form_view_{$clientIp}", 20, 300)) {
                return $this->error('Too many requests. Please try again later.', 429);
            }

            $form = $this->formModel->findBySlug($slug);
            
            if (!$form) {
                return $this->notFound();
            }

            $data = [
                'form' => $form,
                'csrf_token' => $this->security->generateCSRFToken('form_submit_' . $form['id'])
            ];

            return $this->view('forms.show', $data);

        } catch (\Exception $e) {
            $this->security->logSecurityEvent('form_view_error', [
                'slug' => $slug,
                'error' => $e->getMessage()
            ]);

            return $this->error('Form not available');
        }
    }

    public function submit(string $slug)
    {
        try {
            // Rate limiting for form submissions
            $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            if (!$this->security->checkRateLimit("form_submit_{$clientIp}", 5, 300)) {
                return $this->error('Too many submissions. Please try again later.', 429);
            }

            $form = $this->formModel->findBySlug($slug);
            
            if (!$form) {
                return $this->notFound();
            }

            // Verify CSRF token
            $csrfToken = $_POST['csrf_token'] ?? '';
            if (!$this->security->verifyCSRFToken($csrfToken, 'form_submit_' . $form['id'])) {
                throw new \Exception('Invalid CSRF token');
            }

            // Remove CSRF token from form data
            unset($_POST['csrf_token']);

            // Submit form
            $submissionId = $this->formModel->submitForm(
                $form['id'], 
                $_POST, 
                $this->getCurrentUserId()
            );

            // Log successful submission
            $this->security->logSecurityEvent('form_submitted', [
                'form_id' => $form['id'],
                'submission_id' => $submissionId,
                'user_id' => $this->getCurrentUserId()
            ]);

            // Handle redirect or show success message
            if (!empty($form['redirect_url'])) {
                return $this->redirect($form['redirect_url']);
            }

            return $this->view('forms.success', [
                'form' => $form,
                'message' => $form['success_message']
            ]);

        } catch (\Exception $e) {
            $this->security->logSecurityEvent('form_submission_error', [
                'slug' => $slug,
                'error' => $e->getMessage(),
                'user_id' => $this->getCurrentUserId()
            ]);

            return $this->view('forms.error', [
                'form' => $form ?? null,
                'error' => $e->getMessage()
            ]);
        }
    }

    public function admin()
    {
        // Check permissions
        if (!$this->checkPermission('forms.view')) {
            return $this->unauthorized();
        }

        $forms = $this->formModel->getAll();

        return $this->view('admin.forms.index', [
            'forms' => $forms
        ]);
    }

    public function create()
    {
        // Check permissions
        if (!$this->checkPermission('forms.create')) {
            return $this->unauthorized();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Verify CSRF token
                $csrfToken = $_POST['csrf_token'] ?? '';
                if (!$this->security->verifyCSRFToken($csrfToken, 'form_create')) {
                    throw new \Exception('Invalid CSRF token');
                }

                $data = $_POST;
                $data['created_by'] = $this->getCurrentUserId();
                
                $formId = $this->formModel->create($data);

                $this->security->logSecurityEvent('form_created', [
                    'form_id' => $formId,
                    'user_id' => $this->getCurrentUserId()
                ]);

                return $this->redirect('/admin/forms');

            } catch (\Exception $e) {
                return $this->view('admin.forms.create', [
                    'error' => $e->getMessage(),
                    'csrf_token' => $this->security->generateCSRFToken('form_create')
                ]);
            }
        }

        return $this->view('admin.forms.create', [
            'csrf_token' => $this->security->generateCSRFToken('form_create')
        ]);
    }

    public function submissions(int $formId)
    {
        // Check permissions
        if (!$this->checkPermission('forms.submissions')) {
            return $this->unauthorized();
        }

        $form = $this->formModel->find($formId);
        if (!$form) {
            return $this->notFound();
        }

        $submissions = $this->formModel->getSubmissions($formId);

        return $this->view('admin.forms.submissions', [
            'form' => $form,
            'submissions' => $submissions
        ]);
    }

    private function checkPermission(string $permission): bool
    {
        $userId = $this->getCurrentUserId();
        if (!$userId) {
            return false;
        }

        return $this->roleModel->hasPermission($userId, $permission);
    }

    private function getCurrentUserId(): ?int
    {
        return $_SESSION['user_id'] ?? null;
    }
}
