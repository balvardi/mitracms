<?php

namespace Modules\UserManagement\Models;

use App\Core\Model;
use App\Core\Database;

class Role extends Model
{
    protected $table = 'roles';
    protected $fillable = ['name', 'slug', 'description', 'permissions', 'level'];
    protected $casts = ['permissions' => 'json'];

    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
    }

    public function create(array $data): int
    {
        $data = $this->validateRoleData($data);
        
        $sql = "INSERT INTO {$this->table} (name, slug, description, permissions, level, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $data['name'],
            $data['slug'],
            $data['description'] ?? '',
            json_encode($data['permissions'] ?? []),
            $data['level'] ?? 1
        ]);

        return $this->db->lastInsertId();
    }

    public function assignToUser(int $userId, int $roleId): bool
    {
        // Check if user exists
        if (!$this->userExists($userId)) {
            throw new \InvalidArgumentException('User not found');
        }

        // Check if role exists
        if (!$this->find($roleId)) {
            throw new \InvalidArgumentException('Role not found');
        }

        // Remove existing role assignments
        $sql = "DELETE FROM user_roles WHERE user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);

        // Assign new role
        $sql = "INSERT INTO user_roles (user_id, role_id, created_at) VALUES (?, ?, NOW())";
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([$userId, $roleId]);
    }

    public function getUserRole(int $userId): ?array
    {
        $sql = "SELECT r.* FROM {$this->table} r 
                INNER JOIN user_roles ur ON r.id = ur.role_id 
                WHERE ur.user_id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        
        $role = $stmt->fetch();
        if ($role) {
            $role['permissions'] = json_decode($role['permissions'], true);
        }
        
        return $role ?: null;
    }

    public function hasPermission(int $userId, string $permission): bool
    {
        $role = $this->getUserRole($userId);
        
        if (!$role) {
            return false;
        }

        $permissions = $role['permissions'] ?? [];
        
        // Check for wildcard permission
        if (in_array('*', $permissions)) {
            return true;
        }

        // Check for specific permission
        if (in_array($permission, $permissions)) {
            return true;
        }

        // Check for module-level permissions (e.g., 'users.*' for 'users.create')
        $parts = explode('.', $permission);
        if (count($parts) > 1) {
            $modulePermission = $parts[0] . '.*';
            if (in_array($modulePermission, $permissions)) {
                return true;
            }
        }

        return false;
    }

    public function getAvailablePermissions(): array
    {
        return [
            // User Management
            'users.view' => 'مشاهده کاربران',
            'users.create' => 'ایجاد کاربر',
            'users.edit' => 'ویرایش کاربر',
            'users.delete' => 'حذف کاربر',
            'users.*' => 'تمام مجوزهای کاربران',

            // Content Management
            'content.view' => 'مشاهده محتوا',
            'content.create' => 'ایجاد محتوا',
            'content.edit' => 'ویرایش محتوا',
            'content.delete' => 'حذف محتوا',
            'content.publish' => 'انتشار محتوا',
            'content.*' => 'تمام مجوزهای محتوا',

            // E-commerce
            'ecommerce.view' => 'مشاهده فروشگاه',
            'ecommerce.products' => 'مدیریت محصولات',
            'ecommerce.orders' => 'مدیریت سفارشات',
            'ecommerce.reports' => 'گزارشات فروش',
            'ecommerce.*' => 'تمام مجوزهای فروشگاه',

            // Form Builder
            'forms.view' => 'مشاهده فرم‌ها',
            'forms.create' => 'ایجاد فرم',
            'forms.edit' => 'ویرایش فرم',
            'forms.delete' => 'حذف فرم',
            'forms.submissions' => 'مشاهده پاسخ‌ها',
            'forms.*' => 'تمام مجوزهای فرم‌ساز',

            // System
            'system.settings' => 'تنظیمات سیستم',
            'system.modules' => 'مدیریت ماژول‌ها',
            'system.themes' => 'مدیریت قالب‌ها',
            'system.backup' => 'پشتیبان‌گیری',
            'system.*' => 'تمام مجوزهای سیستم',

            // Super Admin
            '*' => 'دسترسی کامل'
        ];
    }

    private function validateRoleData(array $data): array
    {
        if (empty($data['name'])) {
            throw new \InvalidArgumentException('Role name is required');
        }

        // Sanitize name
        $data['name'] = htmlspecialchars(trim($data['name']), ENT_QUOTES, 'UTF-8');
        
        // Generate slug if not provided
        if (empty($data['slug'])) {
            $data['slug'] = $this->generateSlug($data['name']);
        }

        // Validate permissions
        if (!empty($data['permissions'])) {
            $availablePermissions = array_keys($this->getAvailablePermissions());
            foreach ($data['permissions'] as $permission) {
                if (!in_array($permission, $availablePermissions)) {
                    throw new \InvalidArgumentException("Invalid permission: {$permission}");
                }
            }
        }

        // Validate level
        if (isset($data['level'])) {
            if (!is_numeric($data['level']) || $data['level'] < 1 || $data['level'] > 10) {
                throw new \InvalidArgumentException('Role level must be between 1 and 10');
            }
        }

        return $data;
    }

    private function generateSlug(string $name): string
    {
        $slug = strtolower(trim($name));
        $slug = preg_replace('/[^a-z0-9\-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');
        
        return $slug;
    }

    private function userExists(int $userId): bool
    {
        $sql = "SELECT COUNT(*) FROM users WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        
        return $stmt->fetchColumn() > 0;
    }
}
